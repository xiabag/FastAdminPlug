<?php

return [
    'Title'      => '标题',
    'Url'        => '链接',
    'Target'     => '打开方式',
    'Weigh'      => '排序',
    'Views'      => '点击次数',
    'Blank'      => '新窗口',
    'Self'       => '原窗口',
    'Createtime' => '添加时间',
    'Updatetime' => '更新时间',
    'Status'     => '状态'
];
