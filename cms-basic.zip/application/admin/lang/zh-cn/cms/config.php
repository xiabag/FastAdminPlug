<?php

return [
    'Array key'   => '键',
    'Array value' => '值',
];
