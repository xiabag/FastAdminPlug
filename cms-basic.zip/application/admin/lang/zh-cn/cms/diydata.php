<?php

return [
    'User_id'                           => '会员ID',
    'Createtime'                        => '添加时间',
    'Updatetime'                        => '更新时间',
    'Memo'                              => '备注',
    'Rejected'                          => '已拒绝',
    'Array key'                         => '键名',
    'Array value'                       => '键值',
    'Status'                            => '状态',
    'Can not be only digital'           => '不能仅为数字',
    'Please input character or digital' => '请输入字母、数字或下划线'
];
