<?php

return [
    'Name'                              => '模型名称',
    'Table'                             => '表名',
    'Fields'                            => '字段列表',
    'Channeltpl'                        => '栏目页模板',
    'Listtpl'                           => '列表页模板',
    'Showtpl'                           => '详情页模板',
    'Posttpl'                           => '会员投稿模板',
    'Please Select'                     => '请选择',
    'Download'                          => '下载',
    'News'                              => '新闻',
    'Product'                           => '产品',
    'Common'                            => '常规(无自定义字段,需自行手动添加)',
    'Please input character or digital' => '请输入字母、数字或下划线',
    'Main list'                         => '主表列表',
    'Addon list'                        => '副表列表',
    'Duplicate'                         => '复制模型',
    'Createtime'                        => '创建时间',
    'Updatetime'                        => '更新时间',
    'Setting'                           => '配置'
];
