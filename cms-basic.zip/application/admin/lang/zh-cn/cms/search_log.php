<?php

return [
    'Keywords'   => '关键字',
    'Nums'       => '搜索次数',
    'Createtime' => '搜索时间',
    'Status'     => '状态'
];
