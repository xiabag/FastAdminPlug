<?php

return [
    'Type'      => '类型',
    'Aid'       => '关联ID',
    'Name'      => '名称',
    'Url'       => '来访页面',
    'Nums'      => '来访次数',
    'Lastdata'  => '最近5次来访时间',
    'Firsttime' => '首次来访时间',
    'Lasttime'  => '最新来访时间',
    'Index'     => '首页',
    'Archives'  => '文档',
    'Channel'   => '栏目',
    'Page'      => '单页',
    'Diyform'   => '自定义表单',
    'Special'   => '专题',
    'Tag'       => '标签',
    'User'      => '会员主页',
];
