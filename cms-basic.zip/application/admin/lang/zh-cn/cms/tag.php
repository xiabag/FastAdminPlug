<?php

return [
    'Name'        => '标签名称',
    'Archives'    => '文档ID集合',
    'Nums'        => '文档数',
    'Seotitle'    => 'SEO标题',
    'Keywords'    => '关键字',
    'Description' => '描述',
    'Spiders'     => '来访',
    'Autolink'    => '自动内链',
];
