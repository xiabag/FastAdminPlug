<?php
return [
    'Channel_id'  => '栏目',
    'Channel_ids' => '副栏目',
    'Tags'        => '标签',
    'Keywords'    => '关键字',
    'Description' => '描述',
    'Upload'      => '上传',
    'Image'       => '缩略图',
    'Images'      => '组图',
    'Price'       => '价格',
    'Outlink'     => '跳转链接',
    'Array key'   => '键',
    'Array value' => '值'
];
