<?php

namespace addons\comments;

use app\common\library\Menu;
use think\Addons;

/**
 * 插件
 */
class comments extends Addons
{

    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        $menu = [
            [
                'name'    => 'comments',
                'title'   => '评论管理',
                'icon'    => 'fa fa-comments',
                'sublist' => [
                    ['name' => 'comments/index', 'title' => '查看'],
                    ['name' => 'comments/add', 'title' => '添加'],
                    ['name' => 'comments/detail', 'title' => '详情'],
                    ['name' => 'comments/del', 'title' => '删除'],
                ]
            ]
        ];
        Menu::create($menu);
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        Menu::delete('comments');
        return true;
    }

    /**
     * 插件启用方法
     * @return bool
     */
    public function enable()
    {
        Menu::enable('comments');
        return true;
    }

    /**
     * 插件禁用方法
     * @return bool
     */
    public function disable()
    {
        Menu::disable('comments');
        return true;
    }

}
