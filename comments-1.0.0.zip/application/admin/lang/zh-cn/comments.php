<?php

return [
    'Id'          => 'ID',
    'Pid'         => '父ID',
    'Relation_db' => '关联表',
    'Relation_id' => '关联表ID',
    'User_id'     => '用户ID',
    'Content'     => '评论内容',
    'Grade'       => '评分',
    'Images'      => '配图',
    'Createtime'  => '发表时间',
    'Nickname'    => '用户昵称',
    'Avatar'      => '用户头像',
    'Support'     => '点赞数量'
];
