<?php

namespace app\admin\model;

use think\Model;


class Comments extends Model
{

    

    

    // 表名
    protected $name = 'comments';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [

    ];
    
    public $relation_db = '';

    public function getRelationDbAttr($value, $data)
    {
        $value = $value ? $value : $data['relation_db'];
        $conf = get_addon_config('comments');
        $dbconf = $conf['relationdb'];
        $list = $dbconf;
        return isset($list[$value]) ? $list[$value] : '';
    }

    public function getCreatetimeAttr($value, $data)
    {
        $value = $value ? $value : $data['createtime'];
        return date('Y-m-d H:i:s',$value);
    }

    public function reply(){
        return $this->hasOne('Comments','pid','id')->field('id,pid,relation_id,user_id,nickname,avatar,grade,images,support,images,createtime,content');
    }

}
