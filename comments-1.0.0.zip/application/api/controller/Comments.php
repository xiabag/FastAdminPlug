<?php

namespace app\api\controller;

use app\admin\model\Comments as ModelComments;
use app\common\controller\Api;

/**
 * 评论接口
 */
class Comments extends Api
{
    protected $noNeedLogin = ['relationdbs','list','myComments'];
    protected $noNeedRight = ['*'];

    /**
     * 获取当前插件关联数据表
     * 
     * 依据业务逻辑决定是否需要使用
     */
    public function relationdbs(){
        $conf = get_addon_config('comments');
        $dbconf = $conf['relationdb'];
        $this->success('ok',$dbconf);
    }

    /**
     * 获取插件关联表配置
     */
    private function relationConf(){
        $conf = get_addon_config('comments');
        $dbconf = $conf['relationdb'];
        return $dbconf;
    }

    /**
     * 获取评论列表
     */
    public function list(){
        $relation_db = $this->request->param('relation');
        if(!$relation_db) $this->error('请传入评论关联模型!');
        $relationdbs = $this->relationConf();
        if(!isset($relationdbs[$relation_db])){
            $this->error('未知的评论模型!');
        }

        $relation_id = $this->request->param('id');
        if(!$relation_id) $this->error('请传入关联模型ID!');

        $limit = $this->request->param('limit',10);
        $order_field = $this->request->param('order_field','createtime');
        $order_type = $this->request->param('order_type','desc');
        
        $is_support_sql = '0';
        if(!is_null($this->auth->id)){
            $is_support_sql = db('CommentsSupport')->where(['user_id'=>$this->auth->id])->where('comments_id=a.id')->field('count(id)')->buildSql();
        }

        $Comment = new ModelComments();
        // $Comment->relation_db = 'News';
        $res = $Comment->alias('a')
            ->where([
                'relation_db'=>$relation_db,
                'relation_id'=>$relation_id,
                'pid' => 0
            ])
            ->field("id,pid,relation_id,user_id,nickname,avatar,grade,images,support,images,createtime,content,{$is_support_sql} is_support")
            ->with('reply')
            ->order("{$order_field} {$order_type}")
            ->paginate($limit);
        $this->success('ok',$res);
    }

    /**
     * 添加评论
     */
    public function add(){
        # 关联模型
        $relation_db = $this->request->param('relation');
        if(!$relation_db) $this->error('请传入评论关联模型!');
        $relationdbs = $this->relationConf();
        if(!isset($relationdbs[$relation_db])){
            $this->error('未知的评论模型!');
        }
        # 关联表ID
        $relation_id = $this->request->param('id');
        if(!$relation_id) $this->error('请传入关联模型ID!');
        
        # 内容
        $content = $this->request->param('content');
        if(!$content) $this->error('请填写评论内容!');
        # 用户ID
        $user_id = $this->auth->id;
        # PID
        $pid = $this->request->param('pid',0);
        # 评分
        $grade = $this->request->param('grade',null);
        # 配图
        $images = $this->request->param('images',null);
        
        $data = [
            'pid' => $pid,
            'relation_db' => $relation_db,
            'relation_id' => $relation_id,
            'user_id' => $user_id,
            'content' => $content,
            'images' => $images,
            'createtime' => time(),
            'nickname' => $this->auth->nickname,
            'avatar' => $this->auth->avatar,
            'support' => 0
        ];

        $res = ModelComments::insert($data);
        if(!$res){
            $this->error('发表失败!');
        }
        $this->success('发表成功!');
    }

    /**
     * 评论点赞
     */
    public function support(){
        $this->auth->id = 1;
        $id = $this->request->param('id');
        if(!$id) $this->error('请选择评论!');
        $is_support = 0;
        $logs = db('CommentsSupport')->where(['comments_id'=>$id,'user_id'=>$this->auth->id])->find();
        if($logs){
            $this->supportDec($id);
            $is_support = 0;
        }else{
            $this->supportInc($id);
            $is_support = 1;
        }
        $this->success('OK',['is_support'=>$is_support]);
    }
    private function supportInc($id){
        $res1 = ModelComments::where(['id'=>$id])->setInc('support',1);
        $res2 = db('CommentsSupport')->insert([
            'comments_id' => $id,
            'user_id' => $this->auth->id,
            'createtime' => time(),
        ]);
        if(!$res1 || !$res2) $this->error("点赞失败!");
    }
    private function supportDec($id){
        $res1 = ModelComments::where(['id'=>$id])->setDec('support',1);
        $res2 = db('CommentsSupport')->where(['comments_id'=>$id,'user_id'=>$this->auth->id])->delete();
        if(!$res1 || !$res2) $this->error("取消点赞失败!");
    }


    /**
     * 我的评论
     */
    public function myComments(){
        $user_id = $this->auth->id;
        $relation_db = $this->request->param('relation');
        if(!$relation_db) $this->error('请传入评论关联模型!');
        $relationdbs = $this->relationConf();
        if(!isset($relationdbs[$relation_db])){
            $this->error('未知的评论模型!');
        }

        $limit = $this->request->param('limit',10);
        $order_field = $this->request->param('order_field','createtime');
        $order_type = $this->request->param('order_type','desc');

        $is_support_sql = '0';
        $this->auth->id = 1;
        if(!is_null($this->auth->id)){
            $is_support_sql = db('CommentsSupport')->where(['user_id'=>$this->auth->id])->where('comments_id=a.id')->field('count(id)')->buildSql();
        }

        $Comment = new ModelComments();
        $res = $Comment->alias('a')
            ->where([
                'relation_db'=>$relation_db,
                'pid' => 0,
                'user_id' => $this->auth->id
            ])
            ->field("id,pid,relation_id,user_id,nickname,avatar,grade,images,support,images,createtime,content,{$is_support_sql} is_support")
            ->order("{$order_field} {$order_type}")
            ->paginate($limit);
        $this->success('ok',$res);
    }
}
