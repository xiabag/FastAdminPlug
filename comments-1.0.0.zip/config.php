<?php

return [
    [
        'name' => 'relationdb',
        'title' => '关联表',
        'type' => 'array',
        'content' => [],
        'value' => [
            'news' => '文章',
            'order' => '订单',
        ],
        'rule' => 'required',
        'msg' => '',
        'tip' => '',
        'ok' => '',
        'extend' => '',
    ],
    [
        'name' => '__tips__',
        'title' => '温馨提示',
        'type' => 'string',
        'content' => [],
        'value' => '多用评论组件,关联表中,key标识无前缀数据表名,value标识可读中文标题',
        'rule' => '',
        'msg' => '',
        'tip' => '',
        'ok' => '',
        'extend' => '',
    ],
];
