CREATE TABLE IF NOT EXISTS `__PREFIX__comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int(11) DEFAULT '0' COMMENT '父ID',
  `relation_db` varchar(32) NOT NULL COMMENT '关联表',
  `relation_id` int(11) NOT NULL COMMENT '关联表ID',
  `user_id` int(11) DEFAULT '0' COMMENT '用户ID',
  `content` varchar(255) NOT NULL COMMENT '评论内容',
  `grade` tinyint(1) DEFAULT '0' COMMENT '评分',
  `images` varchar(2550) DEFAULT NULL COMMENT '配图',
  `createtime` int(10) NOT NULL COMMENT '发表时间',
  `nickname` varchar(32) DEFAULT NULL COMMENT '用户昵称',
  `avatar` varchar(255) DEFAULT NULL COMMENT '用户头像',
  `support` int(10) DEFAULT NULL COMMENT '点赞数量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='评论管理';

CREATE TABLE IF NOT EXISTS `__PREFIX__comments_support` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `comments_id` int(11) NOT NULL COMMENT '文章ID',
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `createtime` int(11) NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='评论点赞记录';