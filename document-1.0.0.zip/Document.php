<?php

namespace addons\document;

use app\common\library\Menu;
use think\Addons;

/**
 * 插件
 */
class Document extends Addons
{

    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        $menu = [
            [
                'name'    => 'document',
                'title'   => '文档管理',
                'icon'    => 'fa fa-newspaper-o',
                'sublist' => [
                    ['name' => 'document/index', 'title' => '查看'],
                    ['name' => 'document/add', 'title' => '添加'],
                    ['name' => 'document/detail', 'title' => '详情'],
                    ['name' => 'document/del', 'title' => '删除'],
                ]
            ]
        ];
        Menu::create($menu);
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        Menu::delete('document');
        return true;
    }

    /**
     * 插件启用方法
     * @return bool
     */
    public function enable()
    {
        Menu::enable('document');
        return true;
    }

    /**
     * 插件禁用方法
     * @return bool
     */
    public function disable()
    {
        Menu::disable('document');
        return true;
    }

}
