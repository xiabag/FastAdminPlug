<?php

return [
    'Id'      => 'ID',
    'Code'    => '类型',
    'Title'   => '标题',
    'Image'   => '图片',
    'Content' => '图文',
    'Tel'     => '电话'
];
