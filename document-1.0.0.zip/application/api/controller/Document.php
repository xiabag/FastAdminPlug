<?php

namespace app\api\controller;

use app\common\controller\Api;

/**
 * 文档管理接口
 */
class Document extends Api
{

    // 无需登录的接口,*表示全部
    protected $noNeedLogin = ['*'];
    // 无需鉴权的接口,*表示全部
    protected $noNeedRight = [];

    /**
     * 文档详情
     */
    public function detail(){
        $type = $this->request->param('type');
        if(!$type) $this->error('请选择要查看的文档类型');
        $codeConf = get_addon_config('document');
        $codeList = $codeConf['code'];
        if(!isset($type,$codeList)) $this->error("非法的文档请求!");
        $res = db('Document')->where(['code'=>$type])->find();
        if(!$res) $this->error('未找到该文档内容');
        $this->success('ok',$res);
    }

}
