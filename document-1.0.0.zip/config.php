<?php

return [
    [
        'name' => 'code',
        'title' => '分类',
        'type' => 'array',
        'content' => [],
        'value' => [
            'bussiness' => '商务合作',
            'about' => '关于我们',
            'agreement' => '用户协议',
            'privacy' => '隐私声明',
        ],
        'rule' => 'required',
        'msg' => '',
        'tip' => '',
        'ok' => '',
        'extend' => '',
    ],
    [
        'name' => '__tips__',
        'title' => '使用说明',
        'type' => 'string',
        'content' => [],
        'value' => '[键] 填写英文CODE,用于接口调用<br>[值] 填写中文名称,便于后台读取',
        'rule' => 'required',
        'msg' => '',
        'tip' => '',
        'ok' => '',
        'extend' => '',
    ],
];
