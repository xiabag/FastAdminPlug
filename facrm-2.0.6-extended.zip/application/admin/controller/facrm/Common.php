<?php

namespace app\admin\controller\facrm;

use app\common\controller\Backend;

/**
 * 共有的一些不需要权限的接口
 * @internal
 */
class Common extends Backend
{
    protected $noNeedRight = ['*'];
    public function _initialize()
    {
        parent::_initialize();
        //设置过滤方法
        $this->request->filter(['trim', 'strip_tags', 'htmlspecialchars']);
    }

    /**
     * 下拉选择
     * @fun
     * @Internal
     */
    public function selectpage(){
        $modellist=['admin'];
        $model = $this->request->param('model');
        if (!$this->request->request('keyField')){
            $this->error("访问出错");
        }
        if (!in_array($model,$modellist))
            $this->error("非法访问");

        $this->model = model($model);
        $type = $this->request->param('type');


        switch ($model){
            case 'admin':
				$custom=['status'=>'normal'];
                if ($type != "all") {
                    $childrenAdminIds = $this->auth->getChildrenAdminIds(true);
					$custom['id']= ['in', $childrenAdminIds];
                }
				 $this->request->request(['custom' => $custom]);
                break;
        }
        return parent::selectpage();
    }

    public function pageList(){
        $pageList = [
            ['path' => '/pages/index/index', 'name' => '首页'],
            ['path' => '/pages/client/index', 'name' => '客户列表'],
            ['path' => '/pages/business/index', 'name' => '商机列表'],
            ['path' => '/pages/presentation/index', 'name' => '数据统计'],
            ['path' => '/pages/clues/index', 'name' => '线索列表'],
            ['path' => '/pages/client/clientSet/clientSet', 'name' => '新建客户'],
            ['path' => '/pages/business/addBusiness/index', 'name' => '新建商机'],
            ['path' => '/pages/contract/index', 'name' => '新建合同'],
            ['path' => '/pages/contract/list/index', 'name' => '合同列表'],
            ['path' => '/pages/receivables/list', 'name' => '回款列表'],
            ['path' => '/pages/backlog/list', 'name' => '待审批列表（?type=0或type=1）'],
            ['path' => '/pages/highSeas/index', 'name' => '公海'],
            ['path' => '/pages/more/index', 'name' => '更多功能'],
            ['path' => '/pages/performance/index', 'name' => '业绩设置'],
            ['path' => '/pages/receivables/manage', 'name' => '新建回款'],

        ];
        $this->view->assign('pageList', $pageList);
        return $this->view->fetch('facrm/common/pages');
    }

}
