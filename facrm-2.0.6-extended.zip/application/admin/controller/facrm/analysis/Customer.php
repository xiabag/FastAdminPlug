<?php

namespace app\admin\controller\facrm\analysis;

use app\common\controller\Backend;
use think\Db;
use think\Exception;
use think\exception\PDOException;
use think\exception\ValidateException;


/**
 *客户分析
 */
class Customer extends Backend
{

    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\facrm\Customer();

    }

    /**
     *
     * 地区分析
     * @return \think\response\Json|void
     */
    public function index()
    {

        $allmap=$dealmap=[];
        $cache_key=md5("allmapdeal_map");

        list($allmap,$dealmap)=cache($cache_key);
        if (!$allmap&&!$dealmap) {
            try {
                //查询所有省份
                $province_list=model('area')->where('level',1)->cache(true)->column('id','shortname');
                foreach ($province_list as $key=>$val){
                    $r['name']=$key;
                    $r['value']= $this->model->where('province',$val)->where('deal_status',1)->count();
                    $dealmap[]=$r;
                    $f['name']=$key;
                    $f['value']= $this->model->where('province',$val)->count();;
                    $allmap[]=$f;
                }
                cache($cache_key,array($allmap,$dealmap),86400);

            }catch (Exception $e){
                $this->error(__("获取地区表和数据失败，查看解决方案：")."https://ask.fastadmin.net/question/17297.html");
            }

        }
        if (!$allmap||!$dealmap){
            $this->error(__("获取地区表和数据失败，查看解决方案：")."https://ask.fastadmin.net/question/17297.html");
        }
        $this->view->assign([
            'allmap'       =>$allmap,
            'dealmap'       =>$dealmap,

        ]);
        return $this->view->fetch();
    }

    /**
     * 行业分析
     */
    public function industry(){
       $config= get_addon_config('facrm');
       $config['industry'][0]='未知';
       $alldata=$dealdata=[];

        $cache_key=md5("industrydealdataalldata");
        list($allmap,$dealmap)=cache($cache_key);
        if (!$alldata&&!$dealdata) {
            foreach ($config['industry'] as $k=>$v){
                $r['name']=$v;
                $r['value']= $this->model->where('industry',$k)->count();
                $alldata[]=$r;
                $f['name']=$v;
                $f['value']= $this->model->where('industry',$k)->where('deal_status',1)->count();;
                $dealdata[]=$f;
            }
            cache($cache_key,array($alldata,$dealdata),86400);
        }



        $this->view->assign([
            'industry'       =>$config['industry'],
            'alldata'=>$alldata,
            'dealdata'=>$dealdata,
        ]);
        return $this->view->fetch();
    }

    /**
     * 级别分析
     */
    public function level(){
        $config= get_addon_config('facrm');
        $config['level'][0]='未知';
        $alldata=$dealdata=[];

        $cache_key=md5("leveldealdataalldata");
        list($alldata,$dealdata)=cache($cache_key);
        if (!$alldata&&!$dealdata) {
            foreach ($config['level'] as $k=>$v){
                $r['name']=$v;
                $r['value']= $this->model->where('level',$k)->count();
                $alldata[]=$r;
                $f['name']=$v;
                $f['value']= $this->model->where('level',$k)->where('deal_status',1)->count();;
                $dealdata[]=$f;
            }
            cache($cache_key,array($alldata,$dealdata),86400);
        }

        $this->view->assign([
            'level'       =>$config['level'],
            'alldata'=>$alldata,
            'dealdata'=>$dealdata,
        ]);
        return $this->view->fetch();
    }

    /**
     * 来源分析
     */
    public function source(){
        $config= get_addon_config('facrm');
        $config['source'][0]='未知';
        $alldata=$dealdata=[];

        $cache_key=md5("sourcedealdataalldata");
        list($alldata,$dealdata)=cache($cache_key);
        if (!$alldata&&!$dealdata) {
            foreach ($config['source'] as $k=>$v){
                $r['name']=$v;
                $r['value']= $this->model->where('source',$k)->count();
                $alldata[]=$r;
                $f['name']=$v;
                $f['value']= $this->model->where('source',$k)->where('deal_status',1)->count();;
                $dealdata[]=$f;
            }
            cache($cache_key,array($alldata,$dealdata),86400);
        }

        $this->view->assign([
            'source'       =>$config['source'],
            'alldata'=>$alldata,
            'dealdata'=>$dealdata,
        ]);
        return $this->view->fetch();
    }
}
