<?php

namespace app\admin\controller\facrm\apps;

use app\common\controller\Backend;
use think\Db;
use think\Exception;
use think\Queue;
use think\Validate;

/**
 * 通知管理
 * @icon fa fa-tags
 */
class Notice extends Backend
{

    protected $key = "notice_tpl_lists";
    protected $addon_config = array();
    protected $noNeedRight = ['selectpage'];
    protected $data_temp = array();

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\facrm\Setting();
        $this->modelList = ['customer' => __('客户'), 'contacts' => __('联系人'),
            'contract' => __('合同'),
            'business' => __('商机'),
            'contract_receivables'=>__('回款'),
			'clues'=>__('线索')
        ];
        $this->data_temp = \addons\facrm\library\notice\Notice::getTempLplData();


    }

    /**
     * 查看列表
     * @return string|\think\response\Json
     * @throws \think\Exception
     */
    public function index()
    {

        if ($this->request->isAjax()) {
            $result = array("total" => count($this->data_temp), "rows" => $this->data_temp);

            return json($result);
        }
        $source = $this->request->param('source', 'customer');
        $this->view->assign('source', $source);
        $this->view->assign('modelList', $this->modelList);
        $this->view->assign('data_temp', $this->data_temp);
        $this->view->assign('notice_types', \addons\facrm\library\notice\Notice::getProviders());
        return $this->view->fetch();
    }
    /**
     * 修改
     * @return mixed
     */
    public function edit($key = null)
    {
        $type = $this->request->param('type');
        if (!$key)
            $this->error(__("选择有误"));
        $newkey = $key . $type;
        $row = $this->model->where('key', $newkey)->find();


        if ($this->request->isPost()) {
            if (!$this->auth->isSuperAdmin()){
                $this->error(__('超级管理员才能编辑'));
            }
            $params = $this->request->post("row/a");
            if ($params) {
                $params['values']['content'] = ($this->request->post("content"));
                $params['values']['engine'] =$type;
                $params = $this->preExcludeFields($params);
                $params['key'] = $newkey;

                $result = false;
                Db::startTrans();
                try {

                    if (!$row) {
                        //添加
                        $result = $this->model->allowField(true)->save($params);
                    } else {
                        //修改
                        $result = $row->allowField(true)->save($params);
                    }

                    Db::commit();
                } catch (Exception $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                }
                if ($result !== false) {
                    $this->success();
                } else {
                    $this->error(__('No rows were updated'));
                }
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }

        if (!$row) {
            foreach ($this->data_temp as $row) {
                if ($row['key'] == $key) break;
            }
        }
        $this->assign('template_data', json_encode((new \app\admin\controller\facrm\apps\Sms())->getfield(
            isset($row['values']['param_type'])?$row['values']['param_type']:'customer', false)));
        $this->addon_config = get_addon_config('facrm');
        $this->view->assign("recordTypeList", $this->addon_config['record_type']);
        $this->view->assign('modelList', $this->modelList);
        $this->view->assign("row", $row);
        return $this->view->fetch(strtolower($type));
    }

    /**
     * 添加
     * @Internal
     * @return mixed
     */
    public function add()
    {
        $this->error();
    }


    /**
     * @Internal
     * @return mixed
     */
    public function del($ids = "")
    {
        $this->error();
    }
    /**
     * @Internal
     * @return mixed
     */
    public function multi($ids = "")
    {
        $this->error();
    }

}