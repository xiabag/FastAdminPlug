<?php

namespace app\admin\controller\facrm\business;

use app\admin\model\facrm\Customer;
use app\common\controller\Backend;
use think\Db;
use think\Exception;
use think\exception\PDOException;
use think\exception\ValidateException;


/**
 *联系人
 */
class Contacts extends Backend
{

    protected $model = null;
    /**
     * 快速搜索时执行查找的字段
     */
    protected $searchFields = 'customer_id,name,mobile,telephone';
    protected $childrenAdminIds = [];
    public function _initialize()
    {
        parent::_initialize();
        $this->model = model('\app\admin\model\facrm\business\Contacts');
        $this->request->filter(['strip_tags']);
    }

    /**
     * 联系人列表
     */
    public function index($business_id = null)
    {
        //设置过滤方法
        $this->request->filter(['strip_tags']);
        if ($this->request->isAjax()) {

            $filter_w = [];

            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField')) {
                $this->request->request(['custom' => $filter_w]);
                return $this->selectpage();
            }
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();
            $total = $this->model
                ->where($where)
                ->where($filter_w)
                ->with([
                    'contact'
                ])
                ->order($sort, $order)->fetchSql(false)
                ->count();
            $list = $this->model
                ->where($where)
                ->where($filter_w)
                ->with([
                    'contact'
                ])
                ->order($sort, $order)
                ->limit($offset, $limit)->fetchSql(false)
                ->select();
            $result = array("total" => $total, "rows" => $list);

            return json($result);
        }
        $this->error(__('访问出错'));
        return $this->view->fetch();
    }

    /**
     * 关联联系人
     */
    public function correlation($customer_id = null){
        if ($this->request->isAjax()) {
            if ($this->request->post("type")=="bind"){
                //关联提交
                $contacts_ids=$this->request->post("contacts_ids");
                $business_id=$this->request->post("business_id");
                if (!$business_id) $this->error(__("商机信息参数不存在"));
                $businessModel = model('\app\admin\model\facrm\Business');
                $row =$businessModel->get($business_id);
                if (!$row) {
                    $this->error(__('No Results were found'));
                }


                $this->childrenAdminIds = $this->auth->getChildrenAdminIds(true);
                if (!in_array($row['owner_user_id'], $this->childrenAdminIds)) {
                    $this->error(__('You have no permission'));
                }
                //查询客户联系人的合法性
                $row_c=Customer::get($row['customer_id'],['contacts'=>function($contacts) use($contacts_ids) {
                    $contacts->where('id','in',$contacts_ids);
                }]);
                if (!$row_c->contacts){
                    $this->error(__('选择的联系方式不存在'));
                }
                $insert_data=[];
                foreach ($row_c->contacts  as $r){
                    $temp['business_id']=$business_id;
                    $temp['contacts_id']=$r->id;
                    $insert_data[]=$temp;
                }
                $this->model->saveAll($insert_data);
                $this->success(__("关联成功"));
            }else{
                //选择联系人数据
                $customerContacts=new \app\admin\controller\facrm\customer\Contacts();
                return $customerContacts->index($customer_id);
            }

        }
        return $this->view->fetch();
    }

    /**
     * 添加联系人
     * @return mixed
     */
    public function add($customer_id = null)
    {
        $customer = model('\app\admin\model\facrm\Customer');
        $row = $customer->get($customer_id);

        if (!$row)
            $this->error(__('No Results were found'));
        $adminIds = $this->getDataLimitAdminIds();
        if (is_array($adminIds)) {
            if (!in_array($row[$this->dataLimitField], $adminIds)) {
                $this->error(__('You have no permission'));
            }
        }
        $this->childrenAdminIds = $this->auth->getChildrenAdminIds(true);
        if (!in_array($row['owner_user_id'], $this->childrenAdminIds)) {
            $this->error(__('You have no permission'));
        }

        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
            $params['next_time']=$params['next_time']?strtotime($params['next_time']):0;
            $this->request->post(['row' => array_merge($params,[
                'create_user_id'=>$this->auth->id,
                'owner_user_id'=>$row->owner_user_id,
                'customer_id'=>$row->id,
                'types'=>'customer',
            ])]);
        } else {
            $this->view->assign("row", $row);
        }

        return parent::add();
    }

    /**
     * 修改联系人
     * @param null $ids
     * @return mixed
     */
    public function edit($ids = NULL)
    {
        $row = $this->model->get($ids);
        if (!$row) {
            $this->error(__('No Results were found'));
        }
        $adminIds = $this->getDataLimitAdminIds();
        if (is_array($adminIds)) {
            if (!in_array($row[$this->dataLimitField], $adminIds)) {
                $this->error(__('You have no permission'));
            }
        }


        $this->childrenAdminIds = $this->auth->getChildrenAdminIds(true);
        if (!in_array($row['owner_user_id'], $this->childrenAdminIds)) {
            $this->error(__('You have no permission'));
        }

        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
            $params['next_time']=$params['next_time']?strtotime($params['next_time']):'0';
            $params= array_merge($params,[
                'next_time'=> $params['next_time'],
            ]);
            if ($params) {
                $params = $this->preExcludeFields($params);
                $result = false;
                Db::startTrans();
                try {
                    //是否采用模型验证
                    if ($this->modelValidate) {
                        $name = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                        $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.edit' : $name) : $this->modelValidate;
                        $row->validateFailException(true)->validate($validate);
                    }
                    $result = $row->allowField(true)->save($params);
                    Db::commit();
                } catch (ValidateException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (PDOException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (Exception $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                }
                if ($result !== false) {
                    $this->success();
                } else {
                    $this->error(__('No rows were updated'));
                }
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }
        $this->view->assign("row", $row);
        return $this->view->fetch();
    }


}
