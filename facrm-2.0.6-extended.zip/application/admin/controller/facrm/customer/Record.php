<?php

namespace app\admin\controller\facrm\customer;

use app\common\controller\Backend;
use think\Db;
use think\Exception;
use think\exception\PDOException;


/**
 *跟进记录
 */
class Record extends Backend
{

    protected $model = null;
    /**
     * 快速搜索时执行查找的字段
     */
    protected $searchFields = 'content';
    protected $childrenAdminIds = [];
    private $types = "customer";

    public function _initialize()
    {
        parent::_initialize();
        $this->model = model('\app\admin\model\facrm\Record');
        $this->request->filter(['strip_tags']);
    }

    /**
     * 跟进记录
     */
    public function index($customer_id = null)
    {
        //设置过滤方法
        $this->request->filter(['strip_tags']);
        $scene = model('\app\admin\model\facrm\Scene');
        $scene_list = $scene->where('types', 'contacts')
            ->where(function ($query) {
                $query->where('admin_id', 0)->whereor('admin_id', $this->auth->id);
            })
            ->column('id,name');
        if ($this->request->isAjax()) {

            $filter = $this->request->get("filter", '');
            $filter = (array)json_decode($filter, true);
            $filter_w = [];
            $filter_w['create_user_id'] = $this->auth->id;
            if (isset($filter['scene_id'])) {
                if (!isset($scene_list[$filter['scene_id']])) {
                    $this->error(__("您没有权限"));
                }
                $filter_w['create_user_id'] = $this->auth->id;
                switch ($filter['scene_id']) {
                    case 4:
                        $this->childrenAdminIds = $this->auth->getChildrenAdminIds(true);
                        if ($this->childrenAdminIds)
                            $filter_w['create_user_id'] = ['in', $this->childrenAdminIds];
                        break;
                    case 5:
                        //我的
                        $filter_w['create_user_id'] = $this->auth->id;
                        break;
                    case 6:
                        //下属
                        $this->childrenAdminIds = $this->auth->getChildrenAdminIds(false);
                        if ($this->childrenAdminIds)
                            $filter_w['create_user_id'] = ['in', $this->childrenAdminIds];

                        break;
                    default://其它的还做TODO
                        $filter_w['create_user_id'] = $this->auth->id;

                }

                unset($filter['scene_id']);
                $this->request->get(['filter' => json_encode($filter)]);

            }

            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField')) {
                return $this->selectpage();
            }
            $filter_w['types'] = $this->types;

            if ($customer_id) {
                $filter_w['types_id'] = $customer_id;
                //判断是否有该客户的权限
                $auth = new \addons\facrm\library\Auth();
                if (!$auth->checkCustomerAuth($customer_id, $this->auth)) {
                    $this->error(__('您没有权限'));
                }
            }elseif (!$customer_id&& !$filter_w['create_user_id']){
                $this->error(__('您没有权限'));
            }

            list($where, $sort, $order, $offset, $limit) = $this->buildparams();

            $total = $this->model
                ->where($where)
                ->where($filter_w)
                ->order($sort, $order)->fetchSql(false)
                ->count();
            $list = $this->model
                ->where($filter_w)
                ->where($where)
                ->with([
                    'createUser' => function ($user) {
                        $user->field('id,username,nickname');
                    },
                    'customer' => function ($customer) {
                        $customer->field('id,name');
                    },
                    'files' => function ($files) {
                        $files->field('id,url,record_id');
                    },
                ])
                ->order($sort, $order)
                ->limit($offset, $limit)->fetchSql(false)
                ->select();
            $result = array("total" => $total, "rows" => $list);

            return json($result);
        }
        $config = get_addon_config('facrm');
        $this->view->assign("record_type_list", $config['record_type']);
        $this->view->assign("scene_list", $scene_list);
        return $this->view->fetch();
    }

    /**
     * 添加跟进
     * @return mixed
     */
    public function add($ids = null)
    {
        $customer = model('\app\admin\model\facrm\Customer');
        $row = $customer->get($ids);
        if (!$row)
            $this->error(__('No Results were found'));

        $auth = new \addons\facrm\library\Auth();
        if (!$auth->checkCustomerAuth($ids, $this->auth)) {
            $this->error(__('您没有权限1'));
        }
        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
            $params['next_time'] = $params['next_time'] ? strtotime($params['next_time']) : 0;

            $params = array_merge($params, [
                'create_user_id' => $this->auth->id,
                'types_id' => $row->id,
                'types' => $this->types,
            ]);
            $name = str_replace("\\model\\", "\\validate\\", get_class( $this->model));
            $result = $this->model->allowField(true)->validateFailException(false)->validate($name . '.add')->save($params);
            if(false === $result){
                // 验证失败 输出错误信息
                $this->error( $this->model->getError());
            }

            //更新客户表
            $row->next_time = $params['next_time'];
            $row->follow_time = time();
            $row->save();

            //如果存在附件
            if ($params['image']) {
                $images = explode(",", $params['image']);
                $files_data = array();
                foreach ($images as $key => $v) {
                    $files_data[$key]['url'] = $v;
                    $files_data[$key]['types_id'] = $row->id;
                    $files_data[$key]['types'] = $this->types;
                }
                $this->model->files()->saveAll($files_data);
            }
            return $this->success(__('跟进成功'));
        } else {
            $config = get_addon_config('facrm');
            $this->view->assign("levelList", $config['level']);
            $this->view->assign("industryList", $config['industry']);
            $this->view->assign("sourceList", $config['source']);
            $this->view->assign("record_type_list", $config['record_type']);
            $this->view->assign("row", $row);
        }

        $payConfig=\addons\facrm\library\Order::getPayConfig();
        $this->assignconfig('payConfig', ($payConfig?$payConfig['values']:[]));
        $this->view->assign("row", $row);
        return $this->view->fetch();
    }

    /**
     * 删除
     * @param string $ids
     */
    public function del($ids = "")
    {
        if ($ids) {
            $pk = $this->model->getPk();
            $adminIds = $this->getDataLimitAdminIds();
            if (is_array($adminIds)) {
                $this->model->where($this->dataLimitField, 'in', $adminIds);
            }


            $this->childrenAdminIds = $this->auth->getChildrenAdminIds(true);
            if (is_array($adminIds)) {
                $this->model->where($this->dataLimitField, 'in', $adminIds);
            }
            $list = $this->model->where($pk, 'in', $ids)->where('create_user_id', 'in', $this->childrenAdminIds)->select();


            $count = 0;
            Db::startTrans();
            try {
                foreach ($list as $k => $v) {
                    $count += $v->delete();
                }
                Db::commit();
            } catch (PDOException $e) {
                Db::rollback();
                $this->error($e->getMessage());
            } catch (Exception $e) {
                Db::rollback();
                $this->error($e->getMessage());
            }
            if ($count) {
                $this->success();
            } else {
                $this->error(__('No rows were deleted'));
            }
        }
        $this->error(__('Parameter %s can not be empty', 'ids'));
    }

    /**
     *附件查看
     */
    public function files($ids = "")
    {
        //判断是否有权限
        $auth = new \addons\facrm\library\Auth();
        if ($this->request->isAjax()) {
            $customer_id = $this->request->param("customer_id");
            $filter_w['types'] = $this->types;
            if (!$customer_id) {
                $this->error(__('客户不存在'));
            }
            $filter_w['types_id'] = $customer_id;
            if (!$auth->checkCustomerAuth($customer_id, $this->auth)) {
                $this->error(__('您没有权限'));
            }

            $this->model = model('\app\admin\model\facrm\record\Files');
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();
            $total = $this->model
                ->where($where)
                ->where($filter_w)
                ->order($sort, $order)->fetchSql(false)
                ->count();
            $list = $this->model
                ->where($where)
                ->where($filter_w)
                ->order($sort, $order)
                ->limit($offset, $limit)->fetchSql(false)
                ->select();
            $cdnurl = preg_replace("/\/(\w+)\.php$/i", '', $this->request->root());
            foreach ($list as $k => &$v) {
                $v['fullurl'] = cdnurl($v['url']);
                $v['imagetype'] = pathinfo($v['url'], PATHINFO_EXTENSION);
            }
            unset($v);
            $result = array("total" => $total, "rows" => $list);
            return json($result);

        }
        $row = $this->model->get($ids, ['files']);
        if (!$row) $this->error(__('数据不存在'));

        if (!$auth->checkCustomerAuth($row->types_id, $this->auth)) {
            $this->error(__('您没有权限'));
        }

        $this->view->assign("row", $row);
        return $this->view->fetch();
    }

}
