<?php

namespace app\admin\controller\facrm\flow;

use app\common\controller\Backend;
use app\admin\model\AuthGroup;
use app\admin\model\AuthGroupAccess;
use fast\Tree;
use think\Db;
use think\Exception;
use think\exception\PDOException;
use think\exception\ValidateException;

/**
 * 审批流程
 * @icon fa fa-circle-o
 */
class Index extends Backend {

    /**
     * flow模型对象
     * @var \app\admin\model\facrm\Flow
     */
    protected $model = null;
    protected $distinguish = true;


    public function _initialize()
    {
        parent::_initialize();
        $this->model = model('\app\admin\model\facrm\Flow');
        $this->request->filter(['strip_tags']);

    }
    /**
     * 添加
     * @return mixed
     */
    public function add()
    {
        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
            $params = $this->preExcludeFields($params);
            if ($this->dataLimit && $this->dataLimitFieldAutoFill) {
                $params[$this->dataLimitField] = $this->auth->id;
            }
            $result = false;
            Db::startTrans();
            try {
                //是否采用模型验证
                if ($this->modelValidate) {
                    $name = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                    $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.add' : $name) : $this->modelValidate;
                    $this->model->validateFailException(true)->validate($validate);
                }
                $result = $this->model->allowField(true)->save($params);
                //如果是固定审批就添加步骤
                if ($params['config']==1){
                    $step_data = ($this->request->post("step/a"));
                    $flow_id = $this->model->id;
                    $i=1;
                    foreach ($step_data as &$row) {
                        $row['flow_id'] = $flow_id;
                        if ($row['type']==2&&$row['admin_ids']==""){
                            //指定人员
                            exception("请选择指定人员:第".($i)."行");
                        }else if ($row['type']==1){
                            $row['admin_ids']="";
                        }
                        $i++;
                    }
                    $this->model->step()->saveAll($step_data);
                }

                Db::commit();
            } catch (ValidateException $e) {
                Db::rollback();
                $this->error($e->getMessage());
            } catch (PDOException $e) {
                Db::rollback();
                $this->error($e->getMessage());
            } catch (Exception $e) {
                Db::rollback();
                $this->error($e->getMessage());
            }
            if ($result !== false) {
                $this->success();
            } else {
                $this->error(__('No rows were inserted'));
            }
        }
        return $this->view->fetch();
    }

    /**
     * 修改
     * @return mixed
     */
    public function edit($ids=NUll)
    {
        $row = $this->model->get($ids);
        if (!$row) {
            $this->error(__('No Results were found'));
        }

        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
            $params = $this->preExcludeFields($params);
            if ($this->dataLimit && $this->dataLimitFieldAutoFill) {
                $params[$this->dataLimitField] = $this->auth->id;
            }
            $result = false;
            Db::startTrans();
            try {
                //是否采用模型验证
                if ($this->modelValidate) {
                    $name = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                    $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.add' : $name) : $this->modelValidate;
                    $this->model->validateFailException(true)->validate($validate);
                }
                $flow_id = $row->id;
                $result =$row->allowField(true)->save($params);
                $stepModel = model('\app\admin\model\facrm\flow\Step');
                $this->model->step()->where('flow_id', $flow_id)->delete();
                //如果是固定审批就添加步骤
                if ($params['config']==1){
                    $step_data = ($this->request->post("step/a"));
                    $i=1;
                    foreach ($step_data as &$row) {
                        $row['flow_id'] = $flow_id;
                        if ($row['type']==2&&$row['admin_ids']==""){
                            //指定人员
                            exception("请选择指定人员:第".($i)."行");
                        }else if ($row['type']==1){
                            $row['admin_ids']="";
                        }
                        $i++;
                    }
                    $stepModel->saveAll($step_data);
                }

                Db::commit();
            } catch (ValidateException $e) {
                Db::rollback();
                $this->error($e->getMessage());
            } catch (PDOException $e) {
                Db::rollback();
                $this->error($e->getMessage());
            } catch (Exception $e) {
                Db::rollback();
                $this->error($e->getMessage());
            }
            if ($result !== false) {
                $this->success();
            } else {
                $this->error(__('No rows were inserted'));
            }
        }
        $this->view->assign("row", $row);
        $this->view->assign("step_list", $row->step);
        return $this->view->fetch();
    }
}
