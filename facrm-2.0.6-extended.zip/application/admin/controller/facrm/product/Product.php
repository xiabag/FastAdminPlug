<?php

namespace app\admin\controller\facrm\product;

use app\common\controller\Backend;
use app\admin\model\facrm\product\Type;
use app\admin\model\facrm\product\Unit;

/**
 * 商品信息
 * @icon fa fa-circle-o
 */
class Product extends Backend {

    /**
     * Product模型对象
     * @var \app\admin\model\facrm\product\Product
     */
    protected $model = null;
    protected $distinguish = true;
    protected $searchFields = 'id,name,specification,sku,prop';
    public function _initialize() {
        parent::_initialize();
        $this->model = new \app\admin\model\facrm\product\Product;
        $this->request->filter(['strip_tags']);
    }

    /**
     * 获取商品类型列表
     */
    public function get_type_list() {
        $result = array("rows" => [], "total" => 0);
        if ($this->request->isAjax()) {
            if ($this->request->request("keyValue")) {
                $id = $this->request->request("keyValue");
                $type = new Type();
                $list = $type
                        ->field("id,name")
                        ->where("id", $id)
                        ->select();
                return ['total' => 1, 'list' => $list];
            }
            $type = new Type();
            $list = $type
                    ->field("id,name")
                    ->select();
            $count = $type
                    ->field("id,name")
                    ->count();
            $result = array("rows" => $list, "total" => $count);
            return json($result);
        }
        return json($result);
    }

    /**
     * 获取当前商品选择类型的属性
     */
    public function get_type_prop() {
        $type_id = $this->request->param('type_id');
        if ($this->request->isAjax()) {
            $type = new Type();
            $list = $type
                    ->field("prop")
                    ->where('id', $type_id)
                    ->find();
            return $list['prop'];
        }
    }

    /**
     * 获取单位列表
     */
    public function get_unit_list() {
        $result = array("rows" => [], "total" => 0);
        if ($this->request->isAjax()) {
            if ($this->request->request("keyValue")) {
                $id = $this->request->request("keyValue");
                $unit = new Unit();
                $list = $unit
                        ->field("id,name")
                        ->where("id", $id)
                        ->select();
                return ['total' => 1, 'list' => $list];
            }
            $unit = new Unit();
            $list = $unit
                    ->field("id,name")
                    ->select();
            $count = $unit
                    ->field("id,name")
                    ->count();
            $result = array("rows" => $list, "total" => $count);
            return json($result);
        }
        return json($result);
    }

}
