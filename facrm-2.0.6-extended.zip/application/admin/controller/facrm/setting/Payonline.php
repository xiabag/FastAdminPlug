<?php

namespace app\admin\controller\facrm\setting;

use app\common\controller\Backend;
use think\Db;
use think\Exception;
use think\Queue;
use think\Validate;

/**
 * 线上付款
 * @icon fa fa-tags
 */
class Payonline extends Backend
{

    protected $key = "payonline";
    protected $addon_config = array();
    protected $noNeedRight = ['selectpage'];
    protected $data_temp = array();

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\facrm\Setting();
        $config = get_addon_config('facrm');
        $this->view->assign("account_list", $config['account']);
        $this->assignconfig("account_list", $config['account']);
    }


    /**
     * 查看修改
     * @return mixed
     */
    public function index()
    {
        $row = $this->model->where('key', $this->key)->find();

        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");

            if ($params) {
                $params['key'] = $this->key;
                $params['describe'] = "在线支付配置";
                $result = false;
                //是否开启合同续费，开启就需要增加字段
                $fieldsModel=new \app\admin\model\facrm\Fields();
                if ($params['values']['renew_pay']==1&&!$fieldsModel->where('source','contract')->where('name','renewtoken')->count()){
                    //增加续费字段，续费访问

                    $fieldsModel->allowField(true)->saveAll([
                        ['source'=>'contract','name'=>'totalday','title'=>'续期总天','type'=>'number','defaultvalue'=>0,'decimals'=>'0','length'=>11,'extend'=>'disabled','status'=>'hidden','content'=>''],
                        ['source'=>'contract','name'=>'totalrenew','title'=>'续期总额','type'=>'number','defaultvalue'=>0,'decimals'=>'2','length'=>10,'extend'=>'disabled','status'=>'hidden','content'=>''],
                        ['source'=>'contract','name'=>'renewtoken','title'=>'续期访问凭证','type'=>'string','defaultvalue'=>'','decimals'=>'0','length'=>200,'extend'=>'disabled','status'=>'hidden','content'=>''],
                        ['source'=>'contract','name'=>'renewmoeny','title'=>'续期单价','type'=>'number','defaultvalue'=>0,'decimals'=>'2','length'=>10,'rule'=>'','status'=>'normal','content'=>'']
                    ]);

                }
                Db::startTrans();
                try {

                    if (!$row) {
                        //添加
                        $result = $this->model->allowField(true)->save($params);
                    } else {
                        //修改
                        $result = $row->allowField(true)->save($params);
                    }

                    Db::commit();
                } catch (Exception $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                }
                if ($result !== false) {
                    $this->success();
                } else {
                    $this->error(__('No rows were updated'));
                }
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }

        $this->view->assign("row", $row);
        $this->view->assign("key", $this->key);
        return $this->view->fetch();
    }



    /**
     * 添加
     * @Internal
     * @return mixed
     */
    public function add()
    {
        $this->error();
    }


    /**
     * @Internal
     * @return mixed
     */
    public function del($ids = "")
    {
        $this->error();
    }
    /**
     * @Internal
     * @return mixed
     */
    public function multi($ids = "")
    {
        $this->error();
    }

}