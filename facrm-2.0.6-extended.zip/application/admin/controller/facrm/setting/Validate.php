<?php

namespace app\admin\controller\facrm\setting;

use app\common\controller\Backend;
use think\Db;
use think\Exception;


/**
 * 系统字段校验
 * @icon fa fa-tags
 */
class Validate extends Backend
{

    protected $key = "validate_tpl_";
    protected $addon_config = array();
    protected $noNeedRight = ['selectpage','getfield'];
    protected $data_fields = [
        'customer'=>[
            'name'=>'客户名称',
            'telephone'=>'电话',
            'mobile'=>'手机',
            'province'=>'省份',
            'city'=>'城市',
            'area'=>'区域',
            'detail_address'=>'详细地址',
        ],
        'clues'=>[
            'name'=>'客户名称',
            'telephone'=>'电话',
            'mobile'=>'手机',
            'province'=>'省份',
            'city'=>'城市',
            'area'=>'区域',
            'detail_address'=>'详细地址',
        ],
        'contacts'=>[
            'name'=>'名称',
            'telephone'=>'电话',
            'mobile'=>'手机',
            'birthday'=>'生日',
            'wechat'=>'微信',
            'email'=>'邮箱',
            'post'=>'职务',
            'detail_address'=>'地址',
        ],
    ];

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\facrm\Setting();


    }

    /**
     * 查看列表
     * @return string|\think\response\Json
     * @throws \think\Exception
     */
    public function index()
    {

        return $this->view->fetch();
    }
    /**
     * 修改
     * @return mixed
     */
    public function edit($key = null)
    {
        if (!$key)
            $this->error(__("选择有误"));
        $newkey = $this->key.$key ;
        $row = $this->model->where('key', $newkey)->find();


        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");

            if ($params) {
                $insert_data['describe'] = '系统字段自定义验证';
                $insert_data['values'] = $params;
                $insert_data['key'] = $newkey;

                $result = false;
                Db::startTrans();
                try {

                    if (!$row) {
                        //添加
                        $result = $this->model->allowField(true)->save($insert_data);
                    } else {
                        //修改
                        $result = $row->allowField(true)->save($insert_data);
                    }

                    Db::commit();
                } catch (Exception $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                }
                if ($result !== false) {
                    $this->success();
                } else {
                    $this->error(__('No rows were updated'));
                }
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }


        $this->view->assign("row", $row);
        $this->view->assign("data_fields", $this->data_fields);

        return $this->view->fetch();
    }


    /**
     * 添加
     * @Internal
     * @return mixed
     */
    public function add()
    {
        $this->error();
    }


    /**
     * @Internal
     * @return mixed
     */
    public function del($ids = "")
    {
        $this->error();
    }
    /**
     * @Internal
     * @return mixed
     */
    public function multi($ids = "")
    {
        $this->error();
    }

}