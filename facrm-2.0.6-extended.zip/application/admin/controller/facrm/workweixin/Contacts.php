<?php

namespace app\admin\controller\facrm\workweixin;

use app\admin\model\Admin;
use app\common\controller\Backend;
use EasyWeChat\Factory;

use  app\admin\model\facrm\qywx\User as QywxUser;

use  app\admin\model\facrm\qywx\Contacts as Qywxontacts;


/**
 * 微信客户管理
 * @icon fa fa-circle-o
 */
class Contacts extends Backend
{

    protected $model = null;
    protected $distinguish = true;


    public function _initialize()
    {
        parent::_initialize();
        $this->request->filter(['strip_tags']);
        $this->model=(new Qywxontacts());

    }

    /**
     * 查看列表
     * @return string|\think\response\Json
     * @throws \think\Exception
     */
    public function index()
    {
        //设置过滤方法
        $this->request->filter(['strip_tags']);
        if ($this->request->isAjax()) {
            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField')) {
                return $this->selectpage();
            }

            list($where, $sort, $order, $offset, $limit) = $this->buildparams();
            $total = $this->model
                ->where($where)
                ->order($sort, $order)->fetchSql(false)
                ->count();
            $list = $this->model
                ->where($where)
                ->field('weigh',true)
                ->with([
                    'customer' => function ($customer) {
                        $customer->with(['ownerUser'=> function ($user) {
                            $user->field('id,username,nickname');
                        }])->field('id,name,owner_user_id');
                    },
                ])
                ->order($sort, $order)
                ->limit($offset, $limit)->fetchSql(false)
                ->select();
            $result = array("total" => $total, "rows" => $list);

            return json($result);
        }
        return $this->view->fetch();
    }


    /**
     * 同步客户
     */
    public function syn()
    {
        //请提前同步好企业员工再同步客户
        set_time_limit(0);
        $key = "work_weixin_set";
        $settingModel = new \app\admin\model\facrm\Setting();
        $row = $settingModel->where('key', $key)->find();
        if (!$row) $this->error(__("企业微信未配置"));
        $values = json_decode($row['values'], true);//获取器不知道为什么失效了
        if (!$values) $this->error(__("企业微信未配置1"));

        $c_config = [
            'corp_id' => $values['corp_id'],
            'secret' => $values['customer_secret'], // 客户的 secret
        ];
        $qywxUserModel = new QywxUser();
        $userList = $qywxUserModel->select();
        $appc = Factory::work($c_config);
        $contactsModel = new \app\admin\model\facrm\qywx\Contacts();

        foreach ($userList as $row) {
            //TODO 由于easywechat4 里面还没有批量获取，只能一条条获取，到时候自己写
            $externalList = $appc->external_contact->list($row['userid']);
            if (!$externalList || $externalList['errcode'] != '0' || !$externalList['external_userid']) continue;
            foreach ($externalList['external_userid'] as $external_userid) {
                $contactsModel->getContacts($external_userid,$values,['admin_id'=>$row['admin_id']]);
            }
        }
        $this->success();

    }


}
