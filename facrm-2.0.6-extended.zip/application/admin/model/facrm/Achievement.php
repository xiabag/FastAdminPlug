<?php

namespace app\admin\model\facrm;

use app\admin\model\facrm\contract\Receivables;
use think\Model;
use traits\model\SoftDelete;
use function fast\e;

class Achievement extends Model
{

    // 表名
    protected $name = 'facrm_achievement';


    /**
     * 业绩指标
     * @param $config 1=>'合同金额',2=>'回款金额'
     * @param $year 年份
     * @param $month 1~12月份 0代表年份
     * @param $type 2部门3员工
     * @param $type_id 对应type对象ID
     * @param $admin_id int or arrray
     * @return array
     */
    public function achievement($config, $year, $month, $type, $type_id, $admin_id)
    {
        $config_arr = [1 =>__('合同金额') , 2 =>__('回款金额')];
        $month_arr = [0 => 'yeartarget', 1 => "january", 2 => "february", 3 => "march", 4 => "april", 5 => "may", 6 => "june"
            , 7 => "july", 8 => "august", 9 => "september", 10 => "october", 11 => "november", 12 => "december"
        ];
        if (!isset($month_arr[$month]) || !isset($config_arr[$config])) {
            $this->error=__("参数有误");
            return  false;
        }

        if (!is_numeric($year)) {
            $this->error=__("年份有误");
            return  false;
        }
        //获取已完成情况
        //当天开始时间
        list($start_time, $end_time) = $this->mFristAndLast($year, $month);
        //获取业绩目标
        if ($type == 3) {
            //员工业绩
            $yeartarget = $this->where('type', $type)->where('type_id', $type_id)
                ->where('config', $config)
                ->where('year', $year)->value($month_arr[$month]);
            $contract_money = Contract::where('check_status', 2)->where('order_admin_id', $admin_id)
                ->where('order_time', 'between', [$start_time, $end_time])
                ->sum('money');
            $receivables_money = Receivables::where('check_status', 2)->where('order_admin_id', $admin_id)
                ->where('return_time', 'between', [$start_time, $end_time])
                ->sum('money');
        } else {
            //部门业绩
            $yeartarget = $this->where('type', $type)->where('type_id', 'in', $type_id)
                ->where('config', $config)
                ->where('year', $year)->sum($month_arr[$month]);
            $contract_money = Contract::where('check_status', 2)->where('order_admin_id', 'in', $admin_id)
                ->where('order_time', 'between', [$start_time, $end_time])
                ->sum('money');
            $receivables_money = Receivables::where('check_status', 2)->where('order_admin_id', 'in', $admin_id)
                ->where('return_time', 'between', [$start_time, $end_time])
                ->sum('money');
        }

        $achievement = [
            'name' => $config_arr[$config],
            'year' => $year,
            'month' => $month,
            'yeartarget' => $yeartarget ? $yeartarget : 0,
            'contract_money' => $contract_money,
            'receivables_money' => $receivables_money,
            'complete_percent' => $yeartarget > 0 ? round($contract_money / $yeartarget * 100, 2) : 0,
        ];

        return $achievement;

    }

    /**
     * 业绩指标
     * @param $config 1=>'合同金额',2=>'回款金额'
     * @param $start_time 开始时间
     * @param $end_time 截止时间
     * @param $type 2部门3员工
     * @param $type_id 对应type对象ID
     * @param $admin_id int or arrray
     * @return array
     */
    public function getAchievement($config, $start_time, $end_time, $type, $type_id, $admin_id)
    {
        $config_arr = [1 =>__('合同金额') , 2 =>__('回款金额')];
        $month_arr = [0 => 'yeartarget', 1 => "january", 2 => "february", 3 => "march", 4 => "april", 5 => "may", 6 => "june"
            , 7 => "july", 8 => "august", 9 => "september", 10 => "october", 11 => "november", 12 => "december"
        ];
        //获取开始年月和结束月份
        if (!is_numeric($start_time)){
            $start_time=strtotime($start_time);
        }

        if (!is_numeric($end_time)){
            $end_time=strtotime($end_time);
        }
        if ($start_time>$end_time){
            $this->error=__("开始时间不能大于结束时间");
            return  false;
        }
        //格式化，取出月份；
        $year=date('Y',$start_time);
        $s_month=intval(date('m',$start_time));
        $e_month=intval(date('m',$end_time));

        $month_field="";
        if ($s_month==$e_month){
            $month_field=$month_arr[$s_month];
        }else{
            for ($x=$s_month; $x<=$e_month; $x++) {
                $month_field?$month_field."+`{$month_arr[$x]}`":$month_arr[$x];
            }
        }

        //获取业绩目标
        if ($type == 3) {
            //员工业绩
			$type_id=$type_id?$type_id:$admin_id;
		
            $yeartarget = $this->where('type', $type)->where('type_id','in', $type_id)
                ->where('config', $config)
                ->where('year', $year)->sum($month_field);
            $contract_money = Contract::where('check_status', 2)->where('order_admin_id','in', $admin_id)
                ->where('order_time', 'between', [$start_time, $end_time])
                ->sum('money');
            $receivables_money = Receivables::where('check_status', 2)->where('order_admin_id','in', $admin_id)
                ->where('return_time', 'between', [$start_time, $end_time])
                ->sum('money');
        } else {
            //部门业绩
            $yeartarget = $this->where('type', $type)->where('type_id', 'in', $type_id)
                ->where('config', $config)
                ->where('year', $year)->sum($month_field);
            $contract_money = Contract::where('check_status', 2)->where('order_admin_id', 'in', $admin_id)
                ->where('order_time', 'between', [$start_time, $end_time])
                ->sum('money');
            $receivables_money = Receivables::where('check_status', 2)->where('order_admin_id', 'in', $admin_id)
                ->where('return_time', 'between', [$start_time, $end_time])
                ->sum('money');
        }

        $achievement = [
            'name' => $config_arr[$config],
            'year' => $year,
            's_month' => $s_month,
            'e_month' => $e_month,
            'yeartarget' => $yeartarget ? $yeartarget : 0,
            'contract_money' => $contract_money,
            'receivables_money' => $receivables_money,
            'complete_percent' => $yeartarget > 0 ? round($contract_money / $yeartarget * 100, 2) : 0,
        ];
		if($config==1){
			$achievement['complete_percent']=$yeartarget > 0 ? round($contract_money / $yeartarget * 100, 2) : 0;
		}else{
			$achievement['complete_percent']=$yeartarget > 0 ? round($receivables_money / $yeartarget * 100, 2) : 0;
		}

        return $achievement;
    }

    /**
     * 获取时间的开始和结束时间
     * @param int $y
     * @param int $m
     * @return array
     */
    private function mFristAndLast($y = 0, $m = 0)
    {

        $y = $y ? $y : date('Y');
        $e_m = $m ? $m : 12;//如果月份不存在说明想获取一整年，取结束月份为12月
        $m = $m ? $m : 1;//如果月份不存在说明想获取一整年，取开始月份为1月
        $d = date('t', strtotime($y . '-' . $m));
        return array(strtotime($y . '-' . $m), mktime(23, 59, 59, $e_m, $d, $y));
    }




}