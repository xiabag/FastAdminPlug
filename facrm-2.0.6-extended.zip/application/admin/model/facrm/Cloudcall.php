<?php
namespace app\admin\model\facrm;
use think\Cache;
use think\Model;

/**
 * 坐席管理
 */
class Cloudcall extends Model
{
	protected $name = 'facrm_cloudcall';
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';
    // 定义时间戳字段名
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';


    /**
     * 关联员工
     */
    public function admin()
    {
        return $this->hasOne('app\admin\model\Admin', 'id', 'admin_id');
    }




}