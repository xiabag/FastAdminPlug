<?php

namespace app\admin\model\facrm;


use think\Model;
use traits\model\SoftDelete;

/**
 * 线索模型
 * Class Clues
 * @package app\admin\model\facrm
 */
class Clues extends Model
{
    use SoftDelete;

    // 表名
    protected $name = 'facrm_clues';
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = true;
    // 定义时间戳字段名
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $deleteTime = 'delete_time';

    const REMINDDAY = 3;//提醒时间

    protected static function init()
    {
        $forfun = function (&$row) {
            foreach ($row->data as $k => $v) {
                //数组的字段处理成字符串,主要处理是自定义字段多选的值
                if (!empty($v) && is_array($v)) $row->data[$k] = implode(',', $v);
            }
        };
        /**
         * 插入前
         */
        self::beforeInsert(function ($row) use ($forfun) {
            $forfun($row);
        });
        /**
         * 更新前
         */
        self::beforeUpdate(function ($row) use ($forfun) {
            $forfun($row);
        });

    }

    public function getOriginData()
    {
        return $this->origin;
    }

    /**
     * 创建者
     */
    public function createUser()
    {
        return $this->hasOne('\app\admin\model\Admin', 'id', 'create_user_id');
    }

    /**
     * 创建者
     */
    public function ownerUser()
    {
        return $this->hasOne('\app\admin\model\Admin', 'id', 'owner_user_id');
    }

    /**
     * 放入公共
     */
    public function discard()
    {
        $this->owner_user_id = 0;
        if ($this->status ==0){
            //如果是未转客户就设置为 无效线索
            $this->status=-1;
        }
        return $this->save();
    }




    /**
     * 添加线索
     * @param $params
     * @param int $create_user_id
     * @param int $owner_user_id
     * @param bool $validate 是否校验数据
     */
    public function add($params, $create_user_id = 0, $owner_user_id = 0,$validate=true)
    {
        if ($validate) {
            //系统字段验证
            $cresult = Fields::validateByForm('clues', $params,'system');
            if (!$cresult['status']) {
                $this->error = $cresult['msg'];
                return false;
            }
            //校验数据
            $cresult = Fields::validateByForm('clues', $params);
            if (!$cresult['status']) {
                $this->error = $cresult['msg'];
                return false;
            }

        }
        try {
            if ($validate){
                //采用模型验证
                $name = str_replace("\\model\\", "\\validate\\", get_class($this));
                $this->validateFailException(true)->validate($name . '.add');
            }

            $result = $this->allowField(true)->isUpdate(false)->save($params);

        }catch (\Exception $e){
            $this->error=$e->getMessage();
            return  false;
        }

        $insert_id = $this->id;
        unset($this->id);
        return $result ? $insert_id : $result;

    }




    /**
     * 修改
     * @param $params
     * @param bool $validate
     * @return bool|false|int
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function edit($params,$validate=true){

        if ($validate) {
            //系统字段验证
            $cresult = Fields::validateByForm('clues', $params,'system');
            if (!$cresult['status']) {
                $this->error = $cresult['msg'];
                return false;
            }
            //校验自定义数据
            $cresult = Fields::validateByForm('clues', $params);
            if (!$cresult['status']) {
                $this->error = $cresult['msg'];
                return false;
            }
        }
        //是否采用模型验证
        if ($validate){
            //采用模型验证
            $name = str_replace("\\model\\", "\\validate\\", get_class($this));
            $this->validateFailException(true)->validate($name . '.edit');
        }

        return $this->allowField(true)->save($params);

    }
}