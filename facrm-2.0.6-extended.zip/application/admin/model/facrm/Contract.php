<?php

namespace app\admin\model\facrm;

use think\Model;
use traits\model\SoftDelete;

/**
 * 合同模型
 * Class Contract
 * @package app\admin\model\facrm
 */
class Contract extends Model
{
    use SoftDelete;

    // 表名
    protected $name = 'facrm_contract';
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';
    // 定义时间戳字段名
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $deleteTime = 'delete_time';
    /**
     * 创建者
     */
    public function createUser()
    {
        return $this->hasOne('\app\admin\model\Admin', 'id', 'create_user_id');
    }
    /**
     * 拥有者
     */
    public function ownerUser()
    {
        return $this->hasOne('\app\admin\model\Admin', 'id', 'owner_user_id');
    }

    /**
     * 签单人
     * @return \think\model\relation\HasOne
     */
    public function orderAdmin(){
        return $this->hasOne('\app\admin\model\Admin', 'id', 'order_admin_id');
    }
    /**
     * 客户对象
     * @return \think\model\relation\BelongsTo
     */
    public function customer(){
        return $this->belongsTo('\app\admin\model\facrm\Customer', 'customer_id', 'id');
    }

    /**
     * 联系人
     * @return \think\model\relation\BelongsTo
     */
    public function contacts(){
        return $this->belongsTo('\app\admin\model\facrm\customer\Contacts', 'contacts_id');
    }
    /**
     * 商机对象
     * @return \think\model\relation\BelongsTo
     */
    public function business(){
        return $this->belongsTo('\app\admin\model\facrm\Business', 'business_id', 'id');
    }
    /**
     * 关联商品
     * @return \think\model\relation\HasMany
     */
    public function product()
    {
        return $this->hasMany('\app\admin\model\facrm\contract\Product','contract_id','id');
    }

    /**
     * 收款
     * @return \think\model\relation\HasMany
     */
    public function receivables(){
        return $this->hasMany('\app\admin\model\facrm\contract\Receivables','contract_id','id');
    }
    /**
     * 审批日志
     * @return \think\model\relation\HasMany
     */
    public function flowLog(){
        return $this->hasMany('\app\admin\model\facrm\flow\Log','types_id','id')->where('types','contract');
    }

    /**
     * 合同、回款统计
     * @param $startDate 开始时间
     * @param $endDate 结束时间
     * @param $owner_user_ids
     * @return array|bool
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function  getAchievementEchart($startDate,$endDate,$owner_user_ids){

        $contractModel = new \app\admin\model\facrm\Contract();
        $receivablesModel=new \app\admin\model\facrm\contract\Receivables();
        // 生成查询的开始和结束时间，默认取30日
        !is_numeric($startDate) && $starttime = strtotime($startDate);
        !is_numeric($endDate) && $endtime = strtotime($endDate);
        $isnotrangeDate = empty($starttime) && empty($endtime);
        $nearly = '30';
        if ($isnotrangeDate) {
            $endtime = time();
            $nearly -= 1;
            $starttime = strtotime("-{$nearly} day");  // 最近30天日期
        } elseif ($starttime > $endtime) {
            $this->error = '起始时间要小于终止时间';
            return false;
        }
        $totalseconds = $endtime - $starttime;;
        if ($totalseconds > 86400 * 30 * 2) {
            $format = '%Y-%m';
        } else {
            if ($totalseconds > 86400) {
                $format = '%Y-%m-%d';
            } else {
                $format = '%H:00';
            }
        }
        //合同数量和合同金额
        if ($owner_user_ids&&is_numeric($owner_user_ids)){
            $contractModel->where('order_admin_id', $owner_user_ids);
            $receivablesModel->where('order_admin_id', $owner_user_ids);
        }elseif($owner_user_ids&&is_array($owner_user_ids)){
            $contractModel->where('order_admin_id','in', $owner_user_ids);
            $receivablesModel->where('order_admin_id','in', $owner_user_ids);
        }

        //合同金额
        $lists = $contractModel->where('order_time', 'between time', [$starttime, $endtime])
            ->field('COUNT(*) AS nums, sum(money) as money, DATE_FORMAT(FROM_UNIXTIME(order_time), "' . $format . '") AS add_date')
            ->where('check_status', 2)->group('add_date')
            ->select();
        //回款金额
        $listsd = $receivablesModel->where('return_time', 'between time', [$starttime, $endtime])
            ->field('COUNT(*) AS nums, sum(money) as money, DATE_FORMAT(FROM_UNIXTIME(return_time), "' . $format . '") AS add_date')
            ->where('check_status', 2)->group('add_date')
            ->select();


        if ($totalseconds > 84600 * 30 * 2) {
            $starttime = strtotime('last month', $starttime);
            while (($starttime = strtotime('next month', $starttime)) <= $endtime) {
                $column[] = date('Y-m', $starttime);
            }
        } else {
            if ($totalseconds > 86400) {
                for ($time = $starttime; $time <= $endtime;) {
                    $column[] = date("Y-m-d", $time);
                    $time += 86400;
                }
            } else {
                for ($time = $starttime; $time <= $endtime;) {
                    $column[] = date("H:00", $time);
                    $time += 3600;
                }
            }
        }


        $r_count=$c_count=$c_money = $r_money = array_fill_keys($column, 0);

        foreach ($lists as $k => $v) {
            $c_count[$v['add_date']] = $v['nums'];//合同数量
            $c_money[$v['add_date']] = $v['money'];//合同金额
        }

        foreach ($listsd as $k => $v) {
            $r_money[$v['add_date']] = $v['money'];//回款金额
            $r_count[$v['add_date']] = $v['nums'];//回款数量
        }

        $result = [
            'date' => array_keys($c_count),
            'c_money' => array_values($c_money),
            'c_count' => array_values($c_count),
            'r_money' => array_values($r_money),
            'r_count' => array_values($r_count),
        ];

        $data = [
            'date' => $result['date'],
            'data' => [
                "合同数量" => $result['c_count'],
                "合同金额" => $result['c_money'],
                "回款金额" => $result['r_money'],
                "回款数量" => $result['r_count'],
            ],
        ];
        return $data;
    }

    /**
     * 根据规则自动生成编码
     * @param $prefix
     * @return int|mixed|string
     */
    public static function autoNo($prefix){
        $replace_data=['Y'=>date('Y'),'m'=>date('m'),'d'=>date('d'),'h'=>date("H"),'i'=>date("i"),'s'=>date("s"),'rand'=>rand(100000,999999)];
        return $prefix?__($prefix, $replace_data):'';
    }

}