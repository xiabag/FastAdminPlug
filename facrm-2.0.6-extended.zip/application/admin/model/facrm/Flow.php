<?php

namespace app\admin\model\facrm;

use think\Exception;
use think\Model;
use think\Queue;
use traits\model\SoftDelete;

class Flow extends Model
{
    use SoftDelete;
    // 表名
    protected $name = 'facrm_flow';
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';
    // 定义时间戳字段名
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $deleteTime = 'delete_time';

    /**
     * 关联步骤
     * @return \think\model\relation\HasMany
     */
    public function step()
    {
        return $this->hasMany('\app\admin\model\facrm\flow\Step','flow_id','id');
    }

    /**
     * 添加待审批数据
     * @param $op_id 当前需要审批的ID
     * @param $admin_id 当前添加的管理员ID
     * @param string $types receivables contract 审批的类型
     * @param $flow_r 审批的数据可以为空
     * @return bool
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function addFlow($op_id,$admin_id,$types,$flow_r){
        if (!$flow_r){
            $flow_r = $this->where('status',1)->where('types', $types)->find();
        }
        $model_str="";
        switch ($types){
           case 'receivables':
               $model_str='\app\admin\model\facrm\contract\Receivables';
               break;
            case "contract":
                $model_str='\app\admin\model\facrm\Contract';
                break;
            default:
                $this->error=__("审核类型有误");
                return false;

        }
        //处理收款审核流程
        $update_data = array();
        if ($flow_r) {
            $update_data['flow_id'] = $flow_r->id;
            if ($flow_r['config'] == 1) {
                //固定审批
                $flow_admin_id=$flow_r->step[0]['admin_ids'];
                if ($flow_r->step[0]['type']==1){
                    //上级领导审批
                    $Auth=new  \addons\facrm\library\Auth();
                    $parentIds= $Auth->getParentAdminIds($admin_id);
                    $flow_admin_id=$parentIds?join(',',$parentIds):$admin_id;//如果没有父类就是最高级的，同时也要审核一下
                }
                $update_data['step_id'] = $flow_r->step[0]['id'];
                $update_data['flow_admin_id'] = $flow_admin_id;

            }

        } else {
            //没有审批流程就默认是审批状态
            $update_data['check_status'] = 2;
        }
        $model=\model($model_str);
        $result=$model->where('id', $op_id)->update($update_data);
        //消息通知
        try {
            if ($types=="contract"){
                Queue::push("addons\\facrm\\library\\notice\queue\\FlowContractJob", ['model_id'=>$op_id,'data'=>$update_data]);
            }else {
                Queue::push("addons\\facrm\\library\\notice\queue\\FlowReceivablesJob", ['model_id'=>$op_id,'data'=>$update_data]);
            }

        }catch (Exception $e){

        }
        //消息通知end

        return $result;


    }

    /**
     * 获取第一级审批人ids
     * @param $flow_r
     * @param $admin_id
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function getAdminIds($flow_r,$admin_id){
        if ($flow_r->step&&isset($flow_r->step[0])){
            //固定审批
            $flow_admin_id=$flow_r->step[0]['admin_ids'];
            if ($flow_r->step[0]['type']==1){
                //上级领导审批
                $Auth=new  \addons\facrm\library\Auth();
                $parentIds= $Auth->getParentAdminIds($admin_id);
                $flow_admin_id=$parentIds?join(',',$parentIds):$admin_id;//如果没有父类就是最高级的，同时也要审核一下
            }
        }
       return $flow_admin_id;
    }
}