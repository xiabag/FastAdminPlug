<?php

namespace app\admin\model\facrm;

use think\Model;
use traits\model\SoftDelete;

class Scene extends Model
{
    // 表名
    protected $name = 'facrm_scene';
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';
    // 定义时间戳字段名
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';


}