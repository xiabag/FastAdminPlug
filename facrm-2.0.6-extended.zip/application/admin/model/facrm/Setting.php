<?php
namespace app\admin\model\facrm;
use think\Cache;
use think\Model;

/**
 * 配置信息
 */
class Setting extends Model
{
	protected $name = 'facrm_setting';
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';
    // 定义时间戳字段名
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
	
	/**
	 * 获取器: 转义数组格式
	 * @param $value
	 * @return mixed
	 */
	public function getValuesAttr($value)
	{
		return json_decode($value, true);
	}
	
	/**
	 * 修改器: 转义成json格式
	 * @param $value
	 * @return string
	 */
	public function setValuesAttr($value)
	{
		return json_encode($value);
	}

	
	/**
	 * 获取设置项信息
	 * @param $key
	 * @return null|static
	 */
	public static function detail($key)
	{
		return self::get(compact('key'));
	}
	



}