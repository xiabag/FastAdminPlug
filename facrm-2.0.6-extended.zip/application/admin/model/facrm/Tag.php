<?php

namespace app\admin\model\facrm;

use think\Exception;
use think\Model;

class Tag extends Model
{

    // 表名
    protected $name = 'facrm_tag';
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = true;
    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
    protected static $config = [];

    protected static function init()
    {

    }

    public function getOriginData()
    {
        return $this->origin;
    }
    /**
     * 刷新标签
     * @param string $tags        标签,多个标签以,分隔
     * @return bool
     */
    public static function refresh($tags,$oldtags='',$type="customer")
    {
        $field = "nums";
        $tags = str_replace('，', ',', $tags);
        $tagsArr = explode(',', $tags);
        $tagsArr = array_unique(array_filter(array_map('strtolower', $tagsArr)));
        if (!$tagsArr) {
            return true;
        }
        $oldtags = str_replace('，', ',', $oldtags);
        $oldtagsArr = explode(',', $oldtags);
        $oldtagsArr = array_unique(array_filter(array_map('strtolower', $oldtagsArr)));


        if ($oldtagsArr){
            $tagsList = self::where('name', 'in', $oldtagsArr)->where('type',$type)->select();
            foreach ($tagsList as $index => $item) {
                $item['name'] = strtolower($item['name']);
                if (!in_array($item['name'], $tagsArr)) {
                    //统计减1
                    isset($item[$field]) && $item->setDec($field);
                } else {
                    $tagsArr = array_diff($tagsArr, [$item['name']]);
                }
            }

        }

        //取出标签
        $tagList = self::where('name', 'in', $tagsArr)->where('type',$type)->select();
        foreach ($tagList as $index => $item) {
            $item['name'] = strtolower($item['name']);
            $item->setInc($field);
            $tagsArr = array_diff($tagsArr, [$item['name']]);

        }
        //插入未存在的标签
        if ($tagsArr) {
            $originTagsArr = explode(',', $tags);
            foreach ($originTagsArr as $index => $item) {
                $name = strtolower($item);
                if (in_array($name, $tagsArr)) {
                    $tagsArr = array_diff($tagsArr, [$name]);
                    $object = self::create(['name' => $item, $field => 1,'type'=>$type]);
                }
            }
        }
        return true;
    }
}
