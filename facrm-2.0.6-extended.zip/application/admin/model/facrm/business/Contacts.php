<?php

namespace app\admin\model\facrm\business;

use think\Model;


class Contacts extends Model
{


    // 表名
    protected $name = 'facrm_business_contacts';
    /**
     * 创建者
     */
    public function createUser()
    {
        return $this->hasOne('\app\admin\model\Admin', 'id', 'create_user_id');
    }

    /**
     * 联系人信息
     * @return \think\model\relation\BelongsTo
     */
    public function contact(){
        return $this->belongsTo('\app\admin\model\facrm\customer\Contacts', 'contacts_id', 'id');
    }

    /**
     * 商机信息
     * @return \think\model\relation\BelongsTo
     */
    public function business(){
        return $this->belongsTo('\app\admin\model\facrm\Business', 'business_id', 'id');
    }

}