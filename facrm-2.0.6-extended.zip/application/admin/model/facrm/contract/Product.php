<?php

namespace app\admin\model\facrm\contract;

use think\Model;
use traits\model\SoftDelete;

class Product extends Model
{
    use SoftDelete;

    // 表名
    protected $name = 'facrm_contract_product';
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';
    // 定义时间戳字段名
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $deleteTime = 'delete_time';

    /**
     * 关联商品信息
     * @return \think\model\relation\BelongsTo
     */
    public function info()
    {
        return $this->belongsTo('\app\admin\model\facrm\product\Product', 'product_id', 'id');
    }

}