<?php

namespace app\admin\model\facrm\contract;

use think\Model;
use traits\model\SoftDelete;

class Receivables extends Model
{
    use SoftDelete;

    // 表名
    protected $name = 'facrm_contract_receivables';
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';
    // 定义时间戳字段名
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $deleteTime = 'delete_time';
    protected $append = [
        'account_text'
    ];

    /**
     * 获取付款方式
     * @return array
     */
    public function getAccountList()
    {
        $addon_config = get_addon_config('facrm');
        return isset($addon_config['account'])?$addon_config['account']:[];
    }

    /**
     * 获取付款方式名称
     * @param $value
     * @param $data
     * @return array
     */
    public function getAccountTextAttr($value, $data)
    {
        if (!isset($data['account_id'])) return '';
        $lists=$this->getAccountList();

        return isset($lists[$data['account_id']])?$lists[$data['account_id']]:'';
    }
    /**
     * 关联合同
     * @return \think\model\relation\BelongsTo
     */
    public function contract()
    {
        return $this->belongsTo('\app\admin\model\facrm\Contract', 'contract_id', 'id');
    }
    /**
     * 客户
     * @return \think\model\relation\BelongsTo
     */
    public function customer(){
        return $this->belongsTo('\app\admin\model\facrm\Customer', 'customer_id', 'id');
    }

    /**
     * 创建者
     */
    public function createUser()
    {
        return $this->hasOne('\app\admin\model\Admin', 'id', 'create_user_id');
    }
    /**
     * 负责人
     */
    public function ownerUser()
    {
        return $this->hasOne('\app\admin\model\Admin', 'id', 'owner_user_id');
    }

    /**
     * 签单人
     * @return \think\model\relation\HasOne
     */
    public function orderAdmin(){
        return $this->hasOne('\app\admin\model\Admin', 'id', 'order_admin_id');
    }
    /**
     * 审批状态
     * @return array
     */
    public function getCheckStatusList(){
        return ['0' => __('待审核'), '1' => __('审核中'),2=>__('审核通过'),3=>__('审核未通过')];
    }

    public function getCheckStatusTextAttr($value, $data)
    {
        $value = $value ? $value : $data['check_status'];
        $list = $this->getCheckStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }
    /**
     * 根据规则自动生成编码
     * @param $prefix
     * @return int|mixed|string
     */
    public static function autoNo($prefix){
        $replace_data=['Y'=>date('Y'),'m'=>date('m'),'d'=>date('d'),'h'=>date("H"),'i'=>date("i"),'s'=>date("s"),'rand'=>rand(100000,999999)];
        return $prefix?__($prefix, $replace_data):'';
    }
}