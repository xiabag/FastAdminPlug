<?php

namespace app\admin\model\facrm\product;

use think\Model;
use traits\model\SoftDelete;

class Product extends Model
{

    use SoftDelete;

    // 表名
    protected $name = 'facrm_product';
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';
    // 定义时间戳字段名
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $deleteTime = 'delete_time';
    // 追加属性
    protected $append = [
    ];

    public function object_array($array)
    {
        if (is_object($array)) {
            $array = (array)$array;
        }
        if (is_array($array)) {
            foreach ($array as $key => $value) {
                $array[$key] = $this->object_array($value);
            }
        }
        return $array;
    }

}
