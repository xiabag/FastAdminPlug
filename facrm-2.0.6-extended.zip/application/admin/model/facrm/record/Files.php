<?php

namespace app\admin\model\facrm\record;

use think\Model;
use traits\model\SoftDelete;

class Files extends Model
{
    // 表名
    protected $name = 'facrm_record_files';
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';
    // 定义时间戳字段名
    protected $createTime = 'create_time';
    protected $updateTime = false;
	
    public function getUrlAttr($value, $data){
        return cdnurl($value,true);
    }



}