<?php

namespace app\admin\validate\facrm;

use think\Validate;

class Business extends Validate
{

    /**
     * 验证规则
     */
    protected $rule = [
        'name'=>"require|max:100",
    ];

    /**
     * 提示消息
     */
    protected $message = [
    ];

    /**
     * 验证场景
     */
    protected $scene = [
        'add'  => [
            'name',

        ],
        'edit' => [
            'name',
        ],
    ];

    public function __construct(array $rules = array(), $message = array(), $field = array())
    {

        $this->field =[
            'name'=>__("商机名称"),
        ];
        parent::__construct($rules, $message, $field);
    }
}
