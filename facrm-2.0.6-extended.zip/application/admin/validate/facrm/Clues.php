<?php

namespace app\admin\validate\facrm;

use think\Validate;

class Clues extends Validate
{

    /**
     * 验证规则
     */
    protected $rule = [
    ];

    /**
     * 提示消息
     */
    protected $message = [
    ];

    /**
     * 验证场景
     */
    protected $scene = [
        'add'  => [
            'name',
            'mobile',
        ],
        'edit' => [
            'name',
            'mobile',
        ],
    ];

    public function __construct(array $rules = array(), $message = array(), $field = array())
    {
        $messages = [
            'name'=>__("客户名称"),
            'mobile'=>__("客户手机"),
        ];
        parent::__construct($rules, $messages, $field);
    }
}
