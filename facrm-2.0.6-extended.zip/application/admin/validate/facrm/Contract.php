<?php

namespace app\admin\validate\facrm;

use think\Validate;

class Contract extends Validate
{

    /**
     * 验证规则
     */
    protected $rule = [
        'name'=>"require|max:100",
        'number'=>"require|max:100",
        'money'      => 'require|gt:0',
        'order_time'      => 'require',
        'start_time'      => 'require',
        'end_time'      => 'require',
        'order_admin_id'      => 'require',
    ];

    /**
     * 提示消息
     */
    protected $message = [
    ];

    /**
     * 验证场景
     */
    protected $scene = [
        'add'  => [
            'name',
            'number',
            'money',
            'order_time',
            'start_time',
            'end_time',
            'order_admin_id',

        ],
        'edit' => [
            'name',
        ],
    ];

    public function __construct(array $rules = array(), $message = array(), $field = array())
    {

        $this->field =[
            'name'=>__("合同名称"),
            'number'=>__("合同编号"),
            'money'=>__("合同金额"),
            'order_time'=>__("下单时间"),
            'start_time'=>__("合同开始时间"),
            'end_time'=>__("合同结束时间"),
            'order_admin_id'=>__("公司签约人"),
        ];
        parent::__construct($rules, $message, $field);
    }
}
