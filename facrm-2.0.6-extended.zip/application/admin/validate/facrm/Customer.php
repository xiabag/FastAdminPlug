<?php

namespace app\admin\validate\facrm;

use think\Validate;

class Customer extends Validate
{

    /**
     * 验证规则
     */
    protected $rule = [
    ];

    /**
     * 提示消息
     */
    protected $message = [
    ];

    /**
     * 验证场景
     */
    protected $scene = [
        'add'  => [
            'name',
            'mobile',
        ],
        'edit' => [
            'name',
            'mobile',
        ],
    ];

    public function __construct(array $rules = array(), $message = array(), $field = array())
    {
        $messages =\addons\facrm\library\Helper::getfield('customer','*');
        $config=get_addon_config('facrm');
        $unique=$config['unique'];
        //如果非不限定唯一字段
        if ($unique!=='infinity'){
            //如果是编辑模式，则排除下主键
            $ids = request()->param("ids");

            if ($ids) {
                $this->scene['edit']=array_merge($this->scene['edit'],[$unique]);
                $this->rule[$unique."|".(isset($messages[$unique])?$messages[$unique]:$unique)]  = "require|unique:facrm_customer,{$unique},{$ids},id";
            } else {
                $this->scene['add']=array_merge($this->scene['add'],[$unique]);
                $this->rule[$unique."|".(isset($messages[$unique])?$messages[$unique]:$unique)]  = "require|unique:facrm_customer,{$unique}";
            }
        }

        parent::__construct($rules, $message, $field);
    }
}
