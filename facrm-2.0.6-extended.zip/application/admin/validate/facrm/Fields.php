<?php

namespace app\admin\validate\facrm;

use think\Validate;

class Fields extends Validate
{

    /**
     * 验证规则
     */
    protected $rule = [
        'name|名称'        => 'require|unique:facrm_fields,source^name',
        'title|标题'      => 'require',
        'source|来源'      => 'require',
        'status|状态'      => 'require|in:normal,hidden',
    ];

    /**
     * 提示消息
     */
    protected $message = [
    ];

    /**
     * 验证场景
     */
    protected $scene = [
        'add'  => [
            'name',
            'title',
            'source',
            'status'
        ],
        'edit' => [
            'name',
            'title',
            'source',
            'status'
        ],
    ];

    public function __construct(array $rules = array(), $message = array(), $field = array())
    {
        //如果是编辑模式，则排除下主键
        $ids = request()->param("ids");
        if ($ids) {
            $this->rule['name|名称'] = "require|unique:facrm_fields,source^name,{$ids},id";
        } else {
            $this->rule['name|名称2'] = "require|unique:facrm_fields,source^name";
        }
        parent::__construct($rules, $message, $field);
    }
}
