<?php

namespace app\admin\validate\facrm;

use think\Validate;

class Record extends Validate
{

    /**
     * 验证规则
     */
    protected $rule = [
        'content'=>"require|max:250",
        'record_type'=>"require",
    ];

    /**
     * 提示消息
     */
    protected $message = [
    ];

    /**
     * 验证场景
     */
    protected $scene = [
        'add'  => [
            'content',
            'record_type',

        ],
    ];

    public function __construct(array $rules = array(), $message = array(), $field = array())
    {

        $this->field =[
            'content'=>__("跟进内容"),
            'record_type'=>__("跟进类型"),
        ];
        parent::__construct($rules, $message, $field);
    }
}
