<?php

namespace app\admin\validate\facrm\contract;

use think\Validate;

class Receivables extends Validate {

    /**
     * 验证规则
     */
    protected $rule = [
        'number|回款编号'        => 'require',
        'customer_id|用户'      => 'require',
        'contract_id|合同'      => 'require',
        'return_time|回款时间'      => 'require',
        'money|回款金额'      => 'require|gt:0',
    ];

    /**
     * 提示消息
     */
    protected $message = [
    ];

    /**
     * 验证场景
     */
    protected $scene = [
        'add' => ['number','customer_id','contract_id','return_time','money'],
        'edit' => ['number'],
    ];

}
