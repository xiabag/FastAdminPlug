<?php

namespace app\admin\validate\facrm\customer;

use think\Validate;

class Contacts extends Validate {

    /**
     * 验证规则
     */
    protected $rule = [
        'name|姓名'        => 'require',
        'customer_id|客户'      => 'require',

    ];

    /**
     * 提示消息
     */
    protected $message = [
    ];

    /**
     * 验证场景
     */
    protected $scene = [
        'add' => ['name','customer_id'],
        'edit' => ['name'],
    ];

}
