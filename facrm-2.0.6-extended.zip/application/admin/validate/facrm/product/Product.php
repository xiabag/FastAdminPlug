<?php

namespace app\admin\validate\facrm\product;

use think\Validate;

class Product extends Validate {

    /**
     * 验证规则
     */
    protected $rule = [
        'name'=>"require|max:100",
        'product_type_id'=>'require|number',
        'product_unit_id'=>'require|number',
        'specification'=>'require',
        'unit'=>'require',


    ];

    /**
     * 提示消息
     */
    protected $message = [
    ];

    /**
     * 验证场景
     */
    protected $scene = [
        'add' => [],
        'edit' => ['name'],
    ];
    public function __construct(array $rules = array(), $message = array(), $field = array())
    {

        $this->field =[
            'name'=>__("商品名称"),
            'product_type_id'=>__("分类"),
            'product_unit_id'=>__("单位"),
            'unit'=>__("单位"),
            'specification'=>__("规格")
        ];
        parent::__construct($rules, $message, $field);
    }
}
