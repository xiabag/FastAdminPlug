<?php 
 return array (
  'table_name' => 'fa_facrm_achievement,fa_facrm_business,fa_facrm_business_contacts,fa_facrm_business_product,fa_facrm_cloudcall,fa_facrm_clues,fa_facrm_contract,fa_facrm_contract_order,fa_facrm_contract_product,fa_facrm_contract_receivables,fa_facrm_customer,fa_facrm_customer_contacts,fa_facrm_fields,fa_facrm_flow,fa_facrm_flow_log,fa_facrm_flow_step,fa_facrm_product,fa_facrm_product_type,fa_facrm_product_unit,fa_facrm_qywx_contacts,fa_facrm_qywx_user,fa_facrm_record,fa_facrm_record_files,fa_facrm_scene,fa_facrm_setting,fa_facrm_tag',
  'self_path' => 'public/assets/addons/facrm
application/admin/lang/zh-cn/facrm',
  'update_data' => '--
-- 1.0.1
-- 添加名称字段user_id
--
ALTER TABLE `__PREFIX__facrm_customer` ADD COLUMN `user_id` int(11) NULL DEFAULT \'\' COMMENT \'前台用户ID\' AFTER `owner_user_id`;


--
-- 1.0.3
-- 更改表编码和字段编码和增加字段
--
ALTER TABLE `__PREFIX__facrm_customer` DEFAULT CHARACTER SET utf8mb4,
MODIFY COLUMN `name`  varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT \'客户名称\' ,
MODIFY COLUMN `remark`  text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT \'备注\' ;

ALTER TABLE `__PREFIX__facrm_customer_contacts` DEFAULT CHARACTER SET utf8mb4,
MODIFY COLUMN `name`  varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT \'姓名\' ,
MODIFY COLUMN `remark`  text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT \'备注\' ;

ALTER TABLE `__PREFIX__facrm_record` DEFAULT CHARACTER SET utf8mb4,
MODIFY COLUMN `content`  text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT \'跟进内容\' ;

ALTER TABLE `__PREFIX__facrm_setting` ADD COLUMN `status` tinyint(1) NULL DEFAULT \'1\' COMMENT \'状态\' AFTER `create_time`;

--
-- 2.0.0
-- 更改表编码和字段编码和增加字段
--
ALTER TABLE `__PREFIX__facrm_record`
MODIFY COLUMN `types`  enum(\'business\',\'clues\',\'customer\') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT \'customer\' COMMENT \'关联类型(customer跟进,business商机跟进,clues线索)\' AFTER `id`;


ALTER TABLE `__PREFIX__facrm_record_files`
MODIFY COLUMN `types`  enum(\'business\',\'clues\',\'customer\') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT \'customer\' COMMENT \'关联类型(customer客户,business商机,clues线索)\' AFTER `id`;


--
-- 插入一些必须数据
--
INSERT INTO __PREFIX__facrm_flow VALUES (\'1\', \'合同审批\', \'0\', \'contract\', \'0\', \'\', \'\', \'\', \'1610787200\', \'1610787643\', \'1\', null);
INSERT INTO __PREFIX__facrm_flow VALUES (\'2\', \'回款审批\', \'0\', \'receivables\', \'0\', \'\', \'\', \'\', \'1610947811\', \'1618023534\', \'1\', null);
INSERT INTO __PREFIX__facrm_fields VALUES (\'1\', \'customer\', \'weixin\', \'string\', \'微信\', \'value1|title1\\r\\nvalue2|title2\', \'\', \'\', \'\', \'\', \'\', \'0\', \'50\', \'0\', \'0\', \'\', \'{\\"table\\":\\"\\",\\"conditions\\":\\"\\",\\"key\\":\\"\\",\\"value\\":\\"\\"}\', \'22\', \'1614587422\', \'1614664611\', \'0\', \'0\', \'1\', \'1\', \'normal\');
INSERT INTO __PREFIX__facrm_fields VALUES (\'2\', \'customer\', \'qq\', \'number\', \'QQ\', \'value1|title1\\r\\nvalue2|title2\', \'\', \'\', \'\', \'\', \'\', \'0\', \'11\', \'0\', \'0\', \'\', \'{\\"table\\":\\"\\",\\"conditions\\":\\"\\",\\"key\\":\\"\\",\\"value\\":\\"\\"}\', \'25\', \'1614587924\', \'1614667071\', \'0\', \'1\', \'0\', \'1\', \'normal\');

INSERT INTO __PREFIX__facrm_scene VALUES (\'1\', \'customer\', \'全部客户\', \'0\', \'1\', null, \'1\', \'\', \'0\', \'0\');
INSERT INTO __PREFIX__facrm_scene VALUES (\'2\', \'customer\', \'我的客户\', \'0\', \'1\', null, \'1\', \'\', \'0\', \'0\');
INSERT INTO __PREFIX__facrm_scene VALUES (\'3\', \'customer\', \'下属客户\', \'0\', \'1\', null, \'1\', \'\', \'0\', \'0\');
INSERT INTO __PREFIX__facrm_scene VALUES (\'4\', \'contacts\', \'全部\', \'0\', \'1\', null, \'1\', \'\', \'0\', \'0\');
INSERT INTO __PREFIX__facrm_scene VALUES (\'5\', \'contacts\', \'我的\', \'0\', \'1\', null, \'1\', \'\', \'0\', \'0\');
INSERT INTO __PREFIX__facrm_scene VALUES (\'6\', \'contacts\', \'下属\', \'0\', \'1\', null, \'1\', \'\', \'0\', \'0\');
INSERT INTO __PREFIX__facrm_scene VALUES (\'7\', \'business\', \'全部商机\', \'0\', \'1\', null, \'1\', \'\', \'0\', \'0\');
INSERT INTO __PREFIX__facrm_scene VALUES (\'8\', \'business\', \'我的商机\', \'0\', \'1\', null, \'1\', \'\', \'0\', \'0\');
INSERT INTO __PREFIX__facrm_scene VALUES (\'9\', \'business\', \'下属商机\', \'0\', \'1\', null, \'1\', \'\', \'0\', \'0\');
INSERT INTO __PREFIX__facrm_scene VALUES (\'10\', \'clues\', \'全部线索\', \'0\', \'1\', null, \'1\', \'\', \'0\', \'0\');
INSERT INTO __PREFIX__facrm_scene VALUES (\'11\', \'clues\', \'我的线索\', \'0\', \'1\', null, \'1\', \'\', \'0\', \'0\');
INSERT INTO __PREFIX__facrm_scene VALUES (\'12\', \'clues\', \'下属线索\', \'0\', \'1\', null, \'1\', \'\', \'0\', \'0\');

--
-- 2.0.2
-- 添加来源字段
--
ALTER TABLE `__PREFIX__facrm_contract`
ADD COLUMN `source_id`  int(11) NULL DEFAULT 0 COMMENT \'来源ID\' AFTER `contacts_id`;

--
-- 2.0.5
-- 增加云呼方式
--
ALTER TABLE `__PREFIX__facrm_cloudcall`
MODIFY COLUMN `exten_type`  enum(\'gateway\',\'sip\',\'local\') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT \'local\' COMMENT \'接听方式Local为“手机”\' AFTER `from_exten`;

--
-- 2.0.6
-- 增加线上收款
--
ALTER TABLE `__PREFIX__facrm_record`
ADD COLUMN `lng`  double(14,11) NULL COMMENT \'经度\' AFTER `delete_time`,
ADD COLUMN `lat`  double(14,11) NULL COMMENT \'维度\' AFTER `lng`;

ALTER TABLE `__PREFIX__facrm_contract_receivables`
ADD COLUMN `pay_status`  tinyint(4) NULL DEFAULT 0 COMMENT \'在线支付状态1已付款0未付款\' AFTER `delete_time`,
ADD COLUMN `pay_type`  tinyint(4) NULL DEFAULT 1 COMMENT \'收款方式1默认2在线收款3续费\' AFTER `pay_status`,
ADD COLUMN `pay_token`  varchar(200) NULL COMMENT \'访问支付的token\' AFTER `pay_type`;
',
);