<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2015 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: yunwuxin <448901948@qq.com>
// +----------------------------------------------------------------------

namespace addons\facrm\controller;

use addons\facrm\library\BackendApi;
use think\Config;
use think\captcha\Captcha as CaptchaLib;

/**
 * 图片验证码
 * Class Captcha
 * @package addons\facrm\controller
 */
class Captcha extends BackendApi
{
    protected $noNeedLogin = ['index'];
    public function index()
    {
        $id=request()->param('id');
        $sid=request()->param('sid');
        if (!$sid){
            session_start();
            session_id();
            $this->success('',session_id());
        }else{
            session_id($sid);
            session_start();
        }

        $captcha = new CaptchaLib((array)Config::get('captcha'));
        return $captcha->entry($id);
    }
}