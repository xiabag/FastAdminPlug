<?php

namespace addons\facrm\controller\facrm\customer;

use addons\facrm\library\BackendApi;
use app\admin\model\facrm\Fields;
use think\Db;
use think\Exception;
use think\exception\PDOException;
use think\exception\ValidateException;


/**
 * 客户管理
 * @icon fa fa-circle-o
 */
class Index extends BackendApi
{

    protected $model = null;
    /**
     * 快速搜索时执行查找的字段
     */
    protected $searchFields = 'id,name,mobile,telephone';
    protected $childrenAdminIds = [];
    protected $noNeedRight = ['selectpage'];
    protected $addon_config = array();
    private $expire_type = 0;
    protected $modelValidate = true;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\facrm\Customer();
        $this->addon_config = get_addon_config('facrm');
        $this->request->filter(['strip_tags']);
    }

    /**
     * 客户列表
     * @ApiBody ("参数参考电脑版")
     */
    public function index()
    {
        $scene = model('\app\admin\model\facrm\Scene');
        $scene_list = $scene->where('types', 'customer')
            ->where(function ($query) {
                $query->where('admin_id', 0)->whereor('admin_id', $this->auth->id);
            })
            ->column('id,name');

        $filter_w = $this->getFilterWhere($scene_list);
        //如果发送的来源是Selectpage，则转发到Selectpage
        if ($this->request->request('keyField')) {
            $this->request->request(['custom' => $filter_w]);
            return parent::selectpage();
        }
        list($where, $sort, $order, $offset, $limit) = $this->buildparams();
        $list = $this->model->getLoseWhere($this->addon_config, $this->expire_type)
            ->where($where)
            ->where($filter_w)
            ->with([
                'createUser' => function ($user) {
                    $user->field('id,username,nickname');
                },
                'ownerUser' => function ($user) {
                    $user->field('id,username,nickname');
                },
            ])
            ->order($sort, $order)
            ->limit($offset, $limit)->fetchSql(false)
            ->select();

        if ($this->addon_config['show_contacts']!=1){
            $pattern = '/(\d{3})(\d{4})(\d{4})/i';
            $replacement = '$1****$3';
            //为了安全隐藏手机和电话
            foreach ($list as $row) {
                $row->mobile =$row->mobile?preg_replace ($pattern,$replacement,$row->mobile ):'';
                $row->telephone =$row->telephone?preg_replace ($pattern,$replacement,$row->telephone ):'';
            }
        }
        $this->success('',array( "rows" => $list,'scene'=>$scene_list));

    }

    /**
     * 处理过滤where条件
     * @ApiInternal
     * @return array
     */
    private function getFilterWhere($scene_list)
    {
        $filter = $this->request->get("filter", '');
        $filter = (array)json_decode($filter, true);
        $filter_w = [];
        $filter_w['owner_user_id'] = $this->auth->id;
        $filter['scene_id'] = isset($filter['scene_id']) ? $filter['scene_id'] : 1;
        if (isset($filter['scene_id'])) {

            if (!isset($scene_list[$filter['scene_id']])) {
                $this->error(__("您没有权限"));
            }
            switch ($filter['scene_id']) {
                case 1:
                    //全部客户
                    $this->childrenAdminIds = $this->auth->getChildrenAdminIds(true);
                    $filter_w['owner_user_id'] = ['in', $this->childrenAdminIds];
                    break;
                case 2:
                    //我的客户
                    $filter_w['owner_user_id'] = $this->auth->id;
                    break;
                case 3:
                    //下属客户
                    $this->childrenAdminIds = $this->auth->getChildrenAdminIds(false);
                    $filter_w['owner_user_id'] = ['in', $this->childrenAdminIds];
                    break;
                default://其它的还做TODO
                    $filter_w['owner_user_id'] = $this->auth->id;
            }
            if (isset($filter['expire_type'])) {
                $this->expire_type = $filter['expire_type'];
                unset($filter['expire_type']);
            }
            unset($filter['scene_id']);
            $this->request->get(['filter' => json_encode($filter)]);
        }
        return $filter_w;
    }


    /**
     * 添加客户
     * @ApiBody ("参数参考电脑版,去掉row,取里面的.记得把自定义字段也要提交过来")
     * @return mixed
     */
    public function add()
    {
        //判断是否有客户限制
        if ($this->addon_config['possess_num'] > 0 && $this->addon_config['possess_num'] <= $this->model->where('deal_status', 0)->where('owner_user_id', $this->auth->id)->count()) {
            $this->error(__("已经超过限制拥有客户数量,限制") . $this->addon_config['possess_num']);
        }
        $params = $this->request->post();
        if ($params) {
            $result = false;
            Db::startTrans();
            try {
                $params = array_merge($params, [
                    'create_user_id' => $this->auth->id,
                    'owner_user_id' => $this->auth->id,
                    'province' => ($this->request->request('province')),
                    'city' => ($this->request->request('city')),
                    'area' => ($this->request->request('area')),
                    'next_time' =>strtotime($params['next_time']),
                    'follow_time' => time(),
                    'collect_time' => time(),
                ]);
                $result = $this->model->add($params);
                Db::commit();
            } catch (ValidateException $e) {

                Db::rollback();
                $this->error($e->getMessage());
            } catch (PDOException $e) {
                Db::rollback();
                $this->error($e->getMessage());
            } catch (\Exception $e) {
                Db::rollback();
                $this->error($e->getMessage());
            }
            if ($result !== false) {
                $this->success();
            } else {
                $this->error($this->model->getError()?__($this->model->getError()):__('添加失败'));
            }
        }
        $this->error(__('参数不能为空', ''));
    }


    /**
     * 修改客户
     * @ApiMethod (POST|GET)
     * @ApiParams(name="id", type="int", required=true, description="客户id")
     * @ApiBody ("get是获取，post是修改，修改的内容参数参考电脑版")
     */
    public function edit()
    {
        $id=$this->request->request('id','','intval');
        if (!$id){
            $this->error(__('客户不存在'));
        }
        $row = $this->model->get($id,['ownerUser'=>function($query){
            return $query->field('id,username,nickname');
        }]);
        if (!$row) {
            $this->error(__('客户不存在，或已删除'));
        }
        $auth = new \addons\facrm\library\Auth();
        if (!$auth->checkCustomerAuth($row, $this->auth)) {
            $this->error(__('您没有权限'));
        }

        if ($this->request->isPost()) {
            $params = $this->request->post();

            if ($params) {
                $params = array_merge($params, [
                    'province' => ($this->request->param('province')),
                    'city' => ($this->request->param('city')),
                    'area' => ($this->request->param('area')),
                ]);

                $result = false;
                Db::startTrans();
                try {
                    $result = $row->edit($params);
                    Db::commit();
                } catch (ValidateException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (PDOException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (\Exception $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                }
                if ($result !== false) {
                    $this->success();
                } else {
                    $this->error($row->getError() ? __($row->getError()) : __('修改失败'));
                }
            }
            $this->error(__('参数不能为空', ''));
        }
        $this->success('',$row);

    }

    /**
     * 删除
     * @ApiMethod (POST)
     * @param string $ids
     */
    public function del()
    {

        if (!$this->request->isPost()) {
            $this->error(__("Invalid parameters"));
        }

        $ids = $this->request->post("ids");
        if ($ids) {
            $this->childrenAdminIds = $this->auth->getChildrenAdminIds(true);
            $list = $this->model->where('id', 'in', $ids)->where('owner_user_id', 'in', $this->childrenAdminIds)->select();

            $count = 0;
            Db::startTrans();
            try {
                foreach ($list as $k => $v) {
                    $count += $v->delete();
                }
                Db::commit();
            } catch (PDOException $e) {
                Db::rollback();
                $this->error($e->getMessage());
            } catch (\Exception $e) {
                Db::rollback();
                $this->error($e->getMessage());
            }
            if ($count) {
                $this->success(__("删除成功"));
            } else {
                $this->error(__('No rows were deleted'));
            }
        }
        $this->error(__('Parameter %s can not be empty', 'ids'));
    }

    /**
     * 公海客户
     * @ApiBody ("参数参考电脑版")
     */
    public function common()
    {
        $filter_w['owner_user_id'] = 0;
        //如果发送的来源是Selectpage，则转发到Selectpage
        if ($this->request->request('keyField')) {
            return $this->selectpage();
        }

        list($where, $sort, $order, $offset, $limit) = $this->buildparams();


        $list = $this->model
            ->where($where)
            ->where($filter_w)
            ->with([
                'createUser' => function ($user) {
                    $user->field('id,username,nickname');
                },
            ])
            ->order($sort, $order)
            ->limit($offset, $limit)->fetchSql(false)
            ->select();
        foreach ($list as $row) {
            //公海为了安全隐藏手机和电话
            $row->mobile = "***";
            $row->telephone = "***";
        }

        $result = array( "rows" => $list);
        $this->success('',$result);
    }

    /**
     * 放入公海
     * @ApiMethod (POST)
     * @ApiParams(name="ids", type="string", required=true, description="客户id，多个以逗号隔开")
     */
    public function discard($ids = NULL)
    {
        $ids = $this->request->post("ids");
        if (!$ids)
            $this->error(__("请选择客户"));
        $this->childrenAdminIds = $this->auth->getChildrenAdminIds(true);
        $list = $this->model->where('id', 'in', $ids)->where('owner_user_id','in',$this->childrenAdminIds)->select();

        if (!$list) {
            $this->error(__('No Results were found'));
        }
        $success_num = 0;//成功数量
        foreach ($list as $row) {
            $row->discard();
            $success_num++;
        }
        $this->success("成功放入公海{$success_num}条");
    }

    /**
     * 领取
     * @ApiMethod (POST)
     * @ApiParams(name="ids", type="string", required=true, description="客户id，多个以逗号隔开")
     */
    public function receive()
    {
        $ids = $this->request->post("ids");
        if (!$ids)
            $this->error(__("请选择客户"));

        $list = $this->model->where('id', 'in', $ids)->where('owner_user_id',0)->select();
        if (!$list) {
            $this->error(__('No Results were found'));
        }
        $success_num = 0;//成功领取的数量
        foreach ($list as $row) {
            //判断是否有客户限制
            if ($this->addon_config['possess_num'] > 0 && $this->addon_config['possess_num'] <= $this->model->where('deal_status', 0)->where('owner_user_id', $this->auth->id)->count()) {
                $this->error(__("已经超过限制拥有客户数量{$this->addon_config['possess_num']}条。成功领取{$success_num}条"));
            }
            $row->owner_user_id = $this->auth->id;
            $row->follow_time = $row->collect_time = time();
            $row->save();
            //联系人负责人也更改
            $contacts = model('\app\admin\model\facrm\customer\Contacts');
            $contacts->where('customer_id', $row->id)->update(['owner_user_id' => $this->auth->id]);
            $success_num++;
        }
        $this->success("成功领取{$success_num}条");
    }


    /**
     * 转移客户
     * @ApiParams(name="ids", type="string", required=true, description="客户id，多个以逗号隔开")
     * @ApiParams(name="admin_id", type="int", required=true, description="admin_id员工id")
     */
    public function divert($ids = NULL)
    {
		$ids = $this->request->request("ids");
        if (!$ids)
            $this->error(__("请选择客户"));
        if ($this->request->isPost()){
            $admin_id = $this->request->post("admin_id", '', 'intval');
            if (!$admin_id)
                $this->error(__("未选择员工"));

            $this->childrenAdminIds = $this->auth->getChildrenAdminIds(true);
            $list = $this->model->where('id', 'in', $ids)->where('owner_user_id', 'in', $this->childrenAdminIds)->select();
            //判断转移的员工是不是下属
            if (!in_array($admin_id, $this->childrenAdminIds)) {
                $this->error(__('只能转移给自己或者下属'));
            }

            if (!$list) {
                $this->error(__('No Results were found'));
            }

            $owner_count = $this->model->where('deal_status', 0)->where('owner_user_id', $admin_id)->count();
            $contacts = model('\app\admin\model\facrm\customer\Contacts');
            $success_num = 0;//成功数量
            foreach ($list as $row) {
                if ($row->deal_status != 1) {//成交不占用数量
                    //判断是否有客户限制
                    if ($this->addon_config['possess_num'] > 0 && $this->addon_config['possess_num'] <= $owner_count) {
                        $this->error(__("已经超过限制拥有客户数量,限制") . $this->addon_config['possess_num'] . ",成功转移{$success_num}条!");
                    }
                    $owner_count++;
                }
                //转移不限制员工拥有数量。
                $row->owner_user_id = $admin_id;
                $row->save();
                //更改联系人
                //联系人负责人也更改
                $contacts->where('customer_id', $row->id)->update(['owner_user_id' => $admin_id]);

                $success_num++;


            }
            $this->success(__("成功转移{$success_num}条"));
        }

        $this->error(__("请求有误"));

    }

    /**
     * 合同列表
     */
    public function contractlist()
    {
        $customer_id = $this->request->request("customer_id");
        if (!$customer_id)
            $this->error(__("参数错误"));
        //检查是否有权限
        $Auth = new  \addons\facrm\library\Auth();
        if (!$Auth->checkCustomerAuth($customer_id, $this->auth)) {
            $this->error(__("您没有权限查看合同"));
        }
        $this->searchFields = "id,number,name,remark";
        $this->model = model('\app\admin\model\facrm\Contract');
        $filter_w['customer_id'] = $customer_id;
        //设置过滤方法
        $this->request->filter(['strip_tags']);
        //如果发送的来源是Selectpage，则转发到Selectpage
        if ($this->request->request('keyField')) {
            $this->request->request(['custom' => $filter_w]);
            return parent::selectpage();
        }

        list($where, $sort, $order, $offset, $limit) = $this->buildparams();
        $list = $this->model
            ->where($where)
            ->where($filter_w)
            ->with([
                'createUser' => function ($user) {
                    $user->field('id,username,nickname');
                },
                'orderAdmin' => function ($user) {
                    $user->field('id,username,nickname');
                },
                'customer' => function ($customer) {
                    $customer->field('id,name');
                },
            ])
            ->order($sort, $order)
            ->limit($offset, $limit)->fetchSql(false)
            ->select();
        $result = array("rows" => $list);
        return $this->success('',$result);
    }

    /**
     * 回款列表
     */
    public function receivableslist()
    {
        $customer_id = $this->request->request("customer_id");
        if (!$customer_id)
            $this->error(__("参数错误"));
        //检查是否有权限
        $Auth = new  \addons\facrm\library\Auth();
        if (!$Auth->checkCustomerAuth($customer_id, $this->auth)) {
            $this->error(__("您没有权限查看回款"));
        }
        $this->searchFields = "id,number,remark";
        $this->model = model('\app\admin\model\facrm\contract\Receivables');
        $filter_w['customer_id'] = $customer_id;
        //设置过滤方法
        $this->request->filter(['strip_tags']);
        //如果发送的来源是Selectpage，则转发到Selectpage
        if ($this->request->request('keyField')) {
            $this->request->request(['custom' => $filter_w]);
            return parent::selectpage();
        }

        list($where, $sort, $order, $offset, $limit) = $this->buildparams();

        $list = $this->model
            ->where($where)
            ->where($filter_w)
            ->with([
                'createUser' => function ($user) {
                    $user->field('id,username,nickname');
                },
                'customer' => function ($customer) {
                    $customer->field('id,name');
                },
                'contract' => function ($customer) {
                    $customer->field('id,name,number');
                },
            ])
            ->order($sort, $order)
            ->limit($offset, $limit)->fetchSql(false)
            ->select();
        $result = array("rows" => $list);

        return $this->success('',$result);
    }


    /**
     * 客户查重
     */
    public function reduplicate()
    {

        //如果发送的来源是Selectpage，则转发到Selectpage
        list($where, $sort, $order, $offset, $limit) = $this->buildparams();
        $list = $this->model
            ->where($where)
            ->with([
                'createUser' => function ($user) {
                    $user->field('id,username,nickname');
                },
                'ownerUser' => function ($user) {
                    $user->field('id,username,nickname');
                },
            ])
            ->field('id,name,deal_status,create_time,mobile,create_user_id,owner_user_id,telephone,update_time,follow_time,tags')
            ->order($sort, $order)
            ->limit($offset, $limit)->fetchSql(false)
            ->select();

        $pattern = '/(\d{3})(\d{4})(\d{4})/i';
        $replacement = '$1****$3';
        //为了安全隐藏手机和电话
        foreach ($list as $row) {
            $row->mobile = $row->mobile ? preg_replace($pattern, $replacement, $row->mobile) : '';
            $row->telephone = $row->telephone ? preg_replace($pattern, $replacement, $row->telephone) : '';
        }
        $this->success('', array("rows" => $list));
    }




    /**
     * selectpage
     * @ApiInternal
     * @return \think\response\Json
     */
    public function selectpage()
    {
        $type = $this->request->param('type');
        if ($type == "all") {
            return parent::selectpage(); // TODO: Change the autogenerated stub
        } else {
            return $this->index();
        }

    }

}
