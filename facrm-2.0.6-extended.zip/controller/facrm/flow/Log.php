<?php

namespace addons\facrm\controller\facrm\flow;

use addons\facrm\library\BackendApi;


/**
 * 审批日志
 * @icon fa fa-circle-o
 * @internal
 */
class Log extends BackendApi {

    /**
     * flow模型对象
     * @var \app\admin\model\facrm\Flow
     */
    protected $model = null;
    protected $distinguish = true;


    public function _initialize()
    {
        parent::_initialize();
        $this->model = model('\app\admin\model\facrm\flow\Log');
        $this->request->filter(['strip_tags']);

    }

    /**
     * 列表
     * @return string|\think\response\Json
     * @throws \think\Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function index()
    {
        //设置过滤方法
        $this->request->filter(['strip_tags']);
        $flow_id= $this->request->param("flow_id");
        $types_id= $this->request->param("types_id");

        $filter_w = [];
        $filter_w['flow_id']= $flow_id;
        $filter_w['types_id']= $types_id;
        list($where, $sort, $order, $offset, $limit) = $this->buildparams();
        $total = $this->model
            ->where($where)
            ->where($filter_w)
            ->order($sort, $order)->fetchSql(false)
            ->count();
        $list = $this->model
            ->where($where)
            ->where($filter_w)
            ->order($sort, $order)
            ->limit($offset, $limit)->fetchSql(false)
            ->select();
        $result = array("total" => $total, "rows" => $list);

        return $this->success('',$result);
    }
}
