/**
 * 配置编译环境和线上环境之间的切换
 *
 * baseUrl: 域名地址
 * routerMode: 路由模式
 * imgBaseUrl: 图片所在域名地址
 * api_v1:接口地址
 *
 */

let baseUrl = '' // 接口地址
let imgBaseUrl = ''  // 图片地址
let api_v1 = '' // 接口地址
let store_v1 = '' // 备用接口地址
let token_key = '' // 登录凭证

if (process.env.NODE_ENV == 'development') {//测试环境
	baseUrl = 'http://192.168.1.157:8122'  //http://192.168.1.157:8122
	imgBaseUrl = 'http://192.168.1.157:8122'
	api_v1 = "/addons/facrm" 
	token_key = ''
} else if (process.env.NODE_ENV == 'production'){//线上环境
	imgBaseUrl = 'https://crmdemo.rycl.vip'  
	baseUrl = 'https://crmdemo.rycl.vip' 
	// #ifdef H5
	imgBaseUrl = baseUrl = window.location.protocol + "//" + window.location.host;
	// #endif
	api_v1 = '/addons/facrm' 
}

export {
	baseUrl,
	imgBaseUrl,
	api_v1,
	store_v1,
	token_key,
}
