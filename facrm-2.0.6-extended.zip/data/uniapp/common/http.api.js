// 如果没有通过拦截器配置域名的话，可以在这里写上完整的URL(加上域名部分)
let loginUrl = 'index/login',//账号登录
wxlogin = 'index/wxlogin',// 微信登录
mplogin = 'index/mplogin',// 第三方微信公众号登录
init = 'facrm.common/init',//  基础配置
upload = 'facrm.common/upload', // 上传文件
bind = 'index/bind',// 绑定原有账号
logout	= 'index/logout',// 退出登录
adminList = 'auth.admin/index',// 查看管理员列表
groupdata = 'auth.admin/getGroupdata',//获取员工组
adminAdd = 'auth.admin/add',//添加
adminEdit = 'auth.admin/edit',//编辑
adminDel = 'auth.admin/del', // 删除
selectpage = 'auth.admin/selectpage',// 下拉搜素管理员
customerList = 'facrm.customer.index/index',// 客户列表
customerAdd = 'facrm.customer.index/add',// 添加客户
customerEdit = 'facrm.customer.index/edit',// 编辑客户 "get是获取，post是修改，修改的内容参数参考电脑版"
customerDel = 'facrm.customer.index/del',// 删除客户
common = 'facrm.customer.index/common',// 公海客户
discard = 'facrm.customer.index/discard',// 放入公海
receive = 'facrm.customer.index/receive',// 领取客户
divert = 'facrm.customer.index/divert',// 转移客户
contractlist = 'facrm.customer.index/contractlist',// 合同列表
receivableslist = 'facrm.customer.index/receivableslist', // 回款列表
openAdd = 'open.customer/add',// 添加客户
updateProfile = 'general.profile/update',// POST修改个人信息
profileGetInfo = 'general.profile/getInfo',// 获取个人信息
productUnit = 'facrm.product.unit/index',// 商品-单位列表
productUnitEdit = 'facrm.product.unit/edit',// 商品-编辑单位
productUnitAdd = 'facrm.product.unit/add',// 商品-添加单位
productType = 'facrm.product.type/index', // 商品分类列表
productTypeEdit = 'facrm.product.type/edit',// 编辑商品分类
productTypeAdd = 'facrm.product.type/add',// 添加商品分类
productList = 'facrm.product.product/index',//  产品列表
productAdd = 'facrm.product.product/add',// 添加产品
productEdit = 'facrm.product.product/edit',// 编辑产品
productDel = 'facrm.product.product/del',// 删除产品
productTypeList = 'facrm.product.product/get_type_list',// 获取商品类型列表
productTypeProp = 'facrm.product.product/get_type_prop',// 获取当前商品选择类型的属性
productUnitList = 'facrm.product.product/get_unit_list',// 获取单位列表
fields = 'facrm.fields/get_fields',// 获取自定义字段
home = 'facrm.dashboard/index',// 获取首页数据
achievement = 'facrm.dashboard/getAchievement',// 业绩筛选
record = 'facrm.customer.record/index',// 客户跟进记录
recordAdd = 'facrm.customer.record/add',// 添加客户跟进记录
recordDel = 'facrm.customer.record/del',// 删除客户跟进记录
receivables = 'facrm.contract.receivables/index',// 回款列表 
receivablesAdd = 'facrm.contract.receivables/receivablesadd',// 【我和下属】回款添加 get获取审批流程config为1是固定审批0是授权。flow_admin_id是固定审批时候的用户ID
receivablesEdit = 'facrm.contract.receivables/edit', // 回款修改，post修改 ，get获取
receivablesDel = 'facrm.contract.receivables/del',// 回款删除
analysis = 'facrm.analysis.admin/index', // 客户量分析
analysisRecord = 'facrm.analysis.admin/record',// 跟进分析
achievementAnalysis = 'facrm.analysis.admin/achievement',// 业绩分析 
contractIndexList = 'facrm.contract.index/index',// 合同列表
contractAdd = 'facrm.contract.index/contractadd',// 合同添加【我和下属】
contractEdit = 'facrm.contract.index/edit',// 合同修改 get是获取, post修改
contractDel = 'facrm.contract.index/del', // 合同删除
contractSelectpage = 'facrm.contract.index/selectpage', // 合同选择
commonSelectpage = 'facrm.common/selectpage',// 下拉选择（）
subscribe = 'facrm.common/subscribe',//POST|GET是获取 消息订阅修改
businessRecord = 'facrm.business.record/index',//[商机]跟进记录
businessRecordAdd = 'facrm.business.record/add',//[商机]添加跟进
businessRecordDel = 'facrm.business.record/del',//[商机]删除跟进记录
businessList = 'facrm.business.index/index',//商机列表
businessAdd = 'facrm.business.index/add',//商机列表添加
businessEdit = 'facrm.business.index/edit',//商机列表post修改，get获取
businessDel = 'facrm.business.index/del',//商机列表删除
businessContacts = 'facrm.business.contacts/index',//联系人列表[商机]
contactsCorrelation = 'facrm.business.contacts/correlation',// 关联联系人
businessContactsDel = 'facrm.business.contacts/del',// 删除关联联系人
contactsList = 'facrm.customer.contacts/index',// 联系人列表
contactsAdd = 'facrm.customer.contacts/add',// 添加联系人
contactsEdit = 'facrm.customer.contacts/edit',// 修改联系人.get获取 post修改
contactsDel = 'facrm.customer.contacts/del',// 删除联系人
backlog = 'facrm.backlog/index',//待审批列表
backlogVerify = 'facrm.backlog/verify',// 审批 get是获取审批信息，post是审批
logList = 'facrm.flow.log/index',// 获取审批日志
contractRanking = 'facrm.analysis.ranking/contract',// 合同排行榜
receivablestRanking= 'facrm.analysis.ranking/receivables',// 回款排行榜
customerRanking = 'facrm.analysis.ranking/addCustomer',// 新客排名
recordRanking = 'facrm.analysis.ranking/record',// 跟进排名
productRanking = 'facrm.analysis.ranking/product',// 产品排名
customerIndex = 'facrm.analysis.customer/index',// 客户地区分析
industry = 'facrm.analysis.customer/industry',// 客户行业分析
level = 'facrm.analysis.customer/level',// 客户级别分析
source = 'facrm.analysis.customer/source',// 客户来源分析
area = 'facrm.common/area',//读取省市区数据,联动列表
allarea = 'facrm.common/getAllArea',//获取所有省市区，children
baseConfig = 'facrm.common/baseConfig',// 基础配置[客户等级、行业类型、来源等
getInfo = 'general.profile/getInfo',// 获取个人信息
customerSelectpage = 'facrm.customer.index/selectpage', // 下拉选择客户
achievementIndex = 'facrm.achievement/index', // 业绩列表
achievementAdmin = 'facrm.achievement/admin',// 员工业绩列表
achievementEdit	= 'facrm.achievement/edit',// POST 团队业绩编辑
achievementAedit = 'facrm.achievement/aedit',// 成员业绩编辑
fieldsSelectpage = 'facrm.fields/selectpage', // 自定义字段关联表联动
unbind = 'index/unbind', // 解绑微信
noticeTpl = 'facrm.common/getNoticeTpl', // 消息提醒模板
batchTeam = 'facrm.achievement/batchTeam', // 团队批量设置业绩
batchAdmin = 'facrm.achievement/batchAdmin', // 成员批量设置业绩
allAdmin = 'facrm.common/selectpage/model/admin/type/all', // 所有员工
thirdlist = 'index/thirdlist', // 获取第三方列表
cluesList = 'facrm.clues.index/index', // 获取线索列表
cluesAdd = 'facrm.clues.index/add',// 添加线索
cluesEdit = 'facrm.clues.index/edit', // 编辑线索，get获取 ，post修改
cluesDel = 'facrm.clues.index/del',// 删除线索
cluesTransform = 'facrm.clues.index/transform',// 线索转化为客户
shiftDivert = 'facrm.clues.index/divert',// 线索转移
cluesRecord = 'facrm.clues.record/add', // 线索添加跟进
cluesRecordList = 'facrm.clues.record/index', // 线索跟进数据
cluesCommon = 'facrm.clues.index/common', // 公共线索池
cluesReceive = 'facrm.clues.index/receive',// 线索领取
cluesDiscard = 'facrm.clues.index/discard', // 线索丢弃
qywxH5 = 'qywx/login', // 企业微信H5登录
qywxMp = 'qywx/wxlogin', // 企业微信小程序登录
reduplicate = 'facrm.customer.index/reduplicate', // 客户查重
sms = 'facrm.apps.sms/selectpage', // 查看短信模板列表
emailList = 'facrm.apps.email/selectpage', // 查看邮箱模板列表
sendSms = 'facrm.apps.sms/send', // 发送短信
email = 'facrm.apps.email/send', // post发邮件|get获取邮件模板
cloudcall = 'facrm.setting.cloudcall/call',//云呼叫
cloudcallMode = 'facrm.setting.cloudcall/setup',//云呼方式 POST是提交修改，GET获取数据
signin = 'facrm.customer.record/signin', //外访签到跟进
payurl = 'facrm.contract.receivables/payurl',// 生成在线收款单
geocoder = 'facrm.common/geocoder', // 腾讯地图经纬度返回地址
renewPayurl = 'facrm.contract.index/payurl'// 生成续费链接













// 此处第二个参数vm，就是我们在页面使用的this，你可以通过vm获取vuex等操作，更多内容详见uView对拦截器的介绍部分：
// https://uviewui.com/js/http.html#%E4%BD%95%E8%B0%93%E8%AF%B7%E6%B1%82%E6%8B%A6%E6%88%AA%EF%BC%9F
const install = (Vue, vm) => {
	// 此处没有使用传入的params参数
	let getSearch = (params = {}) => vm.$u.get(hotSearchUrl, {
		id: 2
	});
	// 此处使用了传入的params参数，一切自定义即可
	let accountLogin = (params = {}) => vm.$u.post(loginUrl, params),
	onWxlogin = (params = {}) => vm.$u.post(wxlogin, params),
	onMplogin = (params = {}) => vm.$u.get(mplogin, params),
	onBind = (params = {}) => vm.$u.post(bind, params),
	getInit = (params = {}) => vm.$u.get(init, params),
	goUpload = (params = {}) => vm.$u.post(upload, params),
	onLogout = (params = {}) => vm.$u.get(logout, params),
	lookAdmin = (params = {}) => vm.$u.get(admin, params),
	getGroupdata = (params = {}) => vm.$u.get(groupdata, params),
	onAdminAdd = (params = {}) => vm.$u.post(adminAdd, params),
	onAdminEdit  = (params = {}) => vm.$u.post(adminEdit, params),
	getAdminEdit  = (params = {}) => vm.$u.get(adminEdit, params),
	onAdminDel = (params = {}) => vm.$u.get(adminDel, params), 
	onSelectpage = (params = {}) => vm.$u.get(selectpage, params),
	getCustomerList = (params = {}) => vm.$u.get(customerList, params),
	onCustomerAdd = (params = {}) => vm.$u.post(customerAdd, params),
	getCustomer = (params = {}) => vm.$u.get(customerEdit, params),
	onCustomerEdit = (params = {}) => vm.$u.post(customerEdit, params),
	onCustomerDel = (params = {}) => vm.$u.post(customerDel, params),
	getCommon = (params = {}) => vm.$u.get(common, params),
	onDiscard = (params = {}) => vm.$u.post(discard, params),
	getReceive = (params = {}) => vm.$u.post(receive, params),
	onDivert = (params = {}) => vm.$u.post(divert, params),
	getContractlist = (params = {}) => vm.$u.get(contractlist, params),
	getReceivableslist = (params = {}) => vm.$u.get(receivableslist, params),
	onOpenAdd = (params = {}) => vm.$u.get(openAdd, params),
	getProfile = (params = {}) => vm.$u.get(profileGetInfo, params),
	postProfile = (params = {}) => vm.$u.post(updateProfile, params),
	getProductUnit = (params = {}) => vm.$u.get(productUnit, params),
	onProductUnitEdit = (params = {}) => vm.$u.get(productUnitEdit, params),
	onProductUnitAdd = (params = {}) => vm.$u.post(productUnitAdd, params),
	getProductType = (params = {}) => vm.$u.get(productType, params),
	onProductTypeEdit = (params = {}) => vm.$u.get(productTypeEdit, params),
	onProductTypeAdd = (params = {}) => vm.$u.post(productTypeAdd, params),
	getProductList = (params = {}) => vm.$u.get(productList, params),
	onProductAdd = (params = {}) => vm.$u.post(productAdd, params),
	onProductEdit = (params = {}) => vm.$u.post(productEdit, params),
	getProductEdit = (params = {}) => vm.$u.get(productEdit, params),
	onProductDel = (params = {}) => vm.$u.get(productDel, params),
	getProductTypeList = (params = {}) => vm.$u.get(productTypeList, params),
	getProductTypeProp = (params = {}) => vm.$u.get(productTypeProp, params),
	getProductUnitList = (params = {}) => vm.$u.get(productUnitList, params),
	getFields = (params = {}) => vm.$u.get(fields, params),
	getHome = (params = {}) => vm.$u.get(home, params),
	getAchievement = (params = {}) => vm.$u.get(achievement, params),
	getRecord = (params = {}) => vm.$u.get(record, params),
	onRecordAdd = (params = {}) => vm.$u.post(recordAdd, params),
	onRecordDel = (params = {}) => vm.$u.get(recordDel, params),
	getReceivables = (params = {}) => vm.$u.get(receivables, params),
	onReceivablesAdd = (params = {}) => vm.$u.post(receivablesAdd, params),
	getReceivablesAdd = (params = {}) => vm.$u.get(receivablesAdd, params),
	onReceivablesEdit = (params = {}) => vm.$u.post(receivablesEdit, params),
	getReceivablesEdit = (params = {}) => vm.$u.get(receivablesEdit, params),
	onReceivablesDel = (params = {}) => vm.$u.post(receivablesDel, params),
	onAnalysis = (params = {}) => vm.$u.get(analysis, params),
	onAnalysisRecord = (params = {}) => vm.$u.get(analysisRecord, params),
	onAchievementAnalysis = (params = {}) => vm.$u.get(achievementAnalysis, params),
	getContractIndexList = (params = {}) => vm.$u.get(contractIndexList, params),
	onContractAdd = (params = {}) => vm.$u.post(contractAdd, params),
	getContractAdd = (params = {}) => vm.$u.get(contractAdd, params),
	onContractEdit = (params = {}) => vm.$u.post(contractEdit, params),
	getContractEdit = (params = {}) => vm.$u.get(contractEdit, params),
	onContractDel = (params = {}) => vm.$u.post(contractDel, params),
	onContractSelectpage = (params = {}) => vm.$u.get(contractSelectpage, params),
	onCommonSelectpage = (params = {}) => vm.$u.get(commonSelectpage, params),
	getSubscribe = (params = {}) => vm.$u.get(subscribe, params),
	postSubscribe = (params = {}) => vm.$u.post(subscribe, params),
	onBusinessRecord = (params = {}) => vm.$u.get(businessRecord, params),
	onBusinessRecordAdd = (params = {}) => vm.$u.post(businessRecordAdd, params),
	onBusinessRecordDel = (params = {}) => vm.$u.get(businessRecordDel, params),
	onBusinessList = (params = {}) => vm.$u.get(businessList, params),
	onBusinessAdd = (params = {}) => vm.$u.post(businessAdd, params),
	onBusinessEdit = (params = {}) => vm.$u.post(businessEdit, params),
	getBusinessEdit = (params = {}) => vm.$u.get(businessEdit, params),
	onBusinessDel = (params = {}) => vm.$u.get(businessDel, params),
	getBusinessContacts = (params = {}) => vm.$u.get(businessContacts, params),
	onContactsCorrelation = (params = {}) => vm.$u.post(contactsCorrelation, params),
	onBusinessContactsDel = (params = {}) => vm.$u.post(businessContactsDel, params),
	getContactsList = (params = {}) => vm.$u.get(contactsList, params),
	onContactsAdd = (params = {}) => vm.$u.post(contactsAdd, params),
	getContactsEdit = (params = {}) => vm.$u.get(contactsEdit, params),
	onContactsEdit = (params = {}) => vm.$u.post(contactsEdit, params),
	onContactsDel = (params = {}) => vm.$u.post(contactsDel, params),
	getBacklog = (params = {}) => vm.$u.get(backlog, params),
	onBacklogVerify = (params = {}) => vm.$u.post(backlogVerify, params),
	getBacklogVerify = (params = {}) => vm.$u.get(backlogVerify, params),
	getlogList = (params = {}) => vm.$u.get(logList, params),
	getContractRanking = (params = {}) => vm.$u.get(contractRanking, params),
	getReceivablesRanking = (params = {}) => vm.$u.get(receivablestRanking, params),
	getCustomerRanking = (params = {}) => vm.$u.get(customerRanking, params),
	getRecordRanking = (params = {}) => vm.$u.get(recordRanking, params),
	getProductRanking = (params = {}) => vm.$u.get(productRanking, params),
	getCustomerIndex = (params = {}) => vm.$u.get(customerIndex, params),
	getIndustry = (params = {}) => vm.$u.get(industry, params),
	getLevel = (params = {}) => vm.$u.get(level, params),
	getSource = (params = {}) => vm.$u.get(source, params),
	getArea = (params = {}) => vm.$u.get(area, params),
	getAllarea = (params = {}) => vm.$u.get(allarea, params),
	getBaseConfig = (params = {}) => vm.$u.get(baseConfig, params),
	onGetInfo = (params = {}) => vm.$u.get(getInfo, params),
	getCustomerSelectpage = (params = {}) => vm.$u.post(customerSelectpage, params),
	getAdminList = (params = {}) => vm.$u.get(adminList, params),
	getAchievementIndex = (params = {}) => vm.$u.get(achievementIndex, params),
	getAchievementAdmin = (params = {}) => vm.$u.get(achievementAdmin, params),
	onAchievementEdit = (params = {}) => vm.$u.post(achievementEdit, params),
	onAchievementAedit = (params = {}) => vm.$u.post(achievementAedit, params),
	getFieldsSelectpage = (params = {}) => vm.$u.get(fieldsSelectpage, params),
	onUnbind = (params = {}) => vm.$u.post(unbind, params),
	getNoticeTpl = (params = {}) => vm.$u.get(noticeTpl, params),
	onBatchTeam = (params = {}) => vm.$u.post(batchTeam, params),
	onBatchAdmin = (params = {}) => vm.$u.post(batchAdmin, params),
	getAllAdmin = (params = {}) => vm.$u.get(allAdmin, params),
	getThirdlist = (params = {}) => vm.$u.get(thirdlist, params),
	getCluesList = (params = {}) => vm.$u.get(cluesList, params),
	onCluesAdd = (params = {}) => vm.$u.post(cluesAdd, params),
	onCluesEdit	= (params = {}) => vm.$u.post(cluesEdit, params),
	getCluesEdit = (params = {}) => vm.$u.get(cluesEdit, params),
	onCluesDel = (params = {}) => vm.$u.post(cluesDel, params),
	getCluesTransform = (params = {}) => vm.$u.get(cluesTransform, params),
	postCluesTransform = (params = {}) => vm.$u.post(cluesTransform, params),
	onShiftDivert = (params = {}) => vm.$u.post(shiftDivert, params),
	onCluesRecord = (params = {}) => vm.$u.post(cluesRecord, params),
	getCluesRecordList = (params = {}) => vm.$u.get(cluesRecordList, params),
	onQywxH5 = (params = {}) => vm.$u.post(qywxH5, params),
	onQywxMp = (params = {}) => vm.$u.post(qywxMp, params),
	getReduplicate = (params = {}) => vm.$u.get(reduplicate, params),
	getCluesCommon = (params = {}) => vm.$u.get(cluesCommon, params),
	onCluesReceive = (params = {}) => vm.$u.post(cluesReceive, params),
	onCluesDiscard = (params = {}) => vm.$u.post(cluesDiscard, params),
	getSmsList = (params = {}) => vm.$u.get(sms, params),
	getEmailList = (params = {}) => vm.$u.get(emailList, params),
	onSendSms = (params = {}) => vm.$u.post(sendSms, params),
	getSendSms = (params = {}) => vm.$u.get(sendSms, params),
	onSendEmail = (params = {}) => vm.$u.post(email, params),
	getEmail = (params = {}) => vm.$u.get(email, params),
	onCloudcall = (params = {}) => vm.$u.post(cloudcall, params),
	getCloudcallMode = (params = {}) => vm.$u.get(cloudcallMode, params),
	postCloudcallMode = (params = {}) => vm.$u.post(cloudcallMode, params),
	onSignin = (params = {}) => vm.$u.post(signin, params),
	getPayurl = (params = {}) => vm.$u.get(payurl, params),
	getGeocoder = (params = {}) => vm.$u.get(geocoder, params),
	getRenewPayurl = (params = {}) => vm.$u.get(renewPayurl, params)






	// 将各个定义的接口名称，统一放进对象挂载到vm.$u.api(因为vm就是this，也即this.$u.api)下
	vm.$u.api = {
		getSearch, 
		accountLogin,
		onWxlogin,
		onMplogin,
		getInit,
		onBind,
		goUpload,
		onLogout,
		lookAdmin,
		getGroupdata,
		onAdminAdd,
		onAdminEdit,
		getAdminEdit,
		onAdminDel,
		onSelectpage,
		getCustomerList,
		onCustomerAdd,
		onCustomerEdit,
		getCustomer,
		onCustomerDel,
		getCommon,
		onDiscard,
		getReceive,
		onDivert,
		getContractlist,
		getReceivableslist,
		onOpenAdd,
		getProfile,
		postProfile,
		getProductUnit,
		onProductUnitEdit,
		onProductUnitAdd,
		getProductType,
		onProductTypeEdit,
		onProductTypeAdd,
		getProductList,
		onProductAdd,
		onProductEdit,
		getProductEdit,
		onProductDel,
		getProductTypeList,
		getProductTypeProp,
		getProductUnitList,
		getFields,
		getHome,
		getAchievement,
		getRecord,
		onRecordAdd,
		onRecordDel,
		getReceivables,
		onReceivablesAdd,
		getReceivablesAdd,
		onReceivablesEdit,
		getReceivablesEdit,
		onReceivablesDel,
		onAnalysis,
		onAnalysisRecord,
		onContractSelectpage,
		onAchievementAnalysis,
		getContractIndexList,
		onContractAdd,
		getContractAdd,
		onContractEdit,
		getContractEdit,
		onContractDel,
		onCommonSelectpage,
		getSubscribe,
		postSubscribe,
		onBusinessRecord,
		onBusinessRecordAdd,
		onBusinessRecordDel,
		onBusinessList,
		onBusinessAdd,
		onBusinessEdit,
		getBusinessEdit,
		onBusinessDel,
		getBusinessContacts,
		onContactsCorrelation,
		onBusinessContactsDel,
		getContactsList,
		onContactsAdd,
		getContactsEdit,
		onContactsEdit,
		onContactsDel,
		getBacklog,
		onBacklogVerify,
		getBacklogVerify,
		getlogList,
		getContractRanking,
		getCustomerRanking,
		getReceivablesRanking,
		getRecordRanking,
		getProductRanking,
		getCustomerIndex,
		getIndustry,
		getLevel,
		getSource,
		getArea,
		getAllarea,
		getBaseConfig,
		onGetInfo,
		getCustomerSelectpage,
		getAdminList,
		getAchievementIndex,
		getAchievementAdmin,
		onAchievementEdit,
		onAchievementAedit,
		getFieldsSelectpage,
		onUnbind,
		getNoticeTpl,
		onBatchTeam,
		onBatchAdmin,
		getAllAdmin,
		getThirdlist,
		getCluesList,
		onCluesAdd,
		onCluesEdit,
		getCluesEdit,
		onCluesDel,
		postCluesTransform,
		onShiftDivert,
		getCluesTransform,
		onCluesRecord,
		getCluesRecordList,
		onQywxH5,
		onQywxMp,
		getReduplicate,
		getCluesCommon,
		onCluesReceive,
		onCluesDiscard,
		getSmsList,
		onSendEmail,
		onSendSms,
		getSendSms,
		getEmail,
		getEmailList,
		onCloudcall,
		getCloudcallMode,
		postCloudcallMode,
		onSignin,
		getPayurl,
		getGeocoder,
		getRenewPayurl
		
	};
}

export default {
	install
}