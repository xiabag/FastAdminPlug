<template>
	<view class="container">
		<view class="title u-m-b-45">
			<text class="u-p-r-10">{{refresh_token ? '绑定账号' : '账号登录'}}</text>
		</view>
		<view class="input-box">
			<view class="item">
				<u-input v-model="name" required :error-message="errorName" :custom-style="inputColor" placeholder="账号" />
			</view>
			<view class="item">
				<u-input v-model="password" type="password" required :error-message="errorPassword" :custom-style="inputColor" placeholder="密码" />
			</view>
			<view class="item u-flex" v-if="vuex_config.login_captcha">
				<u-input class="u-flex-1" v-model="captcha" :custom-style="inputColor" placeholder="验证码" ></u-input>
				<view class="code_image" @click="changeImgCode">
					<image class="img" :src="code_image"/>
				</view>
			</view>
		</view>
		<view class="bottom-bt">
			<view class="space">
				<u-button type="success" :custom-style="{backgroundColor: vuex_theme.color, color: vuex_theme.bgColor,fontSize: '30rpx',fontWeight: '600'}" :ripple="true"  @click="onLogin">{{refresh_token ? '绑定登录' : '登录'}}</u-button>
			</view>
			<view class="u-flex u-row-center u-m-t-15">
				<text style="color:#506286" >忘记密码请联系管理员</text>
			</view>
		</view>
	</view>
</template>

<script>
	import { processingImages,getImgUrl} from '@/common/mUtils'
	import { baseUrl} from '@/common/config.js'
	export default {
		data() {
			return {
				refresh_token: '',
				inputColor: {
					backgroundColor: "#F7F7F7",
				},
				errorName: '',
				errorPassword: '',
				name: '',
				password: '',
				captcha:'',
				code_image: '',
				type: '',
			};
		},
		filters: {
			//图片地址url 拼接
			changImg(val) {
				if (val) {
					return getImgUrl(val)
				} else {
					return '' 
				}
			},
		},
		onLoad(e) {
			this.type = e.type ? e.type : ''
			// 是否是绑定账号
			if(e.refresh_token){
				this.refresh_token = e.refresh_token
			}
			this.changeImgCode();
		},
		onShow() {
			// 是否有token，有token直接跳转首页
			if(!this.$u.test.isEmpty(this.vuex_token) && this.$u.test.isEmpty(this.type)) {
				uni.switchTab({
					url: '/pages/index/index'
				});
			}
		},
		methods: {
			changeImgCode() {
				var num = Math.round(new Date()/1000);
				var code_image = baseUrl+"/addons/facrm/captcha/index/?num=" + num;
				uni.request({
					url:code_image, 
					success: (res) => {
					console.log(res);
					this.sid=res.data.data;
					this.code_image=code_image +"&sid="+this.sid;
					}
				});
			},
			onLogin(e) {
				let _this = this
				// 验证
        if (!_this.name) {
					_this.$u.toast('请输入名字');
          return false;
        }
        if (!_this.password) {
					_this.$u.toast('请输入密码');
          return false;
        }
				uni.showLoading({
					title: "请稍后...",
					mask: true
				});
				if(this.refresh_token) {
					let platform = ''
					// #ifdef MP-WEIXIN 
						platform = 'admin_min'
					// #endif

					// #ifdef H5
						platform = 'admin_mp'
					// #endif
					let obj = {
						username: this.name,
						password: this.password,
						refresh_token: this.refresh_token,
						platform: platform,
						sid:this.sid,
					}
					// 是否需要验证码
					if(this.vuex_config.login_captcha){
						obj.captcha = this.captcha
					}
					// 绑定原来的账号
					_this.$u.api.onBind(obj).then(res => {
						if(res.code == 1) {
							// vuex储存 token
							_this.$u.vuex('vuex_token', res.data.token)
							uni.hideLoading();
							uni.showToast({
								title: res.msg,
								icon: 'success',
								duration: 2000
							})
							setTimeout(() => {
								uni.switchTab({
									url: '/pages/index/index'
								});
							}, 1000)
						}else{
							this.changeImgCode();
						}
					})
				} else {
					let obj = {
						username: this.name,
						password: this.password,
						sid:this.sid,
					}
					// 是否需要验证码
					if(this.vuex_config.login_captcha){
						obj.captcha = this.captcha
					}
					// 账号密码登录
					_this.$u.api.accountLogin(obj).then(res => {
						if(res.code == 1) {
							// vuex储存 token
							_this.$u.vuex('vuex_token', res.data.token)
							_this.$u.vuex('vuex_admin', res.data);//存储登录的信息
							uni.hideLoading();
							uni.showToast({
								title: res.msg,
								icon: 'success',
								duration: 2000
							})
							setTimeout(() => {
								uni.switchTab({
									url: '/pages/index/index'
								});
							}, 1000)
						}else{
							this.changeImgCode();
						}
					})
				}
			},
			// 提示验证
			verify() {
				this.errorMobile = ''
				this.errorName = ''
			},
			look() {
				this.$u.route('pages/login/clause');
			},
			// 关闭提示
			colse() {
				this.referrerShow = !this.referrerShow
			},
		}
	}
</script>

<style lang="scss" scoped>
.container {
	position: relative;
	padding: 45rpx 60rpx;
	min-height: 100vh;
}
.name {
	font-size: 32rpx;
}
.title {
	font-size: 42rpx;
	font-weight: 600;
	text-align: center;
}
.item {
	background: #F7F7F7;
	padding: 15rpx 28rpx 15rpx 35rpx;
	margin-bottom: 25rpx;
	.code_image {
		width: 180rpx;
		height: 70rpx;
		.img {
			width: 100%;
			height: 100%;
		}
	}
}
.bottom-bt {
	text-align: center;
	padding: 45rpx 0;
}
</style>
