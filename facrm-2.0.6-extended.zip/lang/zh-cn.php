<?php

return [
    'Admin group'                                           => '超级管理组',
    'Second group'                                          => '二级管理组',
    'Third group'                                           => '三级管理组',
    'Second group 2'                                        => '二级管理组2',
    'Third group 2'                                         => '三级管理组2',
];
