<?php

namespace addons\facrm\library;

use think\Db;

class Helper
{
    /**
     * 获取参数字段
     * @param string $types types：customer，contacts
     * @param array $field 查询字段
     * @param array $extend 追加字段
     */
    public static function getfield($types = "customer", $field = '*', $extend = array(), $ignore_column = array())
    {
        $prefix = \think\Config::get('database.prefix');
        $table = "";
        switch ($types) {
            case "contacts":
                $table = "{$prefix}facrm_customer_" . $types;
                break;
            case "contract":
            case "business":
            case "customer":
            case "clues":
            case "contract_receivables":
                $table = "{$prefix}facrm_{$types}";
                break;

            default:

        }
        $dbname = \config('database.database');
        //从数据库中获取表字段信息
        $sql = "SELECT * FROM `information_schema`.`columns` WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?  ORDER BY ORDINAL_POSITION";
        //加载主表的列
        $columnList = Db::query($sql, [$dbname, $table]);

        if ($field!="*"){
            $field=explode(',', $field);
        }

        foreach ($columnList as $index => $item) {
            if (in_array($item['COLUMN_NAME'], $ignore_column)) {
                continue;
            }
            if (is_array($field)&&!in_array($item['COLUMN_NAME'], $field)){
                continue;
            }
            $fieldlist[$item['COLUMN_NAME']] = $item['COLUMN_COMMENT'];
        }

        return array_merge($extend, $fieldlist);
    }


    /**
     * 根据规则自动生成编码
     * @param $prefix
     * @return int|mixed|string
     */
    public static function autoNo($prefix){
        $replace_data=['Y'=>date('Y'),'m'=>date('m'),'d'=>date('d'),'h'=>date("H"),'i'=>date("i"),'s'=>date("s"),'rand'=>rand(100000,999999)];
        return $prefix?__($prefix, $replace_data):'';
    }
}