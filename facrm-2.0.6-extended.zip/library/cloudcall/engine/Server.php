<?php

namespace addons\facrm\library\cloudcall\engine;


/**
 * 抽象类
 * Class server
 */
abstract class Server
{
    /**
     * 错误信息
     * @var
     */
    protected $error;
    protected $config;
    /**
     * 返回错误信息
     * @return mixed
     */
    public function getError()
    {
        return $this->error;
    }
    public function setError($msg){
        $this->error=$msg;
    }


}
