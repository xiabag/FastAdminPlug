<?php

namespace addons\facrm\library\notice;

use think\Exception;

class Notice
{

    /**
     * 配置信息
     * @var array
     */
    private $config = [];

    /**
     * 服务提供者
     * @var array
     */
    private $providers = [
        'Mp' => 'Mp',
        'Min' => 'Min',
        'Email' => 'Email',
		'WXWork' => 'WXWork',
        'Dingding' => 'Dingding',
    ];
    protected static $instance = null;

    private $engine;    // 当前引擎类

    public function __construct($options = [])
    {
        $this->config = array_merge($this->config, is_array($options) ? $options : []);

        //注册服务提供者
        if (isset($this->config['key'])){
            $this->engine = $this->registerProviders();
        }

    }
    /**
     *
     * @param array $options 参数
     * @return $this
     */
    public static function instance($options = [])
    {
        if (is_null(self::$instance)) {
            self::$instance = new static($options);
        }else{
            if (isset($options['key'])){
                self::$instance->engine = self::$instance->registerProviders();
            }
        }

        return self::$instance;
    }

    public function send($config,$data,$replace_data=array())
    {
        try {
            return $this->engine->send($config,$data,$replace_data);
        }catch (Exception $e){
            $this->getError();
            return  false;
        }

    }


    /**
     * 获取通知类型
     * @return array|string[]
     */
    public static function getProviders()
    {
        return (new  self())->providers;
    }

    /**
     * 注册服务提供者
     */
    private function registerProviders()
    {
        $objname = __NAMESPACE__ . "\\engine\\" . $this->providers[$this->config['key']];
        return new $objname($this->config);
    }

    /**
     * 获取默认通知模板数据
     */
    public static function getTempLplData()
    {
        return array(
            [
                'id' => 1,
                'key' => "notice_flow_contract",
                'describe' => __("待审批合同"),
                'status' => 0,
                'values' => [
                    'content'=>'您有({:name})合同待审批',
                    'engine'=>'',
                ],
            ],
            [
                'id' => 2,
                'key' => "notice_flow_receivables",
                'describe' => __("待审批回款"),
                'status' => 0,
                'values' => [
                    'content'=>'您有待回款审批，回款编号{:number},金额:{:money}',
                    'engine'=>'',
                ],

            ],
            [
                'id' => 3,
                'key' => "notice_flow_customer",
                'describe' => __("待跟进客户"),
                'status' => 0,
                'values' => [
                    'content'=>'您有{:count}个客户需要跟进',
                    'engine'=>'',
                ],
            ],
            [
                'id' => 4,
                'key' => "notice_flow_business",
                'describe' => __("待跟进商机"),
                'status' => 0,
                'values' => [
                    'content'=>'您有{:count}个商机需要跟进',
                    'engine'=>'',
                ],
            ],
            [
                'id' => 5,
                'key' => "notice_expire_contract",
                'describe' => __("将过期合同"),
                'status' => 0,
                'values' => [
                    'content'=>'您有{:count}个合同将要过期',
                    'engine'=>'',
                ],
            ],
            [
                'id' => 6,
                'key' => "notice_expire_ccustomer",
                'describe' => __("将掉进公海客户"),
                'status' => 0,
                'values' => [
                    'content'=>'您有{:count}个合同将要过期',
                    'engine'=>'',
                ],
            ],
            [
                'id' => 7,
                'key' => "notice_pass_contract",
                'describe' => __("审批通过合同"),
                'status' => 0,
                'values' => [
                    'content'=>'合同({:name})审批通过',
                    'engine'=>'',
                ],
            ],
            [
                'id' => 8,
                'key' => "notice_pass_receivables",
                'describe' => __("审批通过回款"),
                'status' => 0,
                'values' => [
                    'content'=>'回款审批通过，回款编号{:number},金额:{:money}',
                    'engine'=>'',
                ],
            ],
            [
                'id' => 9,
                'key' => "notice_nopass_receivables",
                'describe' => __("回款驳回"),
                'status' => 0,
                'values' => [
                    'content'=>'回款被驳回，回款编号{:number},金额:{:money}',
                    'engine'=>'',
                ],
            ],
            [
                'id' => 10,
                'key' => "notice_nopass_contract",
                'describe' => __("合同驳回"),
                'status' => 0,
                'values' => [
                    'content'=>'合同({:name})被驳回',
                    'engine'=>'',
                ],
            ],
            [
            'id' => 3,
            'key' => "notice_flow_clues",
            'describe' => __("待跟进线索"),
            'status' => 0,
            'values' => [
                'content'=>'您有{:count}个线索需要跟进',
                'engine'=>'',
            ],
            ],

        );
    }

    /**
     * 获取错误信息
     * @return mixed
     */
    public function getError()
    {
        return $this->engine->getError();
    }


}
