<?php

namespace addons\facrm\library\notice\engine;

use app\admin\model\Admin;
use fast\Http;
use addons\electronics\model\Area;
use think\Queue;

/**
 * 邮件通知
 * @author amplam 122795200@qq.com
 * @Date   2021年8月18日
 */
class Email extends Server
{



    /**
     * 构造方法
     * WxPay constructor.
     * @param $config
     */
    public function __construct($config = array())
    {
        $this->config = $config;
    }

    /**
     * 发送通知
     * @param $config
     * @param $data
     * @param array $replace_data
     * @return bool
     */
    public function send($config,$data,$replace_data=array()){
        //获取多个人的邮箱
        $emails = (new Admin())->where('email', '<>', '')->where('id', 'in', $data['admin_ids'])
            ->where('status', 'normal')->column('email');
        if (!$emails) return  false;

        //邮件队列
        $send_data = [
            'subject' => $config['describe'] . __("通知"),
            'to' => implode(",", $emails),
            'message' => __($config->values['content'], $replace_data),
        ];
       return Queue::push("addons\\facrm\\library\\queue\\EmailJob", $send_data);
    }

}