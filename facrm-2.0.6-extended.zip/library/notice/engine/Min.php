<?php

namespace addons\facrm\library\notice\engine;

use app\admin\model\Admin;
use fast\Http;
use think\Queue;

/**
 * 小程序通知
 * @author amplam 122795200@qq.com
 * @Date   2021年8月18日
 */
class Min extends Server
{


    /**
     * 构造方法
     * WxPay constructor.
     * @param $config
     */
    public function __construct($config = array())
    {
        $this->config = $config;
    }

    /**
     * 发送通知
     * @param $config
     * @param $data
     * @param array $replace_data
     * @return bool
     */
    public function send($config, $data, $replace_data = array())
    {
        $platform = 'admin_min';//微信公众号
        //判断是否安装了第三方登录
        $third = get_addon_info('third');
        if (!$third || $third['state'] != 1) {
            return false;
        }
        //获取openids
        $thirdModel = new \addons\third\model\Third();
        $openids = $thirdModel->where('platform', $platform)->where('user_id', 'in', $data['admin_ids'])->column('openid');
        if (!$openids) return false;

        $tpl = $config->values['content'];
        $tpl = is_array($tpl) ? $tpl : (array)json_decode($tpl, true);
        foreach ($tpl as $item) {

            $value = str_replace('.DATA}}', '', str_replace('{{', '', $item['value']));

            if ($value) {
                $data_temp[$value] = [
                    'value' => ($item['key'] != 'diy_text') ?
                        ($item['def_val'] ? $item['def_val'] :
                            (isset($replace_data[$item['key']]) ? $replace_data[$item['key']] : ''))
                        : $item['def_val']
                ];
            }
        }


        $t_config = get_addon_config('facrm');
        $app = \EasyWeChat\Factory::miniProgram([
            'app_id' => $t_config['min_app_id'],
            'secret' => $t_config['min_app_secret'],
            'response_type' => 'array',
        ]);
        //发送模板消息

        foreach ($openids as $openid) {
            try {
                $res = $app->subscribe_message->send([
                    'touser' => $openid,
                    'template_id' => $config->values['tpl_id'],
                    'page' => isset($config->values['url']) ? $config->values['url'] : '',
                    'data' => $data_temp,
                ]);
                \think\Log::write($res,'error');
                \think\Log::write($data_temp,'error');
            } catch (\Exception $e) {
                $this->error .= $e->getMessage();
            }
        }
    }
}