<?php

namespace addons\facrm\library\notice\engine;


/**
 * 抽象类
 * Class server
 */
abstract class Server
{
    /**
     * 错误信息
     * @var
     */
    protected $error;

    /**
     * 返回错误信息
     * @return mixed
     */
    public function getError()
    {
        return $this->error;
    }


}
