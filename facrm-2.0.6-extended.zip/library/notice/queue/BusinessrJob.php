<?php


namespace addons\facrm\library\notice\queue;

use app\admin\model\Admin;
use app\common\library\Email;
use think\Log;
use think\Queue;
use think\queue\job;
use think\Validate;

/**
 * 和客商机相关通知队列
 * Class FlowContractJob
 * @package addons\facrm\library\notice\queue
 */
class BusinessrJob
{
    public function fire(Job $job, $data)
    {
        if ($job->attempts() > 3) {
            //通过这个方法可以检查这个任务已经重试了几次了
            $job->delete();
            return;
        }
        $key=$data['key'];
        $notice_types = \addons\facrm\library\notice\Notice::getProviders();
        $keys = "";
        foreach ($notice_types as $v) {
            $keys .= $keys ? ',' . $key . $v : $key . $v;
        }
        $settingModel = new \app\admin\model\facrm\Setting();
        $setinglist = $settingModel->where('key', 'in', $keys)->where('status', 1)->select();

        if (!$setinglist) {
            $job->delete();
            return false;
        }
        foreach ($setinglist as $r) {
            if (!$r->values['engine']) continue;
            $notice_app = new \addons\facrm\library\notice\Notice(['key'=>$r->values['engine']]);
            $notice_app->send($r,$data,$data);
        }
        return true;

    }

    public function failed($data)
    {
        Log::write("和客户相关通知队列：" . print_r(['data' => $data,], true), 'error');
    }

}