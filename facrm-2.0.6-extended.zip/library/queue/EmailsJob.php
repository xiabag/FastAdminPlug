<?php


namespace addons\facrm\library\queue;

use app\common\library\Email;
use think\Log;
use think\queue\job;
use think\Validate;

/**
 * 批量发送邮件队列
 * Class EmailsJob
 * @package addons\facrm\library\queue
 */
class EmailsJob
{
    /**
     * @param job $job
     * @param $data['types'] //发送配置，types：customer，contacts
     * @param $data['typesid'] //对象集合ID，多个以逗号隔开
     * @param $data['title'] //邮件标题
     * @param $data['content'] //邮件正文
     * @param $data['create_user_id'] //邮件发送人ID
     * @param $data['record_type'] //跟进类型ID
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function fire(Job $job, $data){
        if ($job->attempts() > 3) {
            //通过这个方法可以检查这个任务已经重试了几次了
            $job->delete();
            return;
        }
        $types_data = array();//发送对象数据，如客户，联系人
        if ($data && $data['types']) {
            switch ($data['types']) {
                case "customer":
                    $custModel = new \app\admin\model\facrm\Customer();
                    $types_data = $custModel->where('id','in',$data['typesid'])->select();
                    break;
                case "contacts":
                    $contactsModel = new \app\admin\model\facrm\customer\Contacts();
                    $types_data = $contactsModel->where('id','in',$data['typesid'])->select();
                    break;
                case "clues":
                    $custModel = new \app\admin\model\facrm\Clues();
                    $types_data = $custModel->where('id','in',$data['typesid'])->select();
                    break;
                default:
                    break;
            }
        }
        if (!$types_data) {
            $job->delete();
            return true;
        }
        $email = new Email();
        foreach ($types_data as $row){
            if (!empty($row['email'])) {
                if (!Validate::is($row['email'], "email")) {
                    continue;//不存在邮箱下一步
                }

                $result = $email->subject($data['title'])
                    ->to($row['email'])// $email 收件人,多个收件人以,进行分隔
                    ->message($data['content'])
                    ->send();

                if ($result) {
                    //param_data types类型如customer,contacts| typesid对应的ID
                    //send_data发送邮件的内容
                    //types_data 当前对象的数据
                    $row['create_user_id'] = $data['create_user_id'];//用于标明是谁发送的
                    $row['record_type']=$data['record_type'];
                    hook("facrm_send_email_success", array('param_data' => $data, 'send_data' => $row, 'types_data' => $types_data));
                }
            } else {
                Log::write("邮件发送失败：".print_r([
                        'name' => $job->getName(),
                        'error'=> $email->getError()
                    ],true),'error');
            }
        }

        $job->delete();
        return true;

    }

    public function failed($data){
        Log::write("邮件任务失败：".print_r(['data' => $data,],true),'error');
    }

}