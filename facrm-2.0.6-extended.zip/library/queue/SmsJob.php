<?php

namespace addons\facrm\library\queue;

use app\common\library\Sms;
use think\Log;
use think\queue\job;

/**
 * 短息发送
 * Class SmsJob
 * @package addons\facrm\library\queue
 */
class SmsJob
{
    public function fire(Job $job, $data){

        if ($job->attempts() > 3) {
            //通过这个方法可以检查这个任务已经重试了几次了
            $job->delete();
            return;
        }

        $result = Sms::notice($data['mobile'],$data['msg'],$data['template']);
        if($result){
            $job->delete();
        }else{
            $job->release();
            Log::write("短息发送失败：".print_r([
                    'name' => $job->getName(),
                ],true),'error');
        }
    }

    public function failed($data){
        Log::write("短信任务失败：".print_r(['data' => $data,],true),'error');
    }
}