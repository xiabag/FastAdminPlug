<?php

namespace addons\facrm\library\qywx;

use think\Exception;

/**
 * 企业微信回调事件类
 * Class Event
 * @package addons\facrm\library\qywx
 */
class Event
{
    protected $error=null;

    public  static  function execute(&$params){
        $self=new  self();
        try {
            $event=$params['Event'];
            return $self->$event($params);
        }catch (\Exception $e){

            $self->error=('操作失败:'.$e->getMessage());
            \think\Log::write($e->getMessage().$e->getFile().$e->getLine(),'error');
            return  false;

        }

    }

    /**
     * 修改员工信息事件
     * @param $params
     * @return bool|false|int
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * @throws \think\exception\PDOException
     */
    private function change_contact(&$params){
        if (!isset($params['UserID'])){
            return false;
        }
        $qywxUser= \app\admin\model\facrm\qywx\User::getUser($params['UserID']);
        if (!$qywxUser) return  false;

        switch ($params['ChangeType']){
            case 'update_user':
                //更新了员工信息
                /**
                 * `corp_id` varchar(120) NOT NULL COMMENT '企业ID',
                `userid` varchar(250) NOT NULL COMMENT '成员userid',
                `name` varchar(250) NOT NULL COMMENT '成员名称',
                `mobile` varchar(20) DEFAULT NULL COMMENT '成员手机号码',
                `email` varchar(250) DEFAULT NULL COMMENT '成员邮箱',
                `avatar` varchar(250) DEFAULT NULL COMMENT '头像url',
                `gender` tinyint(1) NOT NULL DEFAULT '0' COMMENT '性别。0表示未定义，1表示男性，2表示女性',
                `position` varchar(250) DEFAULT NULL COMMENT '职务信息',
                `qr_code` varchar(250) DEFAULT NULL COMMENT '客户联系二维码',
                `status` varchar(30) NOT NULL DEFAULT '' COMMENT '激活状态: 1=已激活，2=已禁用，4=未激活，5=退出企业',
                 *
                 */
                if (isset($params['Name'])){//昵称
                    $qywxUser->name=$params['Name'];
                    $qywxUser->admin->nickname=$params['Name'];
                }
                if (isset($params['Status'])){//禁用
                    $qywxUser->status=$params['Status'];
                    if (in_array($params['Status'],[2,4,5])){
                        $qywxUser->admin->status="normal";
                    }else{
                        $qywxUser->admin->status="hidden";
                    }
                }
                if (isset($params['Position'])){//职位
                    $qywxUser->position=$params['Position'];
                }
                if (isset($params['Avatar'])){//头像
                    $qywxUser->avatar=$params['Avatar'];
                }
                if (isset($params['Gender'])){//性别
                    $qywxUser->gender=$params['Gender'];
                }
                $qywxUser->admin->save();
                return  $qywxUser->save();

        }

        return  false;
    }


}