<?php

namespace addons\facrm\model;

use addons\third\model\Third;
use think\Model;
use think\Session;

class Admin extends \app\admin\model\Admin
{

    /**
     * 用户登录（小程序用）并返回解密信息
     * @param array $post code，encrypted_data，iv
     * @return string
     */
    public function minLogin($post)
    {
        // 获取配置
        $setting=get_addon_config('facrm');
        if (empty($setting['min_app_id'])||empty($setting['min_app_secret'])){
            $this->error="小程序未配置。";
            return  false;
        }
        //微信配置
        $config = [
            'app_id'  =>$setting['min_app_id'], // AppID
            'secret'  => $setting['min_app_secret'], // AppSecret
        ];

        $data=array();
        try{
            $app = \EasyWeChat\Factory::miniProgram($config);
            $session_key= $app->auth->session($post['code']);
            if (empty($session_key)||!isset($session_key['session_key'])){
                $this->error=__("获取session_key错误");
                return  false;
            }
            $data = $app->encryptor->decryptData($session_key['session_key'], $post['iv'], $post['encrypted_data']);
        }catch (\Exception $e){
            $this->error=$e->getMessage();
            return  false;
        }
        return $data;

    }

    /**
     * 用户登录（公众号）
     * @return string
     */
    public function mpLogin()
    {
        // 获取配置
        $setting=get_addon_config('third');
        if (empty($setting['wechat']['app_id'])||empty($setting['wechat']['app_secret'])){
            $this->error="微信公众号未配置。插件->第三方登录->设置";
            return  false;
        }
        //微信配置
        $config = [
            'app_id'  =>$setting['wechat']['app_id'], // AppID
            'secret'  => $setting['wechat']['app_secret'], // AppSecret
        ];
        $data=array();
        try{
            $app = \EasyWeChat\Factory::officialAccount($config);
            $oauth = $app->oauth;
            $data = $oauth->user()->toArray();
        }catch (\Exception $e){
            $this->error=$e->getMessage();
            return  false;
        }
        return $data;

    }





    /**
     * 第三方登录
     * @param string $platform 平台
     * @param array  $params   参数
     * @param array  $extend   会员扩展信息
     * @param int    $keeptime 有效时长
     * @return Third
     */
    public  function connects($platform, $params = [], $extend = [], $keeptime = 0)
    {

        $time = time();
        $nickname = $params['nickname'] ?? ($params['userinfo']['nickname'] ?? '');
        $avatar = $params['avatar'] ?? ($params['userinfo']['avatar'] ?? '');
        $values = [
            'platform'      => $platform,
            'openid'        => $params['openid'],
            'unionid'        => isset($params['unionid'])?$params['unionid']:'',
            'openname'      => $nickname,
            'access_token'  => $params['access_token'],
            'refresh_token' => $params['refresh_token'],
            'expires_in'    => $params['expires_in'],
            'logintime'     => $time,
            'expiretime'    => $time + $params['expires_in'],
        ];
        $values = array_merge($values, $params);


        //是否有自己的
        $third = Third::get(['platform' => $platform, 'openid' => $params['openid']]);

        if (!$third) {
            if (isset($params['unionid']) && !empty($params['unionid'])) {
                //存在unionid就需要判断是否需要生成新记录
                $third = Third::get(['platform' => $platform, 'unionid' => $params['unionid']]);
            }
            if (!$third) {
                //不存在就添加第三方登录信息
                return Third::create($values, true);
            }
        }
        if ($third){
            $third->logintime=$time;
            $third->refresh_token=$params['refresh_token'];
            $third->isUpdate(true)->save();
        }
        return  $third;




    }


}
