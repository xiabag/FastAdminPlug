require.config({
    paths: {
        'editable': '../libs/bootstrap-table/dist/extensions/editable/bootstrap-table-editable.min',
        'x-editable': '../addons/facrm/js/bootstrap-editable.min',
    },
    shim: {
        'editable': {
            deps: ['x-editable', 'bootstrap-table']
        },
        "x-editable": {
            deps: ["css!../addons/facrm/css/bootstrap-editable.css"],
        }
    }
});

define(['jquery', 'bootstrap', 'backend', 'table', 'form', 'editable'], function ($, undefined, Backend, Table, Form,Editable) {
    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'facrm/achievement/index',
                    admin_url: 'facrm/achievement/admin',
                    add_url: '',
                    edit_url: 'facrm/achievement/edit',
                    aedit_url: 'facrm/achievement/aedit',
                    del_url: '',
                    multi_url: '',
                    table: '',
                }
            });
            var table = $("#table");

            //在表格内容渲染完成后回调的事件
            table.on('post-body.bs.table', function (e, json) {
                var myDate = new Date;
                var year = myDate.getFullYear(); //获取当前年
                var form = $("form", table.$commonsearch);
                $(".commonsearch-table input[name=search_time]").val(year);
                $(".commonsearch-table select[name=config]").val(1);

            });
            table.on('load-success.bs.table', function (e, data) {
                $(".commonsearch-table input[name=search_time]").val(data.extend.year);
                $(".commonsearch-table select[name=config]").val(data.extend.config);
            });


            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                commonSearch: true,
                search: false,
                searchFormVisible: true,
                columns: [
                    [
                        {field: 'id', title: 'ID',operate: false},
                        {field: 'name', title: __('Name'), align: 'left', formatter:function (value, row, index) {
                                return value.toString().replace(/(&|&amp;)nbsp;/g, '&nbsp;');
                            },operate: false
                        },
                        {field: 'achievement.yeartarget', title: __('全年'), align: 'left',operate: false,  formatter:function (value, row, index) {
                                return  !value?0:value;
                         }},
                        {field: 'achievement.january', title: __('1月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {field: 'achievement.february', title: __('2月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {field: 'achievement.march', title: __('3月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {field: 'achievement.april', title: __('4月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {field: 'achievement.may', title: __('5月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {field: 'achievement.june', title: __('6月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {field: 'achievement.july', title: __('7月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {field: 'achievement.august', title: __('8月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {field: 'achievement.september', title: __('9月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {field: 'achievement.october', title: __('10月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {field: 'achievement.november', title: __('11月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {field: 'achievement.december', title: __('12月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {
                            field: 'config',
                            title: __('业绩方式'),
                            visible:false,
                            searchList:{1:"合同金额",2:"回款金额",}
                        },
                        {
                            field: 'group_id',
                            title: __('成员组'),
                            visible:false,
                            searchList:Config.groupdata
                        },
                        {
                            field: 'search_time',
                            title: __('年度'),
                            formatter: Table.api.formatter.datetime,
                            operate: 'RANGE',
                            addclass: 'datetimepicker',
                            data: 'data-date-format="YYYY"',
                            visible:false
                        },

                    ]
                ],
                pagination: false,
                onEditableSave:function (field, row, oldValue, $el) {
                    var data = {};
                    var field_arr = field.split('.');
                    data["row[field]"] =field_arr[1];
                    data["row[" + field_arr[1] + "]"] = row[field];
                    data["row[group_id]"] = row['id'];
                    data["row[config]"] =$(".commonsearch-table select[name=config]").val();
                    //获取年份
                    data["row[year]"] =$(".commonsearch-table input[name=search_time]").val();
                    Fast.api.ajax({
                        url: $.fn.bootstrapTable.defaults.extend.edit_url + "/ids/" + row[this.pk],
                        data: data
                    },function () {
                        $(".btn-refresh").trigger("click");
                    });
                }
            });

            // 为表格绑定事件
            Table.api.bindevent(table);//当内容渲染完成后

            var admin_table = $("#admin_table");
            //在表格内容渲染完成后回调的事件
            admin_table.on('post-body.bs.table', function (e, json) {
                var myDate = new Date;
                var year = myDate.getFullYear(); //获取当前年
                var form = $("form", admin_table.$commonsearch);
                $(".commonsearch-table input[name=search_time]").val(year);
                $(".commonsearch-table select[name=config]").val(1);

            });
            admin_table.on('load-success.bs.table', function (e, data) {
                $(".commonsearch-table input[name=search_time]").val(data.extend.year);
                $(".commonsearch-table select[name=config]").val(data.extend.config);
            });
            // 初始化表格
            admin_table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.admin_url,
                commonSearch: true,
                search: false,
                searchFormVisible: true,
                toolbar: '#toolbar1',
                columns: [
                    [
                        {field: 'id', title: 'ID',operate: false},
                        {field: 'nickname', title: __('Name'), align: 'left',operate: false},
                        {field: 'achievement.yeartarget', title: __('全年'), align: 'left',operate: false,  formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {field: 'achievement.january', title: __('1月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {field: 'achievement.february', title: __('2月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {field: 'achievement.march', title: __('3月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {field: 'achievement.april', title: __('4月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {field: 'achievement.may', title: __('5月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {field: 'achievement.june', title: __('6月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {field: 'achievement.july', title: __('7月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {field: 'achievement.august', title: __('8月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {field: 'achievement.september', title: __('9月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {field: 'achievement.october', title: __('10月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {field: 'achievement.november', title: __('11月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {field: 'achievement.december', title: __('12月'), align: 'left',editable: true,operate: false, formatter:function (value, row, index) {
                                return  !value?0:value;
                            }},
                        {
                            field: 'config',
                            title: __('业绩方式'),
                            visible:false,
                            searchList:{1:"合同金额",2:"回款金额",}
                        },
                        {
                            field: 'group_id',
                            title: __('成员组'),
                            visible:false,
                            searchList:Config.groupdata
                        },
                        {
                            field: 'search_time',
                            title: __('年度'),
                            formatter: Table.api.formatter.datetime,
                            operate: 'RANGE',
                            addclass: 'datetimepicker',
                            data: 'data-date-format="YYYY"',
                            visible:false
                        },

                    ]
                ],
                pagination: false,
                onEditableSave:function (field, row, oldValue, $el) {
                    var data = {};
                    var field_arr = field.split('.');
                    data["row[field]"] =field_arr[1];
                    data["row[" + field_arr[1] + "]"] = row[field];
                    data["row[admin_id]"] = row['id'];
                    data["row[config]"] =$(".commonsearch-table select[name=config]").val();
                    //获取年份
                    data["row[year]"] =$(".commonsearch-table input[name=search_time]").val();
                    Fast.api.ajax({
                        url: $.fn.bootstrapTable.defaults.extend.aedit_url + "/ids/" + row[this.pk],
                        data: data
                    },function () {
                        $(".btn-refresh").trigger("click");
                    });
                }
            });

            // 为表格绑定事件
            Table.api.bindevent(admin_table);//当内容渲染完成后

        },
        add: function () {
            Controller.api.bindevent();
        },
        batchteam:function(){
            Controller.api.bindevent();
            Controller.api.average();

        },
        batchadmin:function(){
            Controller.api.bindevent();
            Controller.api.average();

        },

        api: {
            average:function(){
                $("#average").on("click", function(){
                    var yeartarget=$("input[name^='row[yeartarget]']").val();
                    if(yeartarget>0){
                        var average =yeartarget/12;
                        $('.average_month input').val(average.toFixed(2));
                    }
                });
                $(function() {
                    $(".average_month").bind('input propertychange', function() {
                        var yeartarget=0;
                        $(".average_month input").each(function(){
                            var  temp =$(this).val();
                            if (temp){
                                yeartarget=yeartarget+parseFloat(temp);

                            }
                            $("input[name^='row[yeartarget]']").val(yeartarget);
                        });

                    })
                })
            },
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            },
        }
    };
    return Controller;
});