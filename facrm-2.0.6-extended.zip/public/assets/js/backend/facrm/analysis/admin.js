var index = 1;
define(['jquery', 'bootstrap', 'backend', 'table', 'form', 'echarts'], function ($, undefined, Backend, Table, Form, Echarts) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'facrm/analysis/admin/index',
                    add_url: '',
                    edit_url: '',
                    del_url: '',
                    multi_url: '',
                    table: '',
                }
            });

            var table = $("#table");

            //在普通搜索渲染后
            table.on('post-common-search.bs.table', function (event, table) {
            
             
            });

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                columns: [
                    [
                        {field: 'id', title: 'ID',
							addclass: 'selectpage',
							extend: 'data-source="facrm/common/selectpage/model/admin?type=all" data-field="nickname" data-orderBy="id desc"'},
                        {field: 'nickname', title: __('姓名'), operate: "LIKE"},
                        {field: 'customer_count', title: __('客户增量'), operate: false},
                        {field: 'deal_count', title: __('成交数量'), operate: false},
                        {field: 'deal_rate', title: __('成交率'), operate: false},

                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
            require.config({
                    paths: {
                        'Gzyechart': '../addons/facrm/js/gzyechart',
                    }
                }
            );
            require(['Gzyechart'], function () {
                Form.api.bindevent($("form[role=form]"));
                // 基于准备好的dom，初始化健康表格数据
                Gzyechart.echart.loadEchart("order", Echartdata.order.date, Echartdata.order.data);
                Gzyechart.echart.initButton();
                $(document).on("change", "#c-owner_user_id", function () {
                    var owner_user_id = $(this).val();
                    var datetimerange = $(this).parent().parent().find(".datetimerange");
                    var url = datetimerange.data('url');
                    if (url.indexOf("owner_user_id") != -1) {
                        url = Controller.api.replaceParamVal(url, "owner_user_id", owner_user_id);
                    } else {
                        url = url + "&owner_user_id=" + owner_user_id;
                    }
                    datetimerange.data('url', url);
                });
            });


        },
        record: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'facrm/analysis/admin/record',
                    add_url: '',
                    edit_url: '',
                    del_url: '',
                    multi_url: '',
                    table: '',
                }
            });

            var table = $("#table");

            //在普通搜索渲染后
            table.on('post-common-search.bs.table', function (event, table) {
        
            });

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                columns: [
                    [
                        {field: 'id', title: 'ID',
							addclass: 'selectpage',
							extend: 'data-source="facrm/common/selectpage/model/admin?type=all" data-field="nickname" data-orderBy="id desc"'},
                        {field: 'nickname', title: __('姓名'), operate: "LIKE"},
                        {field: 'record_count', title: __('跟进次数'), operate: false},
                        {field: 'customer_count', title: __('跟进客户数'), operate: false},

                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);

            var recordtable = $("#recordtable");

            //在普通搜索渲染后
            recordtable.on('post-common-search.bs.table', function (event, table) {
               
            });

            // 初始化表格
            recordtable.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url + "?resquest=record",
                pk: 'id',
                sortName: 'id',
                toolbar: '#toolbar1',
                columns: [
                    [
                        {field: 'id', title: 'ID',
							addclass: 'selectpage',
							extend: 'data-source="facrm/common/selectpage/model/admin?type=all" data-field="nickname" data-orderBy="id desc"'},
                        {field: 'nickname', title: __('姓名'), operate: "LIKE"},
                        {field: 'record_count', title: __('跟进次数'), operate: false},
                        {field: 'customer_count', title: __('跟进客户数'), operate: false},

                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(recordtable);


            require.config({
                    paths: {
                        'Gzyechart': '../addons/facrm/js/gzyechart',
                    }
                }
            );
            require(['Gzyechart'], function () {
                Form.api.bindevent($("form[role=form]"));
                // 基于准备好的dom，初始化健康表格数据
                Gzyechart.echart.loadEchart("order", Echartdata.order.date, Echartdata.order.data);
                Gzyechart.echart.initButton();
                $(document).on("change", "#c-owner_user_id", function () {
                    var owner_user_id = $(this).val();
                    var datetimerange = $(this).parent().parent().find(".datetimerange");
                    var url = datetimerange.data('url');
                    if (url.indexOf("owner_user_id") != -1) {
                        url = Controller.api.replaceParamVal(url, "owner_user_id", owner_user_id);
                    } else {
                        url = url + "&owner_user_id=" + owner_user_id;
                    }
                    datetimerange.data('url', url);
                });
            });

            //跟进方式

            Controller.api.loadEchart("record_type", Echartdata.record.data);
            $(".datetimerange_type").data("callback", function (start, end) {
                var date = start.format(this.locale.format) + " - " + end.format(this.locale.format);
                $(this.element).val(date);
                $.ajax({
                    url: $(this.element).data('url'),
                    method: 'get',
                    data: {
                        start_date: start.format(this.locale.format),
                        end_date: end.format(this.locale.format),
                    },
                    success: function (data) {
                        if (data.code > 0) {
                            Controller.api.loadEchart("record_type", data.data['record']);
                            return;
                        }
                        layer.msg(data.msg, {'icon': 2});
                    },
                });

            });

            $(document).on("click", ".btn-record_type", function () {
                var label = $(this).text();
                var obj = $(this).parent().find(".datetimerange").data("daterangepicker");
                var dates = obj.ranges[label];
                obj.startDate = dates[0];
                obj.endDate = dates[1];
                obj.clickApply();
            });


        },
        achievement: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'facrm/analysis/admin/achievement',
                    add_url: '',
                    edit_url: '',
                    del_url: '',
                    multi_url: '',
                    table: '',
                }
            });

            var table = $("#table");

            //在普通搜索渲染后
            table.on('post-common-search.bs.table', function (event, table) {
              
            });

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                columns: [
                    [
                        {field: 'id', title: 'ID',
							addclass: 'selectpage',
							extend: 'data-source="facrm/common/selectpage/model/admin?type=all" data-field="nickname" data-orderBy="id desc"'},
                        {field: 'nickname', title: __('姓名'), operate: "LIKE"},
                        {field: 'contract_count', title: __('合同数量'), operate: false},
                        {field: 'contract_money', title: __('合同金额'), operate: false},
                        {field: 'receivables_money', title: __('回款金额'), operate: false},
                        {field: 'customer_data.collect_count', title: __('分客数'), operate: false},
                        {field: 'customer_data.purchase_count', title: __('分客成交数'), operate: false},
                        {field: 'customer_data.percentage', title: __('分客成交率'), operate: false},
                        {field: 'clues_data.create_count', title: __('线索数'), operate: false},
                        {field: 'clues_data.transform', title: __('转客数'), operate: false},
                        {field: 'clues_data.percentage', title: __('转客率'), operate: false},
                        {
                            field: 'search_time',
                            title: __('时间段'),
                            formatter: Table.api.formatter.datetime,
                            operate: 'RANGE',
                            addclass: 'datetimerange',
                            visible:false,
							extend: 'autocomplete="off"'
                        },

                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
            require.config({
                    paths: {
                        'Gzyechart': '../addons/facrm/js/gzyechart',
                    }
                }
            );
            require(['Gzyechart'], function () {
                Form.api.bindevent($("form[role=form]"));
                // 基于准备好的dom，初始化健康表格数据
                Gzyechart.echart.loadEchart("achievement", Echartdata.achievement.date, Echartdata.achievement.data);
                Gzyechart.echart.initButton();
                $(document).on("change", "#c-owner_user_id", function () {
                    var owner_user_id = $(this).val();
                    var datetimerange = $(this).parent().parent().find(".datetimerange");
                    var url = datetimerange.data('url');
                    if (url.indexOf("owner_user_id") != -1) {
                        url = Controller.api.replaceParamVal(url, "owner_user_id", owner_user_id);
                    } else {
                        url = url + "&owner_user_id=" + owner_user_id;
                    }
                    datetimerange.data('url', url);
                });

                $(document).on("change", "#c-group_id", function () {

                    var group_id = $(this).val();
                    var datetimerange = $(this).parent().parent().parent().find(".datetimerange");
                    var url = datetimerange.data('url');
                    if (url.indexOf("group_id") != -1) {
                        url = Controller.api.replaceParamVal(url, "group_id", group_id);
                    } else {
                        url = url + "&group_id=" + group_id;
                    }
                    datetimerange.data('url', url);
                });

            });


        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            },
            //替换指定传入参数的值,paramName为参数,replaceWith为新值
            replaceParamVal: function (oUrl, paramName, replaceWith) {
                var re = eval('/(' + paramName + '=)([^&]*)/gi');
                return oUrl.replace(re, paramName + '=' + replaceWith);
            },
            loadEchart: function (echartname, data) {

                option = {
                    title: {
                        text: '',
                        subtext: '',
                        left: 'center'
                    },
                    tooltip: {
                        trigger: 'item',
                        formatter: '{c}%'
                    },
                    legend: {
                        orient: 'vertical',
                        left: 'left',
                    },
                    series: [
                        {
                            name: '跟进方式',
                            type: 'pie',
                            radius: '70%',
                            data: data,
                            label: {
                                formatter: '{b}: {@name} ({d}%)'
                            },
                            emphasis: {
                                itemStyle: {
                                    shadowBlur: 10,
                                    shadowOffsetX: 0,
                                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                                }
                            }
                        }
                    ]
                };
                var record_type = Echarts.init(document.getElementById(echartname));
                record_type.setOption(option);
            },

        }
    };
    return Controller;
});


