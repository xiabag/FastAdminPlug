define(['jquery', 'bootstrap', 'backend', 'addtabs', 'table', 'echarts', 'echarts-theme', 'template'], function ($, undefined, Backend, Datatable, Table, Echarts, undefined, Template) {

    var Controller = {
        index: function () {

			require.config({
				paths: {
					'china': '../addons/facrm/js/china',
				}}
				);
			require(['china'], function () {
				var myChartMap = Echarts.init(document.getElementById('echart_map'), 'map');
				var allMap = Echarts.init(document.getElementById('echart_all'), 'map');
				option = {
					title : {
						text: '成交客户',
						subtext: '缓存一天左右',
						x:'center'
					},
					tooltip : {
						trigger: 'item'
					},
					legend: {
						orient: 'vertical',
						x:'left',
						data:['客户']
					},
					dataRange: {
						min: 0,
						x: 'left',
						y: 'bottom',
						text:['高','低'],           // 文本，默认为数值文本
						calculable : true
					},
					toolbox: {
						show: true,
						orient : 'vertical',
						x: 'right',
						y: 'center',
						feature : {
							mark : {show: true},
							dataView : {show: true, readOnly: false},
							restore : {show: true},
							saveAsImage : {show: true}
						}
					},
					roamController: {
						show: true,
						x: 'right',
						mapTypeControl: {
							'china': true
						}
					},
					series : [
						{
							name: '客户',
							type: 'map',
							mapType: 'china',
							roam: false,
							itemStyle:{
								normal:{label:{show:true}},
								emphasis:{label:{show:true}}
							},

						}
					]
				};
				option.series[0].data=mapdata.dealmap;
				myChartMap.setOption(option);
				option.series[0].data=mapdata.allmap;
				option.title.text='全部客户';
				allMap.setOption(option);
				$(window).resize(function () {
					myChartMap.resize();
				});

			});

        },
		industry:function () {
			var dataname=data.industry;
			option = {
				title: {
					text: '行业分析',
					subtext: '缓存一天左右'
				},
				tooltip: {
					trigger: 'axis',
					axisPointer: {
						type: 'shadow'
					}
				},
				legend: {
					data: ['全部客户', '成交客户']
				},
				grid: {
					left: '3%',
					right: '4%',
					bottom: '3%',
					containLabel: true
				},
				xAxis: {
					type: 'value',
					boundaryGap: [0, 0.01]
				},
				yAxis: {
					type: 'category',
					data:dataname
				},
				series: [
					{
						name: '全部客户',
						type: 'bar',
						data: data.alldata
					},
					{
						name: '成交客户',
						type: 'bar',
						data:  data.dealdata
					}
				]
			};
			var myChart1 = Echarts.init(document.getElementById('echart'));
			myChart1.setOption(option);
		},
		level:function () {
			var dataname=data.level;
			option = {
				title: {
					text: '等级分析',
					subtext: '缓存一天左右'
				},
				tooltip: {
					trigger: 'axis',
					axisPointer: {
						type: 'shadow'
					}
				},
				legend: {
					data: ['全部客户', '成交客户']
				},
				grid: {
					left: '3%',
					right: '4%',
					bottom: '3%',
					containLabel: true
				},
				xAxis: {
					type: 'value',
					boundaryGap: [0, 0.01]
				},
				yAxis: {
					type: 'category',
					data:dataname
				},
				series: [
					{
						name: '全部客户',
						type: 'bar',
						data: data.alldata
					},
					{
						name: '成交客户',
						type: 'bar',
						data:  data.dealdata
					}
				]
			};
			var myChart1 = Echarts.init(document.getElementById('echart'));
			myChart1.setOption(option);
		},
		source:function () {
			var dataname=data.source;
			option = {
				title: {
					text: '来源分析',
					subtext: '缓存一天左右'
				},
				tooltip: {
					trigger: 'axis',
					axisPointer: {
						type: 'shadow'
					}
				},
				legend: {
					data: ['全部客户', '成交客户']
				},
				grid: {
					left: '3%',
					right: '4%',
					bottom: '3%',
					containLabel: true
				},
				xAxis: {
					type: 'value',
					boundaryGap: [0, 0.01]
				},
				yAxis: {
					type: 'category',
					data:dataname
				},
				series: [
					{
						name: '全部客户',
						type: 'bar',
						data: data.alldata
					},
					{
						name: '成交客户',
						type: 'bar',
						data:  data.dealdata
					}
				]
			};
			var myChart1 = Echarts.init(document.getElementById('echart'));
			myChart1.setOption(option);
		}
    };

    return Controller;
});

