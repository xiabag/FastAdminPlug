var index=1;
define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        contract: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'facrm/analysis/ranking/contract',
                    add_url: '',
                    edit_url: '',
                    del_url: '',
                    multi_url: '',
                    table: '',
                }
            });

            var table = $("#table");
            //在普通搜索渲染后
            table.on('post-common-search.bs.table', function (event, table) {
                var form = $("form", table.$commonsearch);
                $(".commonsearch-table select[name=type_id]").val(1);
            });
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'order_admin_id',
                sortName: 'order_admin_id',
                commonSearch: true,
                search: false,
                searchFormVisible: true,
                columns: [
                    [
                        {field: 'order_admin_id', title: 'ID', operate: false},
                        {field: 'index', title: __('排名'), operate: false},
                        {field: 'orderAdmin.nickname', title: __('姓名'), operate: false},
                        {field: 'count', title: __('合同数量'), operate: false},
                        {field: 'money', title: __('合同金额'), operate: false},
                        {
                            field: 'type_id',
                            title: __('排名方式'),
                            visible:false,
                            searchList:{1:"合同数量",2:"合同总额",}
                        },
                        {
                            field: 'group_id',
                            title: __('成员组'),
                            visible:false,
                            searchList:Config.groupdata
                        },
                        {
                            field: 'search_time',
                            title: __('时间段'),
                            formatter: Table.api.formatter.datetime,
                            operate: 'RANGE',
                            addclass: 'datetimerange',
                            visible:false,
							extend: 'autocomplete="off"'
                        },

                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        receivables: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'facrm/analysis/ranking/receivables',
                    add_url: '',
                    edit_url: '',
                    del_url: '',
                    multi_url: '',
                    table: '',
                }
            });

            var table = $("#table");
            //在普通搜索渲染后
            table.on('post-common-search.bs.table', function (event, table) {
                var form = $("form", table.$commonsearch);
                $(".commonsearch-table select[name=type_id]").val(2);
            });
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'order_admin_id',
                sortName: 'order_admin_id',
                commonSearch: true,
                search: false,
                searchFormVisible: true,
                columns: [
                    [
                        {field: 'order_admin_id', title: 'ID', operate: false},
                        {field: 'index', title: __('排名'), operate: false},
                        {field: 'orderAdmin.nickname', title: __('姓名'), operate: false},
                        {field: 'count', title: __('回款数量'), operate: false},
                        {field: 'money', title: __('回款总额'), operate: false},
                        {
                            field: 'type_id',
                            title: __('排名方式'),
                            visible:false,
                            searchList:{1:"回款数量",2:"回款总额",}
                        },
                        {
                            field: 'group_id',
                            title: __('成员组'),
                            visible:false,
                            searchList:Config.groupdata
                        },
                        {
                            field: 'search_time',
                            title: __('时间段'),
                            formatter: Table.api.formatter.datetime,
                            operate: 'RANGE',
                            addclass: 'datetimerange',
                            visible:false,
							extend: 'autocomplete="off"'
                        },

                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        addcustomer: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'facrm/analysis/ranking/addcustomer',
                    add_url: '',
                    edit_url: '',
                    del_url: '',
                    multi_url: '',
                    table: '',
                }
            });

            var table = $("#table");
            //在普通搜索渲染后
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'create_user_id',
                sortName: 'create_user_id',
                commonSearch: true,
                search: false,
                searchFormVisible: true,
                columns: [
                    [
                        {field: 'create_user_id', title: 'ID', operate: false},
                        {field: 'index', title: __('排名'), operate: false},
                        {field: 'createUser.nickname', title: __('姓名'), operate: false},
                        {field: 'count', title: __('添加客户数量'), operate: false},
                        {
                            field: 'group_id',
                            title: __('成员组'),
                            visible:false,
                            searchList:Config.groupdata
                        },
                        {
                            field: 'search_time',
                            title: __('时间段'),
                            formatter: Table.api.formatter.datetime,
                            operate: 'RANGE',
                            addclass: 'datetimerange',
                            visible:false,
							extend: 'autocomplete="off"'
                        },

                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        record: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'facrm/analysis/ranking/record',
                    add_url: '',
                    edit_url: '',
                    del_url: '',
                    multi_url: '',
                    table: '',
                }
            });

            var table = $("#table");
            //在普通搜索渲染后
            table.on('post-common-search.bs.table', function (event, table) {
                var form = $("form", table.$commonsearch);
                $(".commonsearch-table select[name=type_id]").val(1);
            });
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'create_user_id',
                sortName: 'create_user_id',
                commonSearch: true,
                search: false,
                searchFormVisible: true,
                columns: [
                    [
                        {field: 'create_user_id', title: 'ID', operate: false},
                        {field: 'index', title: __('排名'), operate: false},
                        {field: 'createUser.nickname', title: __('姓名'), operate: false},
                        {field: 'count', title: __('跟进次数'), operate: false},
                        {field: 'total', title: __('跟进客户数'), operate: false},
                        {
                            field: 'type_id',
                            title: __('排名方式'),
                            visible:false,
                            searchList:{1:"跟进次数",2:"跟进客户数",}
                        },
                        {
                            field: 'group_id',
                            title: __('成员组'),
                            visible:false,
                            searchList:Config.groupdata
                        },
                        {
                            field: 'search_time',
                            title: __('时间段'),
                            formatter: Table.api.formatter.datetime,
                            operate: 'RANGE',
                            addclass: 'datetimerange',
                            visible:false,
							extend: 'autocomplete="off"'
                        },

                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        product: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'facrm/analysis/ranking/product',
                    add_url: '',
                    edit_url: '',
                    del_url: '',
                    multi_url: '',
                    table: '',
                }
            });

            var table = $("#table");
            //在普通搜索渲染后
            table.on('post-common-search.bs.table', function (event, table) {
                var form = $("form", table.$commonsearch);
                $(".commonsearch-table select[name=type_id]").val(2);
  
            });
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'product_id',
                sortName: 'product_id',
                commonSearch: true,
                search: false,
                searchFormVisible: true,
                columns: [
                    [
                        {field: 'product_id', title: '产品ID', operate: false},
                        {field: 'index', title: __('排名'), operate: false},
                        {field: 'name', title: __('产品名称'), operate: false},
                        {field: 'count', title: __('销售数量'), operate: false},
                        {field: 'total', title: __('销售总额'), operate: false},
                        {
                            field: 'type_id',
                            title: __('排名方式'),
                            visible:false,
                            searchList:{1:"销售数量",2:"销售总额",}
                        },
                        {
                            field: 'group_id',
                            title: __('成员组'),
                            visible:false,
                            searchList:Config.groupdata
                        },
                        {
                            field: 'search_time',
                            title: __('时间段'),
                            formatter: Table.api.formatter.datetime,
                            operate: 'RANGE',
                            addclass: 'datetimerange',
                            visible:false,
							extend: 'autocomplete="off"'
                        },

                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },

        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            },
        }
    };
    return Controller;
});


