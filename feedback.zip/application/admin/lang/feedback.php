<?php

return [
    'Id'         => 'ID',
    'Type'       => '反馈分类',
    'User_id'    => '用户ID',
    'Content'    => '反馈内容',
    'Tel'        => '联系方式',
    'Createtime' => '反馈时间',
    'Nickname'   => '用户昵称'
];
