<?php

return [
    [
        'name' => '__tips__',
        'title' => '使用说明',
        'type' => 'string',
        'content' => [],
        'value' => '此处可配置不同模块的意见反馈,也可理解为,为反馈增加不同的分类',
        'rule' => 'required',
        'msg' => '',
        'tip' => '',
        'ok' => '',
        'extend' => '',
    ],
    [
        'name' => 'type',
        'title' => '使用说明',
        'type' => 'array',
        'content' => [
            'default' => '默认',
        ],
        'value' => [
            'default' => '默认',
        ],
        'rule' => 'required',
        'msg' => '',
        'tip' => '',
        'ok' => '',
        'extend' => '',
    ],
];
