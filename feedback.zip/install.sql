CREATE TABLE `__PREFIX__feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `type` varchar(32) NOT NULL COMMENT '反馈分类',
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `content` varchar(255) NOT NULL COMMENT '反馈内容',
  `tel` varchar(18) NOT NULL COMMENT '联系方式',
  `createtime` int(11) NOT NULL COMMENT '反馈时间',
  `nickname` varchar(32) DEFAULT NULL COMMENT '用户昵称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='意见反馈';