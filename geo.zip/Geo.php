<?php

namespace addons\geo;

use app\common\library\Menu;
use think\Addons;

/**
 * 插件
 */
class Geo extends Addons
{

    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        $menu = [
            [
                'name'    => 'geo',
                'title'   => '地区管理',
                'icon'    => 'fa fa-map-marker',
                'sublist' => [
                    [
                        'name'    => 'geo/province',
                        'title'   => '省份管理',
                        'icon'    => 'fa fa-map-marker',
                        'sublist' => [
                            ['name' => 'geo/province/index', 'title' => '查看'],
                            ['name' => 'geo/province/add', 'title' => '添加'],
                            ['name' => 'geo/province/detail', 'title' => '详情'],
                            ['name' => 'geo/province/edit', 'title' => '修改'],
                            ['name' => 'geo/province/del', 'title' => '删除'],
                            ['name' => 'geo/province/multi', 'title' => '批量更新'],
                        ]
                    ],
                    [
                        'name'    => 'geo/city',
                        'title'   => '城市管理',
                        'icon'    => 'fa fa-map-marker',
                        'sublist' => [
                            ['name' => 'geo/city/index', 'title' => '查看'],
                            ['name' => 'geo/city/add', 'title' => '添加'],
                            ['name' => 'geo/city/detail', 'title' => '详情'],
                            ['name' => 'geo/city/edit', 'title' => '修改'],
                            ['name' => 'geo/city/del', 'title' => '删除'],
                            ['name' => 'geo/city/multi', 'title' => '批量更新'],
                        ]
                    ],
                    [
                        'name'    => 'geo/area',
                        'title'   => '地区管理',
                        'icon'    => 'fa fa-map-marker',
                        'sublist' => [
                            ['name' => 'geo/area/index', 'title' => '查看'],
                            ['name' => 'geo/area/add', 'title' => '添加'],
                            ['name' => 'geo/area/detail', 'title' => '详情'],
                            ['name' => 'geo/area/edit', 'title' => '修改'],
                            ['name' => 'geo/area/del', 'title' => '删除'],
                            ['name' => 'geo/area/multi', 'title' => '批量更新'],
                        ]
                    ],
                    [
                        'name'    => 'geo/street',
                        'title'   => '街道管理',
                        'icon'    => 'fa fa-map-marker',
                        'sublist' => [
                            ['name' => 'geo/street/index', 'title' => '查看'],
                            ['name' => 'geo/street/add', 'title' => '添加'],
                            ['name' => 'geo/street/detail', 'title' => '详情'],
                            ['name' => 'geo/street/edit', 'title' => '修改'],
                            ['name' => 'geo/street/del', 'title' => '删除'],
                            ['name' => 'geo/street/multi', 'title' => '批量更新'],
                        ]
                    ],
                ]
            ]
        ];
        Menu::create($menu);
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        Menu::delete('geo');
        return true;
    }

    /**
     * 插件启用方法
     * @return bool
     */
    public function enable()
    {
        Menu::enable('geo');
        return true;
    }

    /**
     * 插件禁用方法
     * @return bool
     */
    public function disable()
    {
        Menu::disable('geo');
        return true;
    }

}
