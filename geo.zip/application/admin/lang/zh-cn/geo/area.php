<?php

return [
    'Area_id'        => '自增列',
    'Area_code'      => '区代码',
    'City_code'      => '父级市代码',
    'Area_name'      => '市名称',
    'Short_name'     => '简称',
    'Lng'            => '经度',
    'Lat'            => '纬度',
    'Weigh'          => '排序',
    'Memo'           => '备注',
    'Switch'         => '状态',
    'City.city_name' => '市名称'
];
