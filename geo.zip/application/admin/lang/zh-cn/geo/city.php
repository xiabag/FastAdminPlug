<?php

return [
    'City_id'                => '自增列',
    'City_code'              => '市代码',
    'City_name'              => '市名称',
    'Short_name'             => '简称',
    'Province_code'          => '省代码',
    'Lng'                    => '经度',
    'Lat'                    => '纬度',
    'Weigh'                  => '排序',
    'Memo'                   => '备注',
    'Switch'                 => '状态',
    'Province.province_name' => '省份名称'
];
