<?php

return [
    'Province_id'   => '自增列',
    'Province_code' => '省份代码',
    'Province_name' => '省份名称',
    'Short_name'    => '简称',
    'Lng'           => '经度',
    'Lat'           => '纬度',
    'Weigh'         => '排序',
    'Memo'          => '备注',
    'Switch'        => '状态'
];
