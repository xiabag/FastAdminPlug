<?php

return [
    'Street_id'      => '自增列',
    'Street_code'    => '街道代码',
    'Area_code'      => '父级区代码',
    'Street_name'    => '街道名称',
    'Short_name'     => '简称',
    'Lng'            => '经度',
    'Lat'            => '纬度',
    'Weigh'          => '排序',
    'Memo'           => '备注',
    'Switch'         => '状态',
    'Area.area_name' => '市名称'
];
