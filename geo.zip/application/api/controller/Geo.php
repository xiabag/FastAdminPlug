<?php

namespace app\api\controller;

use app\admin\model\geo\Area;
use app\admin\model\geo\City;
use app\admin\model\geo\Province;
use app\admin\model\geo\Street;
use app\common\controller\Api;

/**
 * 首页接口
 */
class Geo extends Api
{
    protected $noNeedLogin = ['*'];
    protected $noNeedRight = ['*'];

    /**
     * 省
     */
    public function province(){
        $res = Province::where(['switch'=>1])
            ->field('province_code code,province_name name')
            ->select();
        $this->success('OK',$res);
    }

    /**
     * 市
     */
    public function city(){
        $pcode = $this->request->param('pcode');
        // $pcode = '130000';
        if(!$pcode) $this->error('请先选择省份');
        $res = City::where(['switch'=>1,'province_code'=>$pcode])
            ->field('city_code code,city_name name')
            ->select();
        $this->success('OK',$res);
    }
    
    /**
     * 区
     */
    public function area(){
        $pcode = $this->request->param('pcode');
        // $pcode = '140100';
        if(!$pcode) $this->error('请先选择城市');
        $res = Area::where(['switch'=>1,'city_code'=>$pcode])
            ->field('area_code code,area_name name')
            ->select();
        $this->success('OK',$res);
    }

    /**
     * 街道
     */
    public function street(){
        $pcode = $this->request->param('pcode');
        // $pcode = '410102';
        if(!$pcode) $this->error('请先选择区/县');
        $res = Street::where(['switch'=>1,'area_code'=>$pcode])
            ->field('street_code code,street_name name')
            ->select();
        $this->success('OK',$res);
    }
}
