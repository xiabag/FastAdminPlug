define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'geo/area/index' + location.search,
                    add_url: 'geo/area/add',
                    edit_url: 'geo/area/edit',
                    del_url: 'geo/area/del',
                    multi_url: 'geo/area/multi',
                    import_url: 'geo/area/import',
                    table: 'area',
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'area_id',
                sortName: 'weigh',
                columns: [
                    [
                        {checkbox: true},
                        {field: 'area_id', title: __('Area_id')},
                        {field: 'area_code', title: __('Area_code'), operate: 'LIKE'},
                        {field: 'city_code', title: __('City_code'), operate: 'LIKE'},
                        {field: 'area_name', title: __('Area_name'), operate: 'LIKE'},
                        {field: 'short_name', title: __('Short_name'), operate: 'LIKE'},
                        {field: 'lng', title: __('Lng'), operate: 'LIKE'},
                        {field: 'lat', title: __('Lat'), operate: 'LIKE'},
                        {field: 'weigh', title: __('Weigh'), operate: false},
                        {field: 'memo', title: __('Memo'), operate: 'LIKE'},
                        {field: 'switch', title: __('Switch'), table: table, formatter: Table.api.formatter.toggle},
                        {field: 'city.city_name', title: __('City.city_name'), operate: 'LIKE'},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});