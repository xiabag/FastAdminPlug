define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'geo/city/index' + location.search,
                    add_url: 'geo/city/add',
                    edit_url: 'geo/city/edit',
                    del_url: 'geo/city/del',
                    multi_url: 'geo/city/multi',
                    import_url: 'geo/city/import',
                    table: 'city',
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'city_id',
                sortName: 'weigh',
                columns: [
                    [
                        {checkbox: true},
                        {field: 'city_id', title: __('City_id')},
                        {field: 'city_code', title: __('City_code'), operate: 'LIKE'},
                        {field: 'city_name', title: __('City_name'), operate: 'LIKE'},
                        {field: 'short_name', title: __('Short_name'), operate: 'LIKE'},
                        {field: 'province_code', title: __('Province_code'), operate: 'LIKE'},
                        {field: 'lng', title: __('Lng'), operate: 'LIKE'},
                        {field: 'lat', title: __('Lat'), operate: 'LIKE'},
                        {field: 'weigh', title: __('Weigh'), operate: false},
                        {field: 'memo', title: __('Memo'), operate: 'LIKE'},
                        {field: 'switch', title: __('Switch'), table: table, formatter: Table.api.formatter.toggle},
                        {field: 'province.province_name', title: __('Province.province_name'), operate: 'LIKE'},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});