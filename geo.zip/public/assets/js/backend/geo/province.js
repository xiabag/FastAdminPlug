define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'geo/province/index' + location.search,
                    add_url: 'geo/province/add',
                    edit_url: 'geo/province/edit',
                    del_url: 'geo/province/del',
                    multi_url: 'geo/province/multi',
                    import_url: 'geo/province/import',
                    table: 'province',
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'province_id',
                sortName: 'weigh',
                columns: [
                    [
                        {checkbox: true},
                        {field: 'province_id', title: __('Province_id')},
                        {field: 'province_code', title: __('Province_code'), operate: 'LIKE'},
                        {field: 'province_name', title: __('Province_name'), operate: 'LIKE'},
                        {field: 'short_name', title: __('Short_name'), operate: 'LIKE'},
                        {field: 'lng', title: __('Lng'), operate: 'LIKE'},
                        {field: 'lat', title: __('Lat'), operate: 'LIKE'},
                        {field: 'weigh', title: __('Weigh'), operate: false},
                        {field: 'memo', title: __('Memo'), operate: 'LIKE'},
                        {field: 'switch', title: __('Switch'), table: table, formatter: Table.api.formatter.toggle},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});