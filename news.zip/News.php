<?php

namespace addons\news;

use app\common\library\Menu;
use think\Addons;

/**
 * 插件
 */
class News extends Addons
{

    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        $menu = [
            [
                'name'    => 'news',
                'title'   => '新闻资讯',
                'icon'    => 'fa fa-newspaper-o',
                'sublist' => [
                    ['name' => 'news/index', 'title' => '查看'],
                    ['name' => 'news/add', 'title' => '添加'],
                    ['name' => 'news/detail', 'title' => '详情'],
                    ['name' => 'news/del', 'title' => '删除'],
                ]
            ]
        ];
        Menu::create($menu);
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        Menu::delete('news');
        return true;
    }

    /**
     * 插件启用方法
     * @return bool
     */
    public function enable()
    {
        Menu::enable('news');
        return true;
    }

    /**
     * 插件禁用方法
     * @return bool
     */
    public function disable()
    {
        Menu::disable('news');
        return true;
    }

}
