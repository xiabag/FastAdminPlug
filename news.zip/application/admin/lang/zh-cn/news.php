<?php

return [
    'Id'                 => 'ID',
    'Title'              => '标题',
    'Sub_title'          => '副标题',
    'Createtime'         => '创建时间',
    'Updatetime'         => '更新时间',
    'Category_id'        => '分类',
    'Image'              => '缩略图',
    'Content'            => '正文',
    'Support'            => '点赞数量',
    'Favorite'           => '收藏数量',
    'Read'               => '阅读数量',
    'Status'             => '状态',
    'Status 0'           => '隐藏',
    'Status 1'           => '显示',
    'Weigh'              => '权重',
    'Recommend_switch'   => '是否推荐',
    'Recommend_switch 0' => '否',
    'Recommend_switch 1' => '是'
];
