<?php

namespace app\api\controller;

use app\admin\model\News as ModelNews;
use app\common\controller\Api;

/**
 * 新闻资讯接口
 */
class News extends Api
{
    protected $noNeedLogin = ['category','list','detail'];
    protected $noNeedRight = ['*'];

    /**
     * 文章分类
     */
    public function category(){
        $res = db('Category')->where(['type'=>'news','status'=>'normal'])
            ->order('weigh desc')
            ->field('id,name,nickname,image')
            ->select();
        $this->success('ok',$res);
    }

    /**
     * 列表
     */
    public function list(){
        $limit = $this->request->param('limit',10);
        $cid = $this->request->param('cid');
        if(!$cid) $this->error('请选择文章分类');
        $is_support_sql = '0';
        $is_favorite_sql = '0';
        if(!is_null($this->auth->id)){
            $is_support_sql = db('NewsSupport')->where(['user_id'=>$this->auth->id])->where('news_id=a.id')->field('count(id)')->buildSql();
            $is_favorite_sql = db('NewsFavorite')->where(['user_id'=>$this->auth->id])->where('news_id=a.id')->field('count(id)')->buildSql();
        }
        $res = ModelNews::alias('a')
            ->where(['category_id'=>$cid,'status'=>'1'])
            ->order('recommend_switch desc,weigh desc')
            ->field("id,title,sub_title,image,createtime,support,favorite,`read`,{$is_support_sql} is_support,{$is_favorite_sql} is_favorite")
            ->paginate($limit);
        $this->success('ok',$res);
    }

    /**
     * 详情
     */
    public function detail(){
        $id = $this->request->param('id');
        if(!$id) $this->error('请选择文章');
        $this->read($id);# 阅读量+1
        $is_support_sql = '0';
        $is_favorite_sql = '0';
        if(!is_null($this->auth->id)){
            $is_support_sql = db('NewsSupport')->where(['user_id'=>$this->auth->id])->where('news_id=a.id')->field('count(id)')->buildSql();
            $is_favorite_sql = db('NewsFavorite')->where(['user_id'=>$this->auth->id])->where('news_id=a.id')->field('count(id)')->buildSql();
        }
        $res = ModelNews::alias('a')
            ->where(['id'=>$id])
            ->field("id,title,sub_title,createtime,image,content,support,favorite,`read`,{$is_support_sql} is_support,{$is_favorite_sql} is_favorite")
            ->find();
        $this->success('ok',$res);
    }

    /**
     * 阅读量+1
     * 同一IP一天内仅增加1个阅读量
     */
    private function read($id){
        if(is_null($this->auth->id)){
            $cache_name = 'news_'.$id.'_'.$_SERVER['REMOTE_ADDR'];
            if(!cache($cache_name)){
                cache($cache_name,1,['expire'=>86400]);
                $this->readInc($id);
            }
        }else{
            $user_id = $this->auth->id;
            $Read = db('NewsRead');
            $res = $Read->where(['user_id'=>$user_id,'news_id'=>$id])->find();
            if(!$res){
                $Read->insert(['user_id'=>$user_id,'news_id'=>$id,'createtime'=>time()]);
                $this->readInc($id);
            }
        }
    }

    /**
     * 点赞数量-1
     */
    private function supportDec($id){
        ModelNews::where(['id'=>$id,'support'=>['>=',1]])->setDec('support',1);
    }

    /**
     * 点赞数量+1
     */
    private function supportInc($id){
        ModelNews::where(['id'=>$id])->setInc('support',1);
    }

    /**
     * 阅读数量+1
     */
    private function readInc($id){
        ModelNews::where(['id'=>$id])->setInc('read',1);
    }

    /**
     * 收藏数量-1
     */
    private function favoriteDec($id){
        ModelNews::where(['id'=>$id,'favorite'=>['>=',1]])->setDec('favorite',1);
    }

    /**
     * 收藏数量+1
     */
    private function favoriteInc($id){
        ModelNews::where(['id'=>$id])->setInc('favorite',1);
    }

    /**
     * 点赞
     */
    public function support(){
        $user_id = $this->auth->id;
        $id = $this->request->param('id');
        $status = null;
        $Support = db('NewsSupport');
        $res = $Support->where(['user_id'=>$user_id,'news_id'=>$id])->find();
        if($res){
            $Support->where(['id'=>$res['id']])->delete();
            $this->supportDec($id);
            $status = 0;
        }else{
            $Support->insert(['user_id'=>$user_id,'news_id'=>$id,'createtime'=>time()]);
            $this->supportInc($id);
            $status = 1;
        }
        $this->success('ok',['is_support'=>$status]);
    }

    /**
     * 收藏
     */
    public function favorite(){
        $user_id = $this->auth->id;
        $id = $this->request->param('id');
        $status = null;
        $Favorite = db('NewsFavorite');
        $res = $Favorite->where(['user_id'=>$user_id,'news_id'=>$id])->find();
        if($res){
            $Favorite->where(['id'=>$res['id']])->delete();
            $this->favoriteDec($id);
            $status = 0;
        }else{
            $Favorite->insert(['user_id'=>$user_id,'news_id'=>$id,'createtime'=>time()]);
            $this->favoriteInc($id);
            $status = 1;
        }
        $this->success('ok',['is_favorite'=>$status]);
    }

    /**
     * 收藏记录
     */
    public function favoriteList(){
        $user_id = $this->auth->id;
        $limit = $this->request->param('limit',10);
        $news_ids = db('NewsFavorite')->where(['user_id'=>$user_id])->column('news_id');
        $res = ModelNews::whereIn('id',$news_ids)
            ->order('recommend_switch desc,weigh desc')
            ->field('id,title,sub_title,image,createtime,support,favorite,read')
            ->paginate($limit);
        $this->success('ok',$res);
    }


}
