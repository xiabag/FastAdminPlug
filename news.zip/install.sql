CREATE TABLE IF NOT EXISTS `__PREFIX__news` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(20) NOT NULL COMMENT '标题',
  `sub_title` varchar(50) NOT NULL COMMENT '副标题',
  `createtime` int(11) NOT NULL COMMENT '创建时间',
  `updatetime` int(11) NOT NULL COMMENT '更新时间',
  `category_id` int(11) NOT NULL COMMENT '分类',
  `image` varchar(255) DEFAULT NULL COMMENT '缩略图',
  `content` text COMMENT '正文',
  `support` int(11) NOT NULL DEFAULT '0' COMMENT '点赞数量',
  `favorite` int(11) NOT NULL DEFAULT '0' COMMENT '收藏数量',
  `read` int(11) NOT NULL DEFAULT '0' COMMENT '阅读数量',
  `status` enum('0','1') DEFAULT '1' COMMENT '状态:0=隐藏,1=显示',
  `weigh` int(11) COMMENT '权重',
  `recommend_switch` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否推荐:0=否,1=是',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='新闻资讯';

CREATE TABLE `__PREFIX__news_favorite` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `news_id` int(11) NOT NULL COMMENT '文章ID',
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `createtime` int(11) NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='收藏记录';

CREATE TABLE `__PREFIX__news_support` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `news_id` int(11) NOT NULL COMMENT '文章ID',
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `createtime` int(11) NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='点赞记录';

CREATE TABLE `__PREFIX__news_read` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `news_id` int(11) NOT NULL COMMENT '文章ID',
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `createtime` int(11) NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='阅读记录';

-- 自带分类表中增加字段: {"news":"新闻资讯"}
UPDATE __PREFIX__config set `value`=CONCAT(`value`, '{"news":"新闻资讯"}') WHERE `name`='categorytype' AND `group`='dictionary' AND (`value`='' OR `value`='{}')
UPDATE __PREFIX__config set `value`=CONCAT(`value`, ',{"news":"新闻资讯"}') WHERE `name`='categorytype' AND `group`='dictionary'