<?php

return [
    'Name'  =>  '图片上文字',
    'Title'  =>  '标题',
    'Image'  =>  '图片',
    'Content'  =>  '内容',
    'Createtime'  =>  '添加时间',
    'Updatetime'  =>  '更新时间',
    'Status'  =>  '状态'
];
