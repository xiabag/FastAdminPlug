require.config({
    paths: {
        'litestorefreight_delivery': '../addons/litestore/js/litestorefreight_delivery',
        'litestorefreight_regionalChoice': '../addons/litestore/js/litestorefreight_regionalChoice',
        'litestoregoods': '../addons/litestore/js/litestoregoods',
    },
});