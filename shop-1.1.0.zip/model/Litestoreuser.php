<?php

namespace addons\litestore\model;

use think\Model;
use app\common\model\User;

class Litestoreuser extends User
{

}