<template>
<footer>─── Copyright 2016-2028 ® By.Hawk86104 ───</footer>
</template>
<style>
footer {
	color: #6d189e;
	text-align: center;
	height: 20px;
	line-height: 20px;
	margin-bottom: 80px;
	font-size: 11px;
}
</style>