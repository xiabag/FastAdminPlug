<?php

return [
    'Title'       => '活动名称',
    'Goods_ids'   => '商品组',
    'Type'        => '类型',
    'Description' => '活动说明',
    'Starttime'   => '开始时间',
    'Endtime'     => '结束时间',
    'Rules'       => '活动规则',
    'Createtime'  => '创建时间',
    'Updatetime'  => '更新时间',
    'Deletetime'  => '删除时间'
];
