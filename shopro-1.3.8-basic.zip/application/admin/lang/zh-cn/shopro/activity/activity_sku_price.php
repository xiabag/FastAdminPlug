<?php

return [
    'Activity_id'  => '活动 id',
    'Sku_price_id' => '规格 id',
    'Goods_id'     => '所属产品',
    'Stock'        => '库存',
    'Sales'        => '已售',
    'Price'        => '价格',
    'Createtime'        => '添加时间',
    'Updatetime'        => '更新时间'
];
