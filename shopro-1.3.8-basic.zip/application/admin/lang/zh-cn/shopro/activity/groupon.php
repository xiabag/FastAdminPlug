<?php

return [
    'User_id'                  => '团长',
    'Goods_id'                 => '商品',
    'Activity_id'              => '活动',
    'Num'                      => '成团人数',
    'Current_num'              => '当前人数',
    'Status'                   => '状态',
    'Status invalid'           => '已过期',
    'Status ing'               => '进行中',
    'Status finish'            => '已成团',
    'Status finish-fictitious' => '虚拟成团',
    'Createtime'               => '添加时间',
    'Updatetime'               => '更新时间'
];
