<?php

return [
    'Name'            => '房间名',
    'Room_id'         => '房间 ID',
    'Cover_img'       => '房间背景',
    'Live_status'     => '直播状态',
    'Live_status 101' => '直播中',
    'Live_status 102' => '未开始',
    'Live_status 103' => '已结束',
    'Live_status 104' => '禁播',
    'Live_status 105' => '暂停中',
    'Live_status 106' => '异常',
    'Live_status 107' => '已过期',
    'Starttime'       => '开始时间',
    'Endtime'         => '结束时间',
    'Anchor_name'     => '主播',
    'Anchor_img'      => '主播头像',
    'Share_img'       => '分享封面',
    'Createtime'      => '创建时间',
    'Updatetime'      => '更新时间',
    'Deletetime'      => '删除时间'
];
