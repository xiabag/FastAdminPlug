<?php

return [
    'Image'    => '缩略图',
    'Status'   => '上架状态',
    'Status up' => '上架',
    'Status hidden' => '隐藏',
    'Status down' => '下架',
];
