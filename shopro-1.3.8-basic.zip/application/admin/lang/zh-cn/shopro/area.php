<?php

return [
    'Name' => '名称',
    'Pid'  => '上级',
    'Level' => '层级'
];
