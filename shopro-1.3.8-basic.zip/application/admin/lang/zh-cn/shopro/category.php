<?php

return [
    'Name'       => '分类名称',
    'Pid'        => '上级分类',
    'Weigh'      => '排序',
    'Image'      => '分类图片',
    'Shop' => '商城分类',
    'Custom' => '自定义商品组',
    'Description' => '描述',
    'Status'     => '状态',
    'Createtime' => '创建时间'
];
