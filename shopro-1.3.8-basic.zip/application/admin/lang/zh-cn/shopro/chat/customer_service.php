<?php

return [
    'Id'             => 'ID',
    'Admin_id'       => '绑定管理员',
    'Name'           => '客服昵称',
    'Avatar'         => '客服头像',
    'Max_num'        => '接待上限',
    'Lasttime'       => '上次服务时间',
    'Status'         => '状态',
    'Status offline' => '离线',
    'Status online'  => '在线',
    'Status busy'  => '忙碌',
    'Createtime'     => '创建时间',
    'Updatetime'     => '更新时间'
];
