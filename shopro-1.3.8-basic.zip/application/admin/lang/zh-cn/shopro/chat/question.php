<?php

return [
    'Id'            => 'ID',
    'Title'         => '标题',
    'Content'       => '内容',
    'Status'        => '状态',
    'Status normal' => '启用',
    'Status hidden' => '隐藏',
    'Weigh'         => '权重',
    'Createtime'    => '创建时间',
    'Updatetime'    => '更新时间'
];
