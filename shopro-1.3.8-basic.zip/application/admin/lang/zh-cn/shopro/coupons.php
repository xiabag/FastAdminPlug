<?php

return [
    'Name'         => '名称',
    'Goods_ids'    => '适用商品',
    'Type'         => '优惠券类型',
    'Type cash'    => '代金券',
    'Type discount'=> '折扣券',
    'Amount'       => '券面额',
    'Enough'       => '消费门槛',
    'Stock'        => '库存',
    'Limit'        => '每人限制',
    'Gettime'      => '领取周期',
    'Usetime'      => '有效期',
    'Description'  => '描述',
    'Createtime'   => '创建时间',
    'Updatetime'   => '更新时间',
    'Deletetime'   => '删除时间'
];
