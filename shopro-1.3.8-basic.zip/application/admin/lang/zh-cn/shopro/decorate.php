<?php

return [
    'Name' => '模板名称',
    'Memo' => '备注',
    'Status' => '状态',
    'Platform' => '适用平台',
    'Platform h5' => 'H5',
    'Platform wxofficialaccount' => '微信公众号网页',
    'Platform wxminiprogram' => '微信小程序',
    'Platform app' => 'App',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Deletetime' => '删除时间',
    'H5' => 'H5网页',
    'wxOfficialAccount' => '微信公众号',
    'wxMiniProgram' => '微信小程序',
    'App' => 'App'
];
