<?php

return [
    'Name'             => '模板名称',
    'Type'             => '计费方式',
    'Type number'      => '件数',
    'Type weight'      => '重量',
    'Weigh'            => '权重',
    'First_price'      => '首(重/件)价格',
    'Additional_num'   => '续(重/件)数',
    'Additional_price' => '续(重/件)价格',
    'Province_ids'     => '省份',
    'City_ids'         => '市级',
    'Area_ids'         => '区域',
    'Createtime'       => '创建时间',
    'Updatetime'       => '更新时间',
    'Deletetime'       => '删除时间'
];
