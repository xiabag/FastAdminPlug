<?php

return [
    'Name' => '快递公司',
    'Code' => '编码'
];
