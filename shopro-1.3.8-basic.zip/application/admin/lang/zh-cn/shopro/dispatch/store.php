<?php

return [
    'Name'          => '名称',
    'Type'          => '发货方式',
    'Type express'  => '物流快递',
    'Type selfetch' => '用户自提',
    'Type store'    => '商户配送',
    'Type autosend' => '自动发货',
    'Type_ids'      => '包含模板',
    'Createtime'    => '创建时间',
    'Updatetime'    => '更新时间',
    'Deletetime'    => '删除时间'
];
