<?php

return [
    'Title'      => '标题',
    'Content'    => '内容',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Deletetime' => '删除时间'
];
