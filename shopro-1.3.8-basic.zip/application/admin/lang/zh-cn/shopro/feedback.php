<?php

return [
    'User_id'    => '反馈用户',
    'Type'       => '反馈类型',
    'Content'    => '反馈内容',
    'Images'     => '图片',
    'Phone'      => '联系电话',
    'Status'     => '是否处理',
    'Status 0'   => '未处理',
    'Status 1'   => '已处理',
    'Remark'     => '处理备注',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Deletetime' => '删除时间'
];
