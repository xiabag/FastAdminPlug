<?php

return [
    'Id'                => '评论 id',
    'Goods_id'          => '商品',
    'Order_id'          => '订单',
    'Order_item_id'     => '订单商品',
    'User_id'           => '用户',
    'Level'             => '评价星级',
    'Content'           => '评价内容',
    'Images'            => '评价图片',
    'Status'            => '显示状态',
    'Status show'       => '显示',
    'Status hidden'     => '隐藏',
    'Admin_id'          => '管理员 id',
    'Reply_content'     => '回复内容',
    'Replytime'         => '回复时间',
    'Createtime'        => '评论时间',
    'Updatetime'        => '更新时间',
    'Deletetime'        => '删除时间',
    'Shoprogoods.title' => '标题',
    'User.id'           => 'ID',
    'User.nickname'     => '昵称',
    'Admin.id'          => 'ID',
    'Admin.nickname'    => '昵称'
];
