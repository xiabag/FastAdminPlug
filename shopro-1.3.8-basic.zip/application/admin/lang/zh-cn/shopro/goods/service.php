<?php

return [
    'Name'        => '名称',
    'Image'       => '服务标志',
    'Description' => '描述',
    'Createtime'        => '添加时间',
    'Updatetime'        => '更新时间'
];
