<?php

return [
    'Goods_id' => '所属产品',
    'Weigh'    => '排序',
    'Image'    => '缩略图',
    'Stock'    => '库存',
    'Sales'    => '已售',
    'Sn'       => '货号',
    'Weight'   => '重量(kg)',
    'Price'    => '价格',
    'Status'   => '状态',
    'Createtime'        => '添加时间',
    'Updatetime'        => '更新时间'
];
