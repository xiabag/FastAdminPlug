<?php

return [
    'Name'              => '名称',
    'Path'              => '路径',
    'Group'             => '所属分组',
    'Createtime'        => '添加时间',
    'Updatetime'        => '更新时间',
    'Deletetime'        => '删除时间',
];
