<?php

return [
    'Id'              => '消息表',
    'Type'            => '消息类型',
    'Notifiable_id'   => '接收人',
    'Notifiable_type' => '接收人类型',
    'Data'            => '数据',
    'Readtime'        => '是否已读',
    'Createtime'      => '创建时间',
    'Updatetime'      => '更新时间',
    'Deletetime'      => '删除时间'
];
