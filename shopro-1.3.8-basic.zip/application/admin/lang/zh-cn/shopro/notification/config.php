<?php

return [
    'Id'       => 'ID',
    'Platform' => '发送平台',
    'Name'     => '消息名称',
    'Event'    => '消息事件',
    'Content'  => '消息内容',
    'Status'   => '状态',
    'Status 0' => '关闭',
    'Status 1' => '启用'
];
