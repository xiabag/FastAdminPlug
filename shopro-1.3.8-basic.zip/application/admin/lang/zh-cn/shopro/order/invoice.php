<?php

return [
    'Type'                 => '发票类型',
    'Person'               => '个人',
    'Company'              => '企/事业单位',
    'Header_name'          => '抬头名称',
    'Tax_no'               => '税号',
    'Mobile'               => '手机号',
    'Amount'               => '金额',
    'Order_id'             => '订单',
    'User_id'              => '用户',
    'Status'               => '状态',
    'Status 0'             => '已申请',
    'Status 1'             => '已开具',
    'Createtime'           => '申请时间',
    'Confirmtime'          => '确认时间',
    'User.nickname'        => '昵称',
    'User.avatar'          => '头像',
    'order.order_sn'       => '订单号',
];

