<?php

return [
    'Order_sn' => '商户订单号',
    'Refund_sn' => '退款单号',
    'Order_item_id' => '订单商品',
    'Pay_fee' => '支付金额',
    'Refund_fee' => '退款金额',
    'Pay_type' => '支付方式',
    'Pay_type wechat' => '微信支付',
    'Pay_type alipay' => '支付宝',
    'Pay_type wallet' => '钱包支付',
    'Pay_type score' => '积分支付',
    'Status' => '退款单状态',
    'Status -1' => '退款失败',
    'Status 0' => '退款中',
    'Status 1' => '退款完成',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间'
];
