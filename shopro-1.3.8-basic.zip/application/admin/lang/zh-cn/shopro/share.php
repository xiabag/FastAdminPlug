<?php

return [
    'Type' => '识别类型',
    'Type index' => '默认分享',
    'Type goods' => '产品分享',
    'Type groupon' => '拼团分享',
];
