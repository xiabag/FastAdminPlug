<?php

return [
    'Name'  => '名称',
    'Path'  => '路径',
    'Group' => '所属分组'
];
