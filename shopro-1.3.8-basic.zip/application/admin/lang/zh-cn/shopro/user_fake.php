<?php

return [
    'Nickname' => '昵称',
    'Avatar'   => '头像'
];
