<?php

return [
    'User_id'      => '提现用户',
    'Money'        => '提现金额',
    'Actual_money'        => '实际到账',
    'Charge_money' => '手续费',
    'Service_fee'  => '手续费率',
    'Apply_type'     => '收款类型',
    'Apply_type bank'     => '银行卡',
    'Apply_type wechat'     => '微信零钱',
    'Apply_type alipay'     => '支付宝',
    'Apply_info'    => '打款信息',
    'Status'       => '提现状态',
    'Status 0'     => '审核中',
    'Status 1'     => '处理中',
    'Status -1'    => '已拒绝',
    'Status 2'     => '已处理',
    'Createtime'   => '申请时间',
    'Updatetime'   => '更新时间',
    'Log'          => '操作日志'
];
