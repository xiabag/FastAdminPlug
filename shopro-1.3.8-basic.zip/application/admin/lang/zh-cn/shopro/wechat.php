<?php

return [
    'Id'         => 'ID',
    'Type'       => '配置类型',
    'Name'       => '名称',
    'Content'    => '内容',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间'
];
