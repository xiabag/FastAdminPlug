<?php

return [
    'Id'             => 'ID',
    'Name'           => '粉丝名称',
    'Avatar'         => '粉丝头像',
    'User_id'        => '用户',
    'Subscribetime'  => '关注时间',
    'Createtime'     => '创建时间',
    'Updatetime'     => '更新时间',
    'Is_subscribe'   => '关注状态',
    'Is_subscribe 0' => '取消关注',
    'Is_subscribe 1' => '已关注'
];
