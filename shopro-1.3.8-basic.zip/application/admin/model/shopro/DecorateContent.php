<?php

namespace app\admin\model\shopro;

use think\Model;

class DecorateContent extends Model
{
    // 表名
    protected $name = 'shopro_decorate_content';

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;





}
