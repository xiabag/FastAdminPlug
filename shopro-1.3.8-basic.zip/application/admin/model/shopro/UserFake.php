<?php

namespace app\admin\model\shopro;

use think\Model;


class UserFake extends Model
{

    

    

    // 表名
    protected $name = 'shopro_user_fake';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [

    ];
    

    







}
