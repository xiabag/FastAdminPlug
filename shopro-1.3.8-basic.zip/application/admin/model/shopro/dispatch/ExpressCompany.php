<?php

namespace app\admin\model\shopro\dispatch;

use think\Model;


class ExpressCompany extends Model
{

    

    

    // 表名
    protected $name = 'shopro_express';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [

    ];
    

    







}
