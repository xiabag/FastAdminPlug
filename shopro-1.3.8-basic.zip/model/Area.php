<?php

namespace addons\shopro\model;

use think\Model;

/**
 * 区域数据
 */
class Area extends Model
{

    // 表名,不含前缀
    protected $name = 'shopro_area';
    // 追加属性
    protected $append = [
    ];



}
