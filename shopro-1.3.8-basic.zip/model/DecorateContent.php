<?php

namespace addons\shopro\model;

use think\Model;

/**
 * 模板装修内容
 */
class DecorateContent extends Model
{

    // 表名,不含前缀
    protected $name = 'shopro_decorate_content';
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;





}
