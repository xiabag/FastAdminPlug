<?php

namespace addons\sysmessage;

use app\common\library\Menu;
use think\Addons;

/**
 * 插件
 */
class Sysmessage extends Addons
{

    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        $menu = [
            [
                'name'    => 'sysmessage',
                'title'   => '系统消息',
                'icon'    => 'fa fa-commenting',
                'sublist' => [
                    ['name' => 'sysmessage/index', 'title' => '查看'],
                    ['name' => 'sysmessage/add', 'title' => '添加'],
                    ['name' => 'sysmessage/detail', 'title' => '详情'],
                    ['name' => 'sysmessage/del', 'title' => '删除'],
                ]
            ]
        ];
        Menu::create($menu);
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        Menu::delete('sysmessage');
        return true;
    }

    /**
     * 插件启用方法
     * @return bool
     */
    public function enable()
    {
        Menu::enable('sysmessage');
        return true;
    }

    /**
     * 插件禁用方法
     * @return bool
     */
    public function disable()
    {
        Menu::disable('sysmessage');
        return true;
    }


}
