<?php

namespace app\api\controller;

use app\common\controller\Api;
use think\paginator\driver\Bootstrap;
/**
 * 首页接口
 */
class Sysmessage extends Api
{
    protected $noNeedLogin = [];
    protected $noNeedRight = ['*'];

    /**
     * 消息列表
     */
    public function list(){
        $page = $this->request->post('page',1);
        $limit = $this->request->post('limit',10);
        $user_id=$this->auth->id;
        $res = db('Sysmessage')->field("id,title,sub_title,FROM_UNIXTIME(createtime,'%Y年%m月%d日') days")
            ->order('createtime desc')
            ->where("user_id={$user_id} or user_id=0")
            ->paginate($limit);
        $result = [];
        $temp = [];
        $last = ''; # 记录上一个坐标
        foreach ($res->all() as $key => $value) {
            # 需要把不同下标的数据分组
            if(($value['days'] != $last)&& !empty($temp)){
                $result[] = $temp;
                $temp = [];
            }
            $temp['days'] = $value['days'];
            $temp['data'][] = $value;
            $last = $value['days'];
        }
        if(count($temp)>0){
            $result[] = $temp;
        }
        $abc=Bootstrap::make($result,$limit,$res->getCurrentPage(),$res->total(),false);
        $this->success('ok',$abc);
    }

    /**
     * 消息详情
     */
    public function detail(){
        $id = $this->request->post('id');
        if(!$id) $this->error('请传入消息ID');
        $res = db('Sysmessage')->field("id,title,sub_title,content,FROM_UNIXTIME(createtime,'%Y年%m月%d日') days")
            ->where(['id'=>$id])
            ->find();
        $this->success('ok',$res);
    }
}
