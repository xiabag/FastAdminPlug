CREATE TABLE IF NOT EXISTS `__PREFIX__sysmessage` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `createtime` int(11) NOT NULL COMMENT '发送时间',
  `user_id` int(11) NOT NULL COMMENT '接收用户ID',
  `title` varchar(255) NOT NULL COMMENT '消息标题',
  `sub_title` varchar(255) NOT NULL COMMENT '子标题',
  `content` text NOT NULL COMMENT '消息内容',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统消息';