<?php

namespace app\admin\controller\wwh;

use app\common\controller\Backend;
use fast\Tree;
use think\Db;
use think\exception\PDOException;
use think\exception\ValidateException;

/**
 * @icon fa fa-circle-o
 */
class News extends Backend
{

    /**
     * WwhNews模型对象
     * @var \app\admin\model\wwh\News
     */
    protected $model = null;

    /**
     * 快速搜索时执行查找的字段
     */
    
    protected $relationSearch = true;
    protected $searchFields = 'newsname';

    public function _initialize()
    {
        parent::_initialize();
        $this->model = model('\app\admin\model\wwh\News');
        $newscategorylist = collection(model('\app\admin\model\wwh\Newscategory')->select())->toArray();
        Tree::instance()->init($newscategorylist);
        $newscategorylist = Tree::instance()->getTreeList(Tree::instance()->getTreeArray(0), 'name');
        $categorylist = array('' => '==请选择==');
        $this->categoryList = Tree::instance()->getTreeList(Tree::instance()->getTreeArray(0), 'name');
        foreach ($newscategorylist as $k => $v) {
            $categorylist[$v['id']] = $v['name'];
        }
        $this->view->assign('newscategorylist', $categorylist);
        $this->view->assign("tjdataList", $this->model->getTjdataList());
        $this->view->assign("statusList", $this->model->getStatusList());
    }

    /**
     * 默认生成的控制器所继承的父类中有index/add/edit/del/multi五个基础方法、destroy/restore/recyclebin三个回收站方法
     * 因此在当前控制器中可不用编写增删改查的代码,除非需要自己控制这部分逻辑
     * 需要将application/admin/library/traits/Backend.php中对应的方法复制到当前控制器,然后进行修改
     */

    /**
     * 查看
     */
    public function index()
    {
        //设置过滤方法
        $this->request->filter(['strip_tags']);
        if ($this->request->isAjax()) {
            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField')) {
                return $this->selectpage();
            }
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();
            $categoryids = $this->request->request("categoryids");
            $query = [];
            if ($categoryids !== null) {
                $query["news.newscategoryid"] = ["in", $categoryids];
            }

            $total = $this->model
                    ->with('newscategory')
                    ->where($where)
                    ->where($query)
                    ->order($sort, $order)
                    ->count();
            $list = $this->model
                    ->with('newscategory')
                    ->where($where)
                    ->where($query)
                    ->order($sort, $order)
                    ->limit($offset, $limit)
                    ->select();
            $list = collection($list)->toArray();
            $result = array("total" => $total, "rows" => $list);
            return json($result);
        }
        return $this->view->fetch();
    }

    /**
     * 编辑
     */
    public function edit($ids = null)
    {
        $row = $this->model->get($ids);
        if (!$row) {
            $this->error(__('No Results were found'));
        }
        $adminIds = $this->getDataLimitAdminIds();
        if (is_array($adminIds)) {
            if (!in_array($row[$this->dataLimitField], $adminIds)) {
                $this->error(__('You have no permission'));
            }
        }
        $newsstatus = $this->model->where(['status'=>'1','id'=>$ids])->limit(1)->select();
        if ($newsstatus) {
            $this->error('该新闻已审核，不能编辑！');
        }
        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");
            if ($params) {
                $params = $this->preExcludeFields($params);
                $result = false;
                Db::startTrans();
                try {
                    //是否采用模型验证
                    if ($this->modelValidate) {
                        $name = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                        $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.edit' : $name) : $this->modelValidate;
                        $row->validateFailException(true)->validate($validate);
                    }
                    $result = $row->allowField(true)->save($params);
                    Db::commit();
                } catch (ValidateException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (PDOException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (Exception $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                }
                if ($result !== false) {
                    $this->success();
                } else {
                    $this->error(__('No rows were updated'));
                }
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }
        $this->view->assign("row", $row);
        return $this->view->fetch();
    }

    /**
     * 删除
     */
    public function del($ids = "")
    {
        if (!$this->request->isPost()) {
            $this->error(__("Invalid parameters"));
        }
        $ids = $ids ? $ids : $this->request->post("ids");
        if ($ids) {
            $pk = $this->model->getPk();
            $adminIds = $this->getDataLimitAdminIds();
            if (is_array($adminIds)) {
                $this->model->where($this->dataLimitField, 'in', $adminIds);
            }
            $list = $this->model->where($pk, 'in', $ids)->select();
            $count = 0;
            Db::startTrans();
            try {
                foreach ($list as $k => $v) {
                    $newsstatus = $this->model->where(['status'=>'1','id'=>$ids])->limit(1)->select();
                    if ($newsstatus) {
                        $this->error('该新闻已审核，不能删除！');
                    } else {
                        $count += $v->delete();
                    }
                }
                Db::commit();
            } catch (PDOException $e) {
                Db::rollback();
                $this->error($e->getMessage());
            } catch (Exception $e) {
                Db::rollback();
                $this->error($e->getMessage());
            }
            if ($count) {
                $this->success();
            } else {
                $this->error(__('No rows were deleted'));
            }
        }
        $this->error(__('Parameter %s can not be empty', 'ids'));
    }

    /**
     * 获取所有列表
     */
    public function getallnewslist()
    {
        //设置过滤方法
        if ($this->request->isAjax()) {
            $list = $this->model
                    ->select();
            $list = collection($list)->toArray();
            return json($list);
        }
    }

    /**
     * 审核
     */
    public function audit($ids)
    {
        foreach ($ids as $k => $v){
            $res = $this->model->where(['id' => ['in', $ids]])->update(['status' => 1]);
            if ($res == true) {
                $this->success('审核成功');
            } else {
                $this->error('未更新任何行');
            }
        }
    }

    /**
     * 反审核
     */
    public function faudit($ids)
    {
        $res = $this->model->where(['status'=>'1','id'=>$ids])->update(['status' => 0]);
        if ($res) {
            $this->success('反审核成功');
        } else {
            $this->error('未更新任何行');
        }
    }

}
