<?php

return [
    'Title'       => '标题',
    'Pc_image'    => 'PC图片',
    'Phone_image' => '手机图片',
    'Video_image' => '视频',
    'Bigfont'     => '大字',
    'Font'        => '小字',
    'Url'         => '链接',
    'Sort'        => '排序',
    'Updatetime'  => '更新时间'
];
