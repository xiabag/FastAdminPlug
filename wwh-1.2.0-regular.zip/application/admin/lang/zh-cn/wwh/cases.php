<?php

return [
    'Casescategoryid' => '分类ID',
    'Createtime'      => '创建时间',
    'Casescategory'   => '方案分类',
    'Category Manager'=> '方案分类管理',
    'Casesname'       => '方案名称',
    'C_keywords'      => '关键字',
    'C_description'   => '说明',
    'Indent_image'    => '方案缩列图',
    'Time'            => '日期',
    'Description'     => '描述',
    'Content'         => '内容',
    'Views'           => '浏览次数',
    'Updatetime'      => '更新时间'
];
