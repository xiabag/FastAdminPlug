<?php

return [
    'Pid'            => 'pid',
    'Fjname'         => '父级分类',
    'Name'           => '方案分类名称'
];
