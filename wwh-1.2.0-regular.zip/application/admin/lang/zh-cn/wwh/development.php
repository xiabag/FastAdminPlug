<?php

return [
    'Createtime' => '添加时间',
    'Year'       => '发展历程年份',
    'Content'    => '发展历程介绍'
];
