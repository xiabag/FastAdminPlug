<?php

return [
    'Id'                 => 'ID',
    'Downloadcategoryid'     => '分类ID',
    'Downloadcategorys'      => '下载分类',
    'Downloadcategory'       => '分类名称',
    'Category Manager'   => '下载分类管理',
    'Downloadname'           => '名称',
    'Createtime' => '添加时间',
    'Time'       => '发布日期',
    'Weigh'      => '排序',
    'Attachfile' => '文件'
];
