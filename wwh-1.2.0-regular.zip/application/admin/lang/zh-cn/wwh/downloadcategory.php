<?php

return [
    'Name'  =>  '分类名称',
    'Fjname'  =>  '父级分类',
];
