<?php

return [
    'Createtime' => '创建时间',
    'Name'       => '证书名称',
    'Image'      => '证书图片',
    'Sort'       => '排序',
    'Updatetime' => '更新时间'
];
