<?php

return [
    'Realname'   => '姓名',
    'Tel'        => '联系电话',
    'Gangwei'    => '应聘岗位',
    'Content'    => '内容',
    'Url'        => '简历',
    'Createtime' => '提交时间'
];
