<?php

return [
    'Createtime' => '创建时间',
    'Citylist'   => '城市',
    'Name'       => '联系人',
    'Address'    => '地址',
    'Tel'        => '电话',
    'Updatetime' => '更新时间'
];
