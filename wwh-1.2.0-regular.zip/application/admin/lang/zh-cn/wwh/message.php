<?php

return [
    'Realname' => '姓名',
    'Company'  => '公司名称',
    'Tel'      => '电话',
    'Email'    => '邮箱',
    'Content'  => '留言内容',
    'Createtime' => '提交时间'
];
