<?php

return [
    'Id'                 => 'ID',
    'Newscategoryid'     => '分类ID',
    'Newscategorys'      => '新闻分类',
    'Newscategory'       => '分类名称',
    'Category Manager'   => '新闻分类管理',
    'Newsname'           => '新闻名称',
    'N_keywords'         => '关键字',
    'N_description'      => '说明',
    'Summary'            => '摘要',
    'Tjdata'             => '首页显示',
    'Tjdata 0'           => '不显示',
    'Tjdata 1'           => '显示',
    'Image'              => '图片',
    'Weigh'              => '权重',
    'Time'               => '日期',
    'Content'            => '内容',
    'Views'              => '浏览次数',
    'Status'             => '审核状态',
    'Status 0'           => '未审核',
    'Status 1'           => '已审核',
    'Updatetime'         => '更新时间'
];
