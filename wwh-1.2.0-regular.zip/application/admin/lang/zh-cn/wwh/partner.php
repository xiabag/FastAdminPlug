<?php

return [
    'Id'         => 'ID',
    'Createtime' => '创建时间',
    'Title'      => '标题',
    'Image'      => '图片',
    'Weigh'      => '权重',
    'Updatetime' => '更新时间'
];
