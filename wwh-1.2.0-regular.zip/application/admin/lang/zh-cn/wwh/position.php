<?php

return [
    'Name'    => '职位名称',
    'Dept'    => '部门',
    'Addr'    => '工作地点',
    'Xueli'   => '学历',
    'Num'     => '招聘人数',
    'Time'    => '发布日期',
    'Content' => '内容'
];
