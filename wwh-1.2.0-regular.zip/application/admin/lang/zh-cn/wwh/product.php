<?php

return [
    'Createtime'        => '创建时间',
    'Updatetime'        => '更新时间',
    'Productcategory'   => '产品分类',
    'Productname'       => '产品名称',
    'P_keywords'        => '关键字',
    'P_description'     => '说明',
    'Model'             => '产品型号',
    'Tjdata'            => '首页推荐',
    'Tjdata 0'          => '不推荐',
    'Tjdata 1'          => '推荐',
    'Description'       => '产品描述',
    'Indent_image'      => '产品缩列图',
    'Banner_images'     => '产品轮播图',
    'Index_image'       => '首页推荐图',
    'Gn_content'        => '功能特点',
    'Zb_content'        => '技术指标',
    'Size_image'        => '外形尺寸',
    'Category Manager'  => '产品分类管理'
];
