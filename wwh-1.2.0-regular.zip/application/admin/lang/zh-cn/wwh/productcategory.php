<?php

return [
    'Pid'               => 'pid',
    'Fjname'            => '父级分类',
    'Name'              => '产品分类名称'
];
