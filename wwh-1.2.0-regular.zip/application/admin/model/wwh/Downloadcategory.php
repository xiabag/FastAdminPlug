<?php

namespace app\admin\model\wwh;

use think\Exception;
use think\Model;

class Downloadcategory extends Model
{
    // 表名
    protected $name = 'wwh_downloadcategory';
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;
    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    // 追加属性
    protected $append = [
    ];

    protected static function init()
    {
        self::beforeUpdate(function ($row) {
            if ($row['pid']) {
                $childrenIds = self::getChildrenIds($row['id'], true);
                if (in_array($row['pid'], $childrenIds)) {
                    throw new Exception("父级分类不能是其自身或下级分类");
                }
            }
        });
    }

    public static function getChildrenIds($id, $withself = false)
    {
        static $tree;
        if (!$tree) {
            $tree = \fast\Tree::instance();
            $tree->init(collection(Downloadcategory::order('id desc')->field('id,pid,name')->select())->toArray(), 'pid');
        }
        $childIds = $tree->getChildrenIds($id, $withself);
        return $childIds;
    }
}
