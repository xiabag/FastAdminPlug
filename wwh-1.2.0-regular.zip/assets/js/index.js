$(function () {
  /*
      eg: <div class="wow animate slideInLeft" data-wow-delay="200ms"></div>
      可选参数：
      data-wow-duration（动画持续时间）
      data-wow-delay（动画延迟时间）
      data-wow-offset（元素的位置露出后距离底部多少像素执行）
      data-wow-iteration（动画执行次数）
  */
  var volist = 0;
  if (!(/msie [6|7|8|9]/i.test(navigator.userAgent))) {
    var wow = new WOW({
      boxClass: 'wow', //	需要执行动画的元素的 class
      animateClass: 'animated', // animation.css 动画的 class
      offset: 0, // 元素的位置露出后距离底部多少像素执行
      mobile: true, // 是否在移动设备上执行动画
      live: true, // 异步加载的内容是否有效
      callback: function (e) {
        if ($(e).attr('data-type') == 'volist') {
          volist += 100;
          $(e).css("animation-delay", volist + 'ms');
        }
      }
    });
    wow.init();
  }

  setTimes();
  var timeOuts = null
  function setTimes() {
    timeOuts = setTimeout(function() {
      volist = 0;
    }, 150);
  }

  var st = $(window).scrollTop();
  $(window).scroll(function () {
    /*滚动时先清除上一个定时器,然后再设置新的定时器,以免出现多个定时器造成混乱*/
    clearTimeout(timeOuts);
    setTimes();

    st = $(window).scrollTop();
  });


  /*首页Banner*/
  var width=$(window).width();

  // 获取第一个视频时长
  $(".banner .swiper-slide").each(function(){
    if($(this).has('video').length){
      $(this).find('video').attr('id','video');
      return false;
    }
  });

  var audioE2  = document.getElementById("video");
  // 如果swiper有视频
  if(audioE2){
    // 上传了视频,等待视频加载完
    audioE2 .onloadedmetadata = function() {
      var tol=audioE2.duration;
      // tol=tol*1000;
      var banner_swiper = new Swiper('.banner .swiper-container',{
        speed:1000,
        loop:true,
        // autoplay:false,
        autoplay: {
          delay: 5000,
          stopOnLastSlide: false,
          disableOnInteraction: false,
        },
        navigation: {
          nextEl: '.banner .swiper-button-next',
          prevEl: '.banner .swiper-button-prev',
        },
        pagination: {
          el: '.banner .swiper-pagination',
          clickable: true,
        },
        on: {
          init: function(){
            $('.banner .swiper-slide').eq(this.activeIndex).find('.text').addClass('active');
          },
          slideChangeTransitionStart: function(){
            $('.banner .swiper-slide').find('.text').removeClass('active').eq(this.activeIndex).addClass('active').siblings();
            var _target = this;
            var curVideo = this.$el.find(".swiper-slide-active").find("video");
            // tol=curVideo.duration;
            //暂停所有视频
            function pauseAll(ele){
              ele.find("video").each(function(){
                $(this)[0].pause();
              });
            }
            pauseAll(this.$el);
            //轮播间隔时间
            console.log(tol)
            _target.params.autoplay.delay = tol*1000;
            //判断当前激活元素是否有视频
            if(curVideo.length > 0){
              console.log("有视频！");
              this.autoplay.stop();
              curVideo[0].currentTime = 0;
              curVideo[0].play();
              curVideo[0].removeEventListener('ended', function (){}, false);
              curVideo[0].addEventListener('ended', function (){
                if($('.banner .sign').hasClass('active')){
                  // 此时是暂停状态
                }else{
                  _target.slideNext();
                }

              }, false);
            }else{
              console.log("无视频！");
              _target.params.autoplay.delay=5000;
              _target.autoplay.start();
              $('.banner .sign').removeClass('active');
              flag=true;
            }

          },
        },
      });
    }
  }else{
    // 没上传视频
    var banner_swiper = new Swiper('.banner .swiper-container',{
      speed:1000,
      loop:true,
      // autoplay:false,
      autoplay: {
        delay: 5000,
        stopOnLastSlide: false,
        disableOnInteraction: false,
      },
      navigation: {
        nextEl: '.banner .swiper-button-next',
        prevEl: '.banner .swiper-button-prev',
      },
      pagination: {
        el: '.banner .swiper-pagination',
        clickable: true,
      },
      on: {
        init: function(){
          $('.banner .swiper-slide').eq(this.activeIndex).find('.text').addClass('active');
        },
        slideChangeTransitionStart: function(){
          $('.banner .swiper-slide').find('.text').removeClass('active').eq(this.activeIndex).addClass('active').siblings();
        },
      },
    });
  }

});

/*产品分类侧栏*/
$(function(){
  $('.pn-list .pn-tit.cursleect').parents('.pn-content').slideDown().prev('.pn-tit').addClass('cur cut');

  var retractLeft = $(".pn-list").width();
  $('.pn-box').hover(function(){
    $('.pn-list').addClass('on')
    $('.pn-retract').css("left",retractLeft)
  },function(){
    $('.pn-list').removeClass('on')
    $('.pn-retract').css("left",-retractLeft)
  })

  $('.pn-retract').hover(function() {
    $('.pn-list').removeClass('on');
    $('.pn-retract').css("left",-retractLeft)
  },function(){
    $('.pn-list').addClass('on')
    $('.pn-retract').css("left",retractLeft)
  })

  $('.pn-list li .pn-tit-one').on('click',function(){
    var sss = $(this).parent('li').index();
    var len = $('.pn-list li').length-1;
    if (sss == len) {
      var off = $(this).offset().top - ($('.pn-list').height()/2);
      $('.pn-list').stop().animate({'scrollTop':off},500);
    };

    if (!$(this).hasClass('cut')) {
      $(this).addClass('cut').parents('li').siblings('li').find('.pn-tit-one').removeClass('cut');
      $(this).next('.pn-con-one').slideDown().parents('li').siblings('li').find('.pn-con-one').slideUp()
    }else{
      $(this).removeClass('cut')
      $(this).next('.pn-con-one').slideUp()
    }
  })
  $('.pn-list li .pn-tit-two').on('click',function(){
    var sss = $(this).parent('li').index();
    var len = $('.pn-list li').length-1;
    if (sss == len) {
      var off = $(this).offset().top - ($('.pn-list').height()/2);
      $('.pn-list').stop().animate({'scrollTop':off},500);
    };

    if (!$(this).hasClass('cut')) {
      $(this).addClass('cut').parents('li').siblings('li').find('.pn-tit-two').removeClass('cut');
      $(this).next('.pn-con-two').slideDown().parents('li').siblings('li').find('.pn-con-two').slideUp()
    }else{
      $(this).removeClass('cut')
      $(this).next('.pn-con-two').slideUp()
    }
  })

  $('.pn-list li .pn-tit-three').on('click',function(){
    if (!$(this).hasClass('cur')) {
      $(this).addClass('cur').siblings('.pn-tit-three').removeClass('cur').parents('li').siblings('li').find('.pn-tit-three').removeClass('cur');
      $(this).next('.pn-con-three').slideDown().siblings('.pn-con-three').slideUp().parents('li').siblings('li').find('.pn-con-three').slideUp()
    }else{
      $(this).removeClass('cur')
      $(this).next('.pn-con-three').slideUp()
    }
  })

});
