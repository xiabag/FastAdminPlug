<?php

namespace addons\wwh\controller;

use think\Config;
use think\Db;
use think\Request;

class Base extends \think\addons\Controller
{
    // 初始化
    public function __construct(Request $request = null)
    {
        parent::__construct($request);
        $config = get_addon_config('wwh');
        // 设定主题模板目录
        $this->view->engine->config('view_path', $this->view->engine->config('view_path') . $config['theme'] . DS);
    }

    public function _initialize()
    {
        parent::_initialize();
        // 如果请求参数action的值为一个方法名,则直接调用
        $action = $this->request->post("action");
        if ($action && $this->request->isPost()) {
            return $this->$action();
        }
        //产品中心分类
        $productcategory = Db::name('wwh_productcategory')->where('pid', 0)->limit(6)->select();
        $this->assign('productcategory', $productcategory);
        //解决方案分类
        $casescategory = Db::name('wwh_casescategory')->where('pid', 0)->limit(6)->select();
        $this->assign('casescategory', $casescategory);
        //新闻中心分类
        $newscategory = Db::name('wwh_newscategory')->where('pid', 0)->limit(6)->select();
        $this->assign('newscategory', $newscategory);
        //站点设置
        $config = Db::name('wwh_config')->where('id', 1)->find();
        if ($config) {
            $this->assign('config', $config);
        } else {
            $this->error("请导入测试数据");
        }
    }
}
