
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

--
-- 表的结构 `__PREFIX__wwh_about`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__wwh_about` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `about_title` varchar(100) DEFAULT NULL COMMENT '关于标题',
  `about_description` text COMMENT '关于简述',
  `about_content` text COMMENT '关于内容',
  `about_image` varchar(100) DEFAULT NULL COMMENT '关于图片',
  `culture_title1` varchar(100) DEFAULT NULL COMMENT '企业文化标题1',
  `culture_en1` varchar(100) DEFAULT NULL COMMENT '企业文化英文1',
  `culture_des1` varchar(500) DEFAULT NULL COMMENT '企业文化描述1',
  `culture_image1` varchar(100) DEFAULT NULL COMMENT '企业文化图片1',
  `culture_title2` varchar(100) DEFAULT NULL COMMENT '企业文化标题2',
  `culture_en2` varchar(500) DEFAULT NULL COMMENT '企业文化英文2',
  `culture_image2` varchar(100) DEFAULT NULL COMMENT '企业文化图片2',
  `culture_title3` varchar(100) DEFAULT NULL COMMENT '企业文化标题3',
  `culture_en3` varchar(500) DEFAULT NULL COMMENT '企业文化英文3',
  `culture_image3` varchar(100) DEFAULT NULL COMMENT '企业文化图片3',
  `culture_title4` varchar(100) DEFAULT NULL COMMENT '企业文化标题4',
  `culture_en4` varchar(500) DEFAULT NULL COMMENT '企业文化英文4',
  `culture_image4` varchar(100) DEFAULT NULL COMMENT '企业文化图片4',
  `culture_title5` varchar(100) DEFAULT NULL COMMENT '企业文化标题5',
  `culture_en5` varchar(500) DEFAULT NULL COMMENT '企业文化英文5',
  `culture_image5` varchar(100) DEFAULT NULL COMMENT '企业文化图片5',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

--
-- 表的结构 `__PREFIX__wwh_banner`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__wwh_banner` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(1000) DEFAULT NULL COMMENT '标题',
  `pc_image` varchar(1000) DEFAULT NULL COMMENT 'PC图片',
  `phone_image` varchar(1000) DEFAULT NULL COMMENT '手机图片',
  `video_image` varchar(1000) DEFAULT NULL COMMENT '视频',
  `bigfont` varchar(1000) DEFAULT NULL COMMENT '大字',
  `font` varchar(1000) DEFAULT NULL COMMENT '小字',
  `url` varchar(1000) DEFAULT NULL COMMENT '链接',
  `sort` varchar(10) DEFAULT NULL COMMENT '排序',
  `updatetime` int(11) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

--
-- 表的结构 `__PREFIX__wwh_cases`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__wwh_cases` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `casescategoryid` int(11) DEFAULT NULL COMMENT '分类ID',
  `createtime` int(11) NOT NULL COMMENT '创建时间',
  `casesname` varchar(100) DEFAULT NULL COMMENT '方案名称',
  `c_keywords` varchar(1000) DEFAULT NULL COMMENT '关键字',
  `c_description` varchar(1000) DEFAULT NULL COMMENT '说明',
  `indent_image` varchar(1000) DEFAULT NULL COMMENT '方案缩列图',
  `time` date DEFAULT NULL COMMENT '日期',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `content` text COMMENT '内容',
  `views` int(10) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `updatetime` int(11) NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

--
-- 表的结构 `__PREFIX__wwh_casescategory`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__wwh_casescategory` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int(10) DEFAULT '0' COMMENT 'pid',
  `name` varchar(50) DEFAULT NULL COMMENT '方案分类名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

--
-- 表的结构 `__PREFIX__wwh_config`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__wwh_config` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `site_name` varchar(100) DEFAULT NULL COMMENT '站点名称',
  `keywords` varchar(500) DEFAULT NULL COMMENT '关键字',
  `description` varchar(1000) DEFAULT NULL COMMENT '描述',
  `logo` varchar(1000) DEFAULT NULL COMMENT 'logo',
  `footer_logo` varchar(1000) DEFAULT NULL COMMENT '底部logo',
  `email` varchar(1000) DEFAULT NULL COMMENT '邮箱',
  `tel` varchar(100) DEFAULT NULL COMMENT '电话',
  `gongwang` varchar(1000) DEFAULT NULL COMMENT '公网安备号',
  `link1` varchar(100) DEFAULT NULL COMMENT '公网安备地址',
  `beian` varchar(1000) DEFAULT NULL COMMENT '网站备案号',
  `link2` varchar(100) DEFAULT NULL COMMENT '备案地址',
  `copyright` varchar(1000) DEFAULT NULL COMMENT '版权',
  `image` varchar(1000) DEFAULT NULL COMMENT '二维码图片',
  `banner1` varchar(500) DEFAULT NULL COMMENT '产品中心',
  `ban1_t1` varchar(100) DEFAULT NULL COMMENT '产品中心英文',
  `ban1_t2` varchar(100) DEFAULT NULL COMMENT '产品中心中文',
  `banner2` varchar(500) DEFAULT NULL COMMENT '解决方案',
  `ban2_t1` varchar(100) DEFAULT NULL COMMENT '解决方案英文',
  `ban2_t2` varchar(100) DEFAULT NULL COMMENT '解决方案中文',
  `banner3` varchar(500) DEFAULT NULL COMMENT '服务中心',
  `ban3_t1` varchar(100) DEFAULT NULL COMMENT '服务中心英文',
  `ban3_t2` varchar(100) DEFAULT NULL COMMENT '服务中心中文',
  `banner4` varchar(500) DEFAULT NULL COMMENT '新闻中心',
  `ban4_t1` varchar(100) DEFAULT NULL COMMENT '新闻中心英文',
  `ban4_t2` varchar(100) DEFAULT NULL COMMENT '新闻中心中文',
  `banner5` varchar(500) DEFAULT NULL COMMENT '关于我们',
  `ban5_t1` varchar(100) DEFAULT NULL COMMENT '关于我们英文',
  `ban5_t2` varchar(100) DEFAULT NULL COMMENT '关于我们中文',
  `banner6` varchar(500) DEFAULT NULL COMMENT '合作伙伴',
  `ban6_t1` varchar(100) DEFAULT NULL COMMENT '合作伙伴英文',
  `ban6_t2` varchar(100) DEFAULT NULL COMMENT '合作伙伴中文',
  `caidan1` varchar(100) DEFAULT NULL COMMENT '菜单图1',
  `caidan2` varchar(100) DEFAULT NULL COMMENT '菜单图2',
  `caidan3` varchar(100) DEFAULT NULL COMMENT '菜单图3',
  `caidan4` varchar(100) DEFAULT NULL COMMENT '菜单图4',
  `caidan5` varchar(100) DEFAULT NULL COMMENT '菜单图5',
  `content` text COMMENT '底部链接',
  `map_zb` varchar(100) DEFAULT NULL COMMENT '地图坐标',
  `map_dzq` varchar(100) DEFAULT NULL COMMENT '到这去坐标',
  `map_mc` varchar(100) DEFAULT NULL COMMENT '地图公司名称',
  `map_dz` varchar(100) DEFAULT NULL COMMENT '地图公司地址',
  `sale` varchar(50) DEFAULT NULL COMMENT '销售咨询',
  `technology` varchar(50) DEFAULT NULL COMMENT '技术支持',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

--
-- 表的结构 `__PREFIX__wwh_contact`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__wwh_contact` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `tel` varchar(100) DEFAULT NULL COMMENT '总机',
  `fax` varchar(100) DEFAULT NULL COMMENT '传真',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `time` varchar(100) DEFAULT NULL COMMENT '工作时间',
  `address` varchar(500) DEFAULT NULL COMMENT '地址',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

--
-- 表的结构 `__PREFIX__wwh_development`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__wwh_development` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `createtime` int(11) NOT NULL COMMENT '添加时间',
  `year` varchar(50) NOT NULL COMMENT '发展历程年份',
  `content` text NOT NULL COMMENT '发展历程介绍',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

--
-- 表的结构 `__PREFIX__wwh_download`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__wwh_download` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `downloadcategoryid` int(10) DEFAULT NULL COMMENT '分类ID',
  `createtime` int(11) NOT NULL COMMENT '添加时间',
  `downloadname` varchar(100) NOT NULL COMMENT '名称',
  `time` date NOT NULL COMMENT '发布日期',
  `weigh` int(11) NOT NULL COMMENT '排序',
  `attachfile` varchar(1000) NOT NULL COMMENT '文件',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

--
-- 表的结构 `__PREFIX__wwh_downloadcategory`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__wwh_downloadcategory` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int(10) DEFAULT NULL COMMENT 'PID',
  `name` varchar(50) DEFAULT NULL COMMENT '分类名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

--
-- 表的结构 `__PREFIX__wwh_home`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__wwh_home` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `about_title` varchar(100) DEFAULT NULL COMMENT '关于标题',
  `introduction` text COMMENT '关于介绍',
  `title1` varchar(100) DEFAULT NULL COMMENT '标题1',
  `description1` varchar(1000) DEFAULT NULL COMMENT '描述1',
  `title2` varchar(100) DEFAULT NULL COMMENT '标题2',
  `description2` varchar(1000) DEFAULT NULL COMMENT '描述2',
  `title3` varchar(100) DEFAULT NULL COMMENT '标题3',
  `description3` varchar(1000) DEFAULT NULL COMMENT '描述3',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

--
-- 表的结构 `__PREFIX__wwh_honor`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__wwh_honor` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `createtime` int(11) NOT NULL COMMENT '创建时间',
  `name` varchar(100) DEFAULT NULL COMMENT '证书名称',
  `image` varchar(1000) DEFAULT NULL COMMENT '证书图片',
  `sort` int(11) NOT NULL COMMENT '排序',
  `updatetime` int(11) NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

--
-- 表的结构 `__PREFIX__wwh_injoin`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__wwh_injoin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `realname` varchar(255) NOT NULL COMMENT '姓名',
  `tel` varchar(255) NOT NULL COMMENT '联系电话',
  `gangwei` varchar(255) NOT NULL COMMENT '应聘岗位',
  `content` varchar(255) DEFAULT NULL COMMENT '内容',
  `url` varchar(255) DEFAULT NULL COMMENT '简历',
  `createtime` int(11) DEFAULT NULL COMMENT '提交时间',
   PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

--
-- 表的结构 `__PREFIX__wwh_market`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__wwh_market` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `createtime` int(11) NOT NULL COMMENT '创建时间',
  `citylist` enum('浙江','江苏','安徽','山东','福建','广东','江西','北京','陕西','河北','辽宁','湖南','河南','上海','云南','四川','湖北','吉林','山西','重庆','广西','天津','内蒙古','贵州','黑龙江','海南','台湾','香港','新疆','甘肃','宁夏','青海','澳门','西藏') NOT NULL COMMENT '城市',
  `name` varchar(50) DEFAULT NULL COMMENT '联系人',
  `address` varchar(255) DEFAULT NULL COMMENT '地址',
  `tel` varchar(255) DEFAULT NULL COMMENT '电话',
  `updatetime` int(11) NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

--
-- 表的结构 `__PREFIX__wwh_message`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__wwh_message` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `realname` varchar(50) DEFAULT NULL COMMENT '姓名',
  `company` varchar(50) DEFAULT NULL COMMENT '公司名称',
  `tel` varchar(50) DEFAULT NULL COMMENT '电话',
  `email` varchar(50) DEFAULT NULL COMMENT '邮箱',
  `content` text COMMENT '留言内容',
  `createtime` int(11) DEFAULT NULL COMMENT '提交时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

--
-- 表的结构 `__PREFIX__wwh_news`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__wwh_news` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `newscategoryid` int(10) DEFAULT NULL COMMENT '分类ID',
  `newsname` varchar(100) DEFAULT NULL COMMENT '新闻标题',
  `n_keywords` varchar(1000) DEFAULT NULL COMMENT '关键字',
  `n_description` varchar(1000) DEFAULT NULL COMMENT '说明',
  `summary` varchar(100) DEFAULT NULL COMMENT '摘要',
  `tjdata` enum('0','1') NOT NULL COMMENT '顶部推荐:0=不显示,1=显示',
  `image` varchar(255) DEFAULT NULL COMMENT '图片',
  `weigh` int(11) NOT NULL COMMENT '权重',
  `time` date NOT NULL COMMENT '日期',
  `content` text COMMENT '内容',
  `views` int(10) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `status` enum('0','1') NOT NULL DEFAULT '0' COMMENT '审核状态',
  `updatetime` int(10) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

--
-- 表的结构 `__PREFIX__wwh_newscategory`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__wwh_newscategory` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int(10) DEFAULT '0' COMMENT 'pid',
  `name` varchar(50) DEFAULT NULL COMMENT '分类名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

--
-- 表的结构 `__PREFIX__wwh_partner`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__wwh_partner` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `createtime` int(11) NOT NULL COMMENT '创建时间',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `image` varchar(250) NOT NULL COMMENT '图片',
  `weigh` int(11) NOT NULL COMMENT '权重',
  `updatetime` int(11) NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

--
-- 表的结构 `__PREFIX__wwh_position`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__wwh_position` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(100) NOT NULL COMMENT '职位名称',
  `dept` varchar(100) NOT NULL COMMENT '部门',
  `addr` varchar(100) NOT NULL COMMENT '工作地点',
  `xueli` varchar(100) NOT NULL COMMENT '学历',
  `num` varchar(10) NOT NULL COMMENT '招聘人数',
  `time` date DEFAULT NULL COMMENT '发布日期',
  `content` text NOT NULL COMMENT '内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

--
-- 表的结构 `__PREFIX__wwh_product`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__wwh_product` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `productcategoryid` int(11) DEFAULT NULL COMMENT '分类ID',
  `pids` varchar(255) NOT NULL DEFAULT '0' COMMENT 'pids',
  `createtime` int(11) NOT NULL COMMENT '创建时间',
  `productname` varchar(100) DEFAULT NULL COMMENT '产品名称',
  `p_keywords` varchar(1000) DEFAULT NULL COMMENT '关键字',
  `p_description` varchar(1000) DEFAULT NULL COMMENT '说明',
  `tjdata` enum('0','1') NOT NULL COMMENT '首页推荐:0=不推荐,1=推荐',
  `model` varchar(1000) DEFAULT NULL COMMENT '产品型号',
  `description` varchar(500) DEFAULT NULL COMMENT '产品描述',
  `indent_image` varchar(1000) DEFAULT NULL COMMENT '产品缩列图',
  `banner_images` varchar(1000) DEFAULT NULL COMMENT '产品轮播图',
  `index_image` varchar(1000) DEFAULT NULL COMMENT '首页推荐图',
  `gn_content` text COMMENT '功能特点',
  `zb_content` text COMMENT '技术指标',
  `size_image` varchar(1000) DEFAULT NULL COMMENT '外形尺寸',
  `updatetime` int(11) NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

--
-- 表的结构 `__PREFIX__wwh_productcategory`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__wwh_productcategory` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int(10) DEFAULT NULL COMMENT 'pid',
  `pids` varchar(255) NOT NULL DEFAULT '0' COMMENT 'pids',
  `name` varchar(50) DEFAULT NULL COMMENT '产品分类名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

--
-- 表的结构 `__PREFIX__wwh_service`
--

CREATE TABLE IF NOT EXISTS `__PREFIX__wwh_service` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `content` text COMMENT '服务策略',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
COMMIT;

--
-- 转存表中的数据 `__PREFIX__wwh_config`
--

INSERT INTO `__PREFIX__wwh_config` (`id`, `site_name`, `keywords`, `description`, `logo`, `footer_logo`, `email`, `tel`, `gongwang`, `link1`, `beian`, `link2`, `copyright`, `image`, `banner1`, `ban1_t1`, `ban1_t2`, `banner2`, `ban2_t1`, `ban2_t2`, `banner3`, `ban3_t1`, `ban3_t2`, `banner4`, `ban4_t1`, `ban4_t2`, `banner5`, `ban5_t1`, `ban5_t2`, `banner6`, `ban6_t1`, `ban6_t2`, `caidan1`, `caidan2`, `caidan3`, `caidan4`, `caidan5`, `content`, `map_zb`, `map_dzq`, `map_mc`, `map_dz`, `sale`, `technology`) VALUES
(1, '站点名称', '企业站点关键字', '企业站点描述', 'http://demo.wuwenhui.cn/uploads/20200909/logo.png', 'http://demo.wuwenhui.cn/uploads/20200909/footer_logo.png', 'wwh@admin.com', '0571-88888888', '浙公网安备XXXXXXXXXXXXXX号', 'http://www.beian.gov.cn/', '浙ICP备XXXXXXXX号', 'http://beian.miit.gov.cn/', 'Copyright © 2001-2020 XXXXXXXX公司 版权所有', 'http://demo.wuwenhui.cn/uploads/20200909/01ffee79c617d9296476eb7119fae45f.jpg', 'http://demo.wuwenhui.cn/uploads/20200911/860ef63de4af1dad13dcdd031a7cd4d5.jpg', 'PRODUCT CENTER', '强大的产品研发能力和创新能力', 'http://demo.wuwenhui.cn/uploads/20200911/e8361c327543f91628b22de0754c1c6d.jpg', 'SOLUTION', '根据每个客户的不同需求定制不同层次的解决方案', 'http://demo.wuwenhui.cn/uploads/20200911/23ba732cd0974f4957a50d37b6345894.jpg', 'SERVICE CENTRE', '服务群众是我们的责任，群众满意是我们的心愿', 'http://demo.wuwenhui.cn/uploads/20200911/574618243ffbcdb37fa699b9dbf448a8.jpg', 'NEWS', '紧密跟随国家产业指导及技术发展', 'http://demo.wuwenhui.cn/uploads/20200911/a2db50ac891ba18017285b12956fcda0.jpg', 'ABOUT US', '专注于计算机通信集成（CTI）领域', 'http://demo.wuwenhui.cn/uploads/20200911/ae93442deba880846c4d5066412004db.jpg', 'PARTNER', '诚信为本、合作共赢', 'http://demo.wuwenhui.cn/uploads/20211020/9049502cf538d33ab0f697ead0bde024.jpg', 'http://demo.wuwenhui.cn/uploads/20211020/b170b2a25ae7ed539033f61717fd84a9.jpg', 'http://demo.wuwenhui.cn/uploads/20211020/5f91880148172f93273bcd10135dcf80.jpg', 'http://demo.wuwenhui.cn/uploads/20211020/eb53a96264b17ef6dc530af1d62d3c36.jpg', 'http://demo.wuwenhui.cn/uploads/20211020/39cabfc00c696c170f5778e589c8fac2.jpg', '<div class=\"items-box\">\r\n          <div class=\"tt\">关于我们<span></span></div>\r\n          <div class=\"items\">\r\n            <a href=\"#\" class=\"item\">公司概况</a>\r\n            <a href=\"#\" class=\"item\">荣誉资质</a>\r\n            <a href=\"#\" class=\"item\">加入我们</a>\r\n            <a href=\"#\" class=\"item\">联系我们</a>\r\n          </div>\r\n        </div>\r\n        <div class=\"items-box\">\r\n          <div class=\"tt\">新闻中心<span></span></div>\r\n          <div class=\"items\">\r\n            <a href=\"#\" class=\"item\">互联网</a>\r\n            <a href=\"#\" class=\"item\">行业资讯</a>\r\n            <a href=\"#\" class=\"item\">5G频道</a>\r\n          </div>\r\n        </div>\r\n        <div class=\"items-box\">\r\n          <div class=\"tt\">服务中心<span></span></div>\r\n          <div class=\"items\">\r\n            <a href=\"#\" class=\"item\">服务策略</a>\r\n            <a href=\"#\" class=\"item\">营销网络</a>\r\n          </div>\r\n        </div>\r\n        <div class=\"items-box\">\r\n          <div class=\"tt\">常用链接<span></span></div>\r\n          <div class=\"items\">\r\n            <a href=\"#\" class=\"item\">产品中心</a>\r\n            <a href=\"#\" class=\"item\">解决方案</a>\r\n            <a href=\"#\" class=\"item\">客户留言</a>\r\n          </div>\r\n        </div>\r\n        <div class=\"items-box\">\r\n          <div class=\"tt\">联系我们<span></span></div>\r\n          <div class=\"items\">\r\n            <a href=\"javascript:;\" class=\"item\">0571-88888888</a>\r\n            <a href=\"javascript:;\" class=\"item\">support@admin.com</a>\r\n            <a href=\"javascript:;\" class=\"item\">杭州市滨江区江汉路1515号</a>\r\n          </div>\r\n        </div>', '120.210704,30.20676', '30.20676,120.210704', '杭州演示站点股份有限公司', '浙江省杭州市滨江区江汉路1515号', '0571-88888888', '0571-66666666');

--
-- 转存表中的数据 `__PREFIX__wwh_home`
--

INSERT INTO `__PREFIX__wwh_home` (`id`, `about_title`, `introduction`, `title1`, `description1`, `title2`, `description2`, `title3`, `description3`) VALUES
(1, '关于我们', '这是一段演示文字，这是一段演示文字，这是一段演示文字，这是一段演示文字，这是一段演示文字，这是一段演示文字，这是一段演示文字，这是一段演示文字，这是一段演示文字，这是一段演示文字！', '2006', '<p>公司正式成立</p><p>XXXXXXXX有限公司</p>', '50', '<p>全国行业50强企业</p><p>连续5年入选，2019年度排名26位</p>', '23', '<p>23个省级行政区</p><p>全国售后服务体系覆盖范围</p>');
COMMIT;

--
-- 1.0.3
-- 旧版本修复表结构，解决方案添加描述
--
ALTER TABLE `__PREFIX__wwh_cases` ADD COLUMN `description` varchar(255) DEFAULT NULL COMMENT '描述' AFTER `time`;

--
-- 1.0.5
-- 旧版本修复表结构，产品分类及产品内容增加pids
--
ALTER TABLE `__PREFIX__wwh_product` ADD `pids` VARCHAR(255) NOT NULL DEFAULT '0' COMMENT 'pids' AFTER `productcategoryid`;
ALTER TABLE `__PREFIX__wwh_productcategory` ADD `pids` VARCHAR(255) NOT NULL DEFAULT '0' COMMENT 'pids' AFTER `pid`;

--
-- 1.0.6
-- 旧版本修复表结构，新增关键字及说明
--
ALTER TABLE `__PREFIX__wwh_config` ADD `logo` VARCHAR(1000) NULL COMMENT 'logo' AFTER `description`;
ALTER TABLE `__PREFIX__wwh_cases` ADD `c_keywords` VARCHAR(1000) NULL COMMENT '关键字' AFTER `casesname`;
ALTER TABLE `__PREFIX__wwh_cases` ADD `c_description` VARCHAR(1000) NULL COMMENT '说明' AFTER `c_keywords`;
ALTER TABLE `__PREFIX__wwh_news` ADD `n_keywords` VARCHAR(1000) NULL COMMENT '关键字' AFTER `newsname`;
ALTER TABLE `__PREFIX__wwh_news` ADD `n_description` VARCHAR(1000) NULL COMMENT '说明' AFTER `n_keywords`;
ALTER TABLE `__PREFIX__wwh_product` ADD `p_keywords` VARCHAR(1000) NULL COMMENT '关键字' AFTER `productname`;
ALTER TABLE `__PREFIX__wwh_product` ADD `p_description` VARCHAR(1000) NULL COMMENT '说明' AFTER `p_keywords`;

--
-- 1.0.8
-- 旧版本修复表结构，新增底部logo、侧栏电话等
--
ALTER TABLE `__PREFIX__wwh_config` ADD `footer_logo` VARCHAR(1000) NULL COMMENT '底部logo' AFTER `logo`;
ALTER TABLE `__PREFIX__wwh_config` ADD `tel` VARCHAR(100) NULL COMMENT '电话' AFTER `email`;
ALTER TABLE `__PREFIX__wwh_config` ADD `map_zb` VARCHAR(1000) NULL COMMENT '地图坐标' AFTER `content`;
ALTER TABLE `__PREFIX__wwh_config` ADD `map_dzq` VARCHAR(1000) NULL COMMENT '到这去坐标' AFTER `map_zb`;
ALTER TABLE `__PREFIX__wwh_config` ADD `map_mc` VARCHAR(1000) NULL COMMENT '地图公司名称' AFTER `map_dzq`;
ALTER TABLE `__PREFIX__wwh_config` ADD `map_dz` VARCHAR(1000) NULL COMMENT '地图公司地址' AFTER `map_mc`;

--
-- 1.1.0
-- 旧版本修复表结构，新增字段
--
ALTER TABLE `__PREFIX__wwh_about` ADD `about_image` VARCHAR(100) DEFAULT NULL COMMENT '关于图片' AFTER `about_content`;
ALTER TABLE `__PREFIX__wwh_about` ADD `culture_image1` varchar(100) DEFAULT NULL COMMENT '企业文化图片1' AFTER `culture_des1`;
ALTER TABLE `__PREFIX__wwh_about` ADD `culture_image2` varchar(100) DEFAULT NULL COMMENT '企业文化图片2' AFTER `culture_en2`;
ALTER TABLE `__PREFIX__wwh_about` ADD `culture_image3` varchar(100) DEFAULT NULL COMMENT '企业文化图片3' AFTER `culture_en3`;
ALTER TABLE `__PREFIX__wwh_about` ADD `culture_image4` varchar(100) DEFAULT NULL COMMENT '企业文化图片4' AFTER `culture_en4`;
ALTER TABLE `__PREFIX__wwh_about` ADD `culture_image5` varchar(100) DEFAULT NULL COMMENT '企业文化图片5' AFTER `culture_en5`;
ALTER TABLE `__PREFIX__wwh_config` CHANGE `map_zb` `map_zb` VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '地图坐标';
ALTER TABLE `__PREFIX__wwh_config` CHANGE `map_dzq` `map_dzq` VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '到这去坐标';
ALTER TABLE `__PREFIX__wwh_config` CHANGE `map_mc` `map_mc` VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '地图公司名称';
ALTER TABLE `__PREFIX__wwh_config` CHANGE `map_dz` `map_dz` VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '地图公司地址';
ALTER TABLE `__PREFIX__wwh_config` ADD `caidan1` varchar(100) DEFAULT NULL COMMENT '菜单图1' AFTER `banner5`;
ALTER TABLE `__PREFIX__wwh_config` ADD `caidan2` varchar(100) DEFAULT NULL COMMENT '菜单图2' AFTER `caidan1`;
ALTER TABLE `__PREFIX__wwh_config` ADD `caidan3` varchar(100) DEFAULT NULL COMMENT '菜单图3' AFTER `caidan2`;
ALTER TABLE `__PREFIX__wwh_config` ADD `caidan4` varchar(100) DEFAULT NULL COMMENT '菜单图4' AFTER `caidan3`;
ALTER TABLE `__PREFIX__wwh_config` ADD `caidan5` varchar(100) DEFAULT NULL COMMENT '菜单图5' AFTER `caidan4`;
UPDATE `__PREFIX__wwh_config` SET `caidan1` = 'http://demo.wuwenhui.cn/uploads/20211020/9049502cf538d33ab0f697ead0bde024.jpg', `caidan2` = 'http://demo.wuwenhui.cn/uploads/20211020/b170b2a25ae7ed539033f61717fd84a9.jpg', `caidan3` = 'http://demo.wuwenhui.cn/uploads/20211020/5f91880148172f93273bcd10135dcf80.jpg', `caidan4` = 'http://demo.wuwenhui.cn/uploads/20211020/eb53a96264b17ef6dc530af1d62d3c36.jpg', `caidan5` = 'http://demo.wuwenhui.cn/uploads/20211020/39cabfc00c696c170f5778e589c8fac2.jpg' WHERE `__PREFIX__wwh_config`.`id` = 1;
UPDATE `__PREFIX__wwh_about` SET `about_image` = 'http://demo.wuwenhui.cn/uploads/20211020/94d03a82daebb7a87817845d78b3cc33.jpg', `culture_image1` = 'http://demo.wuwenhui.cn/uploads/20211020/a4347b2369e1b8fcabdec962b9b4052c.jpg', `culture_image2` = 'http://demo.wuwenhui.cn/uploads/20211020/a003d8db4e0ef2dc3e272f581aa208af.jpg', `culture_image3` = 'http://demo.wuwenhui.cn/uploads/20211020/953648e0505bff999deae66d1c2c1922.jpg', `culture_image4` = 'http://demo.wuwenhui.cn/uploads/20211020/97439f6a644814147310c49c8905652f.jpg', `culture_image5` = 'http://demo.wuwenhui.cn/uploads/20211020/d65c8175feef6ab647527f4546c52a7e.jpg' WHERE `__PREFIX__wwh_about`.`id` = 1;

--
-- 1.1.1
-- 旧版本修复表结构，新增字段
--
ALTER TABLE `__PREFIX__wwh_config` ADD `banner6` varchar(500) DEFAULT NULL COMMENT '合作伙伴' AFTER `banner5`;
UPDATE `__PREFIX__wwh_config` SET `banner6` = 'http://demo.wuwenhui.cn/uploads/20200911/ae93442deba880846c4d5066412004db.jpg' WHERE `__PREFIX__wwh_config`.`id` = 1;

--
-- 1.1.2
-- 旧版本修复表结构，新增字段
--
ALTER TABLE `__PREFIX__wwh_casescategory` CHANGE `pid` `pid` INT(10) NULL DEFAULT '0' COMMENT 'pid';
ALTER TABLE `__PREFIX__wwh_newscategory` CHANGE `pid` `pid` INT(10) NULL DEFAULT '0' COMMENT 'pid';
ALTER TABLE `__PREFIX__wwh_message` ADD `createtime` INT NULL DEFAULT NULL COMMENT '提交时间' AFTER `content`;

--
-- 1.1.3
-- 旧版本修复表结构，新增字段
--
ALTER TABLE `__PREFIX__wwh_config` ADD `link1` varchar(100) DEFAULT NULL COMMENT '公网安备地址' AFTER `gongwang`;
ALTER TABLE `__PREFIX__wwh_config` ADD `link2` varchar(100) DEFAULT NULL COMMENT '备案地址' AFTER `beian`;
ALTER TABLE `__PREFIX__wwh_config` ADD `sale` varchar(100) DEFAULT NULL COMMENT '销售咨询' AFTER `map_dz`;
ALTER TABLE `__PREFIX__wwh_config` ADD `technology` varchar(100) DEFAULT NULL COMMENT '技术支持' AFTER `sale`;

--
-- 1.1.4
-- 旧版本修复表结构，新增字段
--
ALTER TABLE `__PREFIX__wwh_config` ADD `ban1_t1` varchar(100) DEFAULT NULL COMMENT '产品中心英文' AFTER `banner1`;
ALTER TABLE `__PREFIX__wwh_config` ADD `ban1_t2` varchar(100) DEFAULT NULL COMMENT '产品中心中文' AFTER `ban1_t1`;
ALTER TABLE `__PREFIX__wwh_config` ADD `ban2_t1` varchar(100) DEFAULT NULL COMMENT '解决方案英文' AFTER `banner2`;
ALTER TABLE `__PREFIX__wwh_config` ADD `ban2_t2` varchar(100) DEFAULT NULL COMMENT '解决方案中文' AFTER `ban2_t1`;
ALTER TABLE `__PREFIX__wwh_config` ADD `ban3_t1` varchar(100) DEFAULT NULL COMMENT '服务中心英文' AFTER `banner3`;
ALTER TABLE `__PREFIX__wwh_config` ADD `ban3_t2` varchar(100) DEFAULT NULL COMMENT '服务中心中文' AFTER `ban3_t1`;
ALTER TABLE `__PREFIX__wwh_config` ADD `ban4_t1` varchar(100) DEFAULT NULL COMMENT '新闻中心英文' AFTER `banner4`;
ALTER TABLE `__PREFIX__wwh_config` ADD `ban4_t2` varchar(100) DEFAULT NULL COMMENT '新闻中心中文' AFTER `ban4_t1`;
ALTER TABLE `__PREFIX__wwh_config` ADD `ban5_t1` varchar(100) DEFAULT NULL COMMENT '关于我们英文' AFTER `banner5`;
ALTER TABLE `__PREFIX__wwh_config` ADD `ban5_t2` varchar(100) DEFAULT NULL COMMENT '关于我们中文' AFTER `ban5_t1`;
ALTER TABLE `__PREFIX__wwh_config` ADD `ban6_t1` varchar(100) DEFAULT NULL COMMENT '合作伙伴英文' AFTER `banner6`;
ALTER TABLE `__PREFIX__wwh_config` ADD `ban6_t2` varchar(100) DEFAULT NULL COMMENT '合作伙伴中文' AFTER `ban6_t1`;

--
-- 1.1.5
-- 旧版本修复表结构，新增字段
--
ALTER TABLE `__PREFIX__wwh_news` ADD `status` enum('0','1') NOT NULL DEFAULT '0' COMMENT '审核状态' AFTER `views`;
