define(['jquery', 'bootstrap', 'backend', 'table', 'form', 'jstree'], function ($, undefined, Backend, Table, Form, jstree) {
    var Controller = {
        index: function () {
            $(".btn-detail").data("area", ['90%', '90%']);
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'wwh/news/index',
                    add_url: 'wwh/news/add',
                    edit_url: 'wwh/news/edit',
                    del_url: 'wwh/news/del',
                    multi_url: 'wwh/news/multi',
                    table: 'wwh_news',
					dragsort_url:'',
                }
            });
            var table = $("#table");
            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'news.id',
                fixedColumns : true,
                fixedRightNumber  : 2,
                columns: [
                    [
                        // {checkbox: true},
                        {
                            checkbox: true, formatter:function (value,row,index){
                                if (row.status == 1){
                                    return{
                                        disabled:true
                                    };
                                }
                            }
                        },
                        {field: 'id', title: __('Id'), },
                        {field: 'newsname', title: __('Newsname')},
                        {field: 'newscategory.name', title: __('Newscategory'), formatter: Table.api.formatter.search},
                        {field: 'n_keywords', title: __('N_keywords')},
                        {field: 'n_description', title: __('N_description')},
						{
                            field: 'summary', sortable: false, title: __('Summary'), formatter: function (value, row, index) {
                                var width = this.width != undefined ? this.width : 250;
                                return "<div style='white-space: nowrap; text-overflow:ellipsis; overflow: hidden; max-width:" + width + "px;'>" + value + "</div>";
                            }
                        },
						{field: 'tjdata', title: __('Tjdata'), searchList: {"0":__('Tjdata 0'),"1":__('Tjdata 1')}, formatter: Table.api.formatter.normal},
                        {field: 'image', title: __('Image'), events: Table.api.events.image, formatter: Table.api.formatter.image, operate: false},
                        {field: 'weigh', title: __('Weigh'), sortable: true,cellStyle: function () {return {css: {"min-width": "65px"}}}},
                        {field: 'time', title: __('Time'), operate:'RANGE', addclass:'datetimerange', sortable: true},
                        {field: 'views', title: __('Views')},
                        {field: 'updatetime', title: __('Updatetime'), operate:'RANGE', addclass:'datetimerange', formatter: Table.api.formatter.datetime},
                        {field: 'status', title: __('Status'), searchList: {"0":__('Status 0'),"1":__('Status 1')}, custom: {0: 'grey', 1: 'info'}, formatter: Table.api.formatter.flag},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate,
                            buttons: [
                                {
                                    name: 'faudit',
                                    text: __('反审核'),
                                    title: __('反审核'),
                                    classname: 'btn btn-xs btn-danger btn-magic btn-ajax',
                                    // icon: 'fa fa-close',
                                    url: 'wwh/news/faudit',
                                    hidden:function(row){
                                        if(row.status != '1'){
                                            return true;
                                        }
                                    },
                                    success: function (data, ret) {
                                        table.bootstrapTable('refresh');    //自动刷新
                                    },
                                }
                            ],
                            formatter: function (value, row, index) {
                                var that = $.extend({}, this);
                                var table = $(that.table).clone(true);
                                if (row.status == 1){
                                    $(table).data("operate-edit",null);
                                    $(table).data("operate-del",null);
                                }
                                that.table = table;
                                return Table.api.formatter.operate.call(that, value, row, index);
                            }}
                    ]
                ],
                queryParams: function (params) {
                    return params;
                },
                onPostBody: function () {
                    $(".btn-detailone").data("area", ['90%', '90%']);
                }
            });
            $(function () {
                $("#channeltree").jstree({
                    "themes": {
                        "stripes": true
                    },
                    "checkbox": {
                        "keep_selected_style": false,
                    },
                    "types": {
                        "channel": {
                            "icon": "fa fa-th",
                        },
                        "list": {
                            "icon": "fa fa-list",
                        },
                        "link": {
                            "icon": "fa fa-link",
                        },
                        "disabled": {
                            "check_node": false,
                            "uncheck_node": false
                        }
                    },
                    'plugins': ["types", "checkbox"],
                    "core": {
						"multiple": false,
                        'check_callback': true,
                        "themes":{
                            "icons":false,
                        },
                        "data": {
                            url: "wwh/newscategory/getjsTree",
                        }
                    }
                }).on("select_node.jstree deselect_node.jstree", function (e, data) {
                    $("#table").bootstrapTable("refresh", {query: {categoryids: data.selected.join(",")}});
                });
            });

            //审核
            $(document).on("click", ".btn-audit", function () {
                var data = table.bootstrapTable('getSelections');
                var ids = [];
                if (data.length === 0) {
                    Toastr.error("请选择操作信息");
                    return;
                }
                for (var i = 0; i < data.length; i++) {
                    ids[i] = data[i]['id']
                }
                Layer.confirm(
                    '确认选中'+ids.length+'条审核吗?',
                    {icon: 3, title: __('Warning'), offset: '40%', shadeClose: true},
                    function (index) {
                        Layer.close(index);
                        Backend.api.ajax({
                            url: "wwh/news/audit",
                            data: {ids:ids}
                        }, function(data, ret){//成功的回调
                            if (ret.code === 1) {
                                table.bootstrapTable('refresh');
                                Layer.close(index);
                            } else {
                                Layer.close(index);
                                Toastr.error(ret.msg);
                            }
                        }, function(data, ret){//失败的回调
                            console.log(ret);
                            Layer.close(index);
                        });
                    }
                );
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));   
            }
        },
    };
    return Controller;
});
